import { BumperConfig } from '../types/bumper';
import { getWatermarkImage } from './watermarkTemplates';

// Particle memory cache for deterministic particle animation
interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  seed: number;
}

const particlePool: Record<string, Particle[]> = {};

function getParticles(theme: string, count: number): Particle[] {
  const key = `${theme}_${count}`;
  if (!particlePool[key] || particlePool[key].length !== count) {
    const list: Particle[] = [];
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const radius = 0.1 + Math.random() * 0.9;
      list.push({
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        z: Math.random(),
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: 1 + Math.random() * 3.5,
        color: '#FFFFFF',
        seed: Math.random(),
      });
    }
    particlePool[key] = list;
  }
  return particlePool[key];
}

// Logo image cache
const imageCache = new Map<string, HTMLImageElement>();

export function getCachedImage(url?: string): HTMLImageElement | null {
  if (!url) return null;
  if (imageCache.has(url)) {
    const img = imageCache.get(url)!;
    return img.complete ? img : null;
  }
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.src = url;
  imageCache.set(url, img);
  return null;
}

// Pre-load the official sliced HD assets immediately
if (typeof window !== 'undefined') {
  getCachedImage('/assets/aistudio/kso_nke_hd.png');
  getCachedImage('/assets/aistudio/kso_jaya_hd.png');
  getCachedImage('/assets/aistudio/kso_wiswa_hd.png');
  getCachedImage('/assets/aistudio/kso_full_hd.png');
  getCachedImage('/assets/aistudio/LOGO_KSO_HD_vektor_edcea276.png');
  getCachedImage('/assets/aistudio/LOGO_WM_NKE_R3_c1d75e16.png');
  getCachedImage('/assets/aistudio/image_737631e5.png');
}

// Smooth easing helpers
function easeOutCubic(x: number): number {
  const t = Math.max(0, Math.min(1, x));
  return 1 - Math.pow(1 - t, 3);
}

function easeOutExpo(x: number): number {
  const t = Math.max(0, Math.min(1, x));
  return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
}

function easeOutBack(x: number): number {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  const t = Math.max(0, Math.min(1, x)) - 1;
  return 1 + c3 * Math.pow(t, 3) + c1 * Math.pow(t, 2);
}

function clamp(val: number, min: number = 0, max: number = 1): number {
  return Math.max(min, Math.min(max, val));
}

/**
 * Traces an authentic jigsaw edge from (x0, y0) to (x1, y1)
 * matching the 4-piece jigsaw reference (image_460651e4.png).
 * tabDir: +1 for tab on right of vector, -1 for tab on left of vector, 0 for flat outer edge
 */
function addJigsawEdge(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  tabDir: number,
  tabSize: number = 0.22
) {
  if (tabDir === 0) {
    ctx.lineTo(x1, y1);
    return;
  }
  const dx = x1 - x0;
  const dy = y1 - y0;
  const len = Math.hypot(dx, dy);
  if (len < 1) {
    ctx.lineTo(x1, y1);
    return;
  }
  const ux = dx / len;
  const uy = dy / len;
  // Normal perpendicular vector pointing to tab direction
  const nx = (dy / len) * tabDir;
  const ny = (-dx / len) * tabDir;
  const hTab = len * tabSize;

  // Neck start at 38%
  const pA_x = x0 + ux * len * 0.38;
  const pA_y = y0 + uy * len * 0.38;
  ctx.lineTo(pA_x, pA_y);

  // Peak of round circular knob at 50%
  const pPeak_x = x0 + ux * len * 0.50 + nx * hTab;
  const pPeak_y = y0 + uy * len * 0.50 + ny * hTab;

  // Neck end at 62%
  const pB_x = x0 + ux * len * 0.62;
  const pB_y = y0 + uy * len * 0.62;

  // Cubic beziers forming the circular jigsaw knob and socket
  const cp1_x = pA_x - nx * (hTab * 0.12) + ux * len * 0.01;
  const cp1_y = pA_y - ny * (hTab * 0.12) + uy * len * 0.01;
  const cp2_x = pPeak_x - ux * len * 0.14 + nx * (hTab * 0.15);
  const cp2_y = pPeak_y - uy * len * 0.14 + ny * (hTab * 0.15);
  ctx.bezierCurveTo(cp1_x, cp1_y, cp2_x, cp2_y, pPeak_x, pPeak_y);

  const cp3_x = pPeak_x + ux * len * 0.14 + nx * (hTab * 0.15);
  const cp3_y = pPeak_y + uy * len * 0.14 + ny * (hTab * 0.15);
  const cp4_x = pB_x - nx * (hTab * 0.12) - ux * len * 0.01;
  const cp4_y = pB_y - ny * (hTab * 0.12) - uy * len * 0.01;
  ctx.bezierCurveTo(cp3_x, cp3_y, cp4_x, cp4_y, pB_x, pB_y);

  ctx.lineTo(x1, y1);
}

/**
 * Generates the closed path for each of the 4 interlocking jigsaw pieces:
 * Piece 0: Top-Left (Yellow in reference image)
 * Piece 1: Top-Right (Pink in reference image)
 * Piece 2: Bottom-Left (Blue in reference image)
 * Piece 3: Bottom-Right (Green in reference image)
 */
function buildJigsawPiecePath(
  ctx: CanvasRenderingContext2D,
  pieceIndex: number,
  x0: number,
  y0: number,
  x1: number,
  y1: number
) {
  const xm = (x0 + x1) / 2;
  const ym = (y0 + y1) / 2;

  ctx.beginPath();
  if (pieceIndex === 0) {
    // 0: TOP-LEFT
    ctx.moveTo(x0, y0);
    addJigsawEdge(ctx, x0, y0, xm, y0, 0); // top flat
    addJigsawEdge(ctx, xm, y0, xm, ym, 1); // right tab into TR
    addJigsawEdge(ctx, xm, ym, x0, ym, -1); // bottom receives tab from BL (socket)
    addJigsawEdge(ctx, x0, ym, x0, y0, 0); // left flat
  } else if (pieceIndex === 1) {
    // 1: TOP-RIGHT
    ctx.moveTo(xm, y0);
    addJigsawEdge(ctx, xm, y0, x1, y0, 0); // top flat
    addJigsawEdge(ctx, x1, y0, x1, ym, 0); // right flat
    addJigsawEdge(ctx, x1, ym, xm, ym, -1); // bottom tab into BR
    addJigsawEdge(ctx, xm, ym, xm, y0, -1); // left receives tab from TL (socket)
  } else if (pieceIndex === 2) {
    // 2: BOTTOM-LEFT
    ctx.moveTo(x0, ym);
    addJigsawEdge(ctx, x0, ym, xm, ym, 1); // top tab into TL
    addJigsawEdge(ctx, xm, ym, xm, y1, 1); // right tab into BR
    addJigsawEdge(ctx, xm, y1, x0, y1, 0); // bottom flat
    addJigsawEdge(ctx, x0, y1, x0, ym, 0); // left flat
  } else {
    // 3: BOTTOM-RIGHT
    ctx.moveTo(xm, ym);
    addJigsawEdge(ctx, xm, ym, x1, ym, 1); // top receives tab from TR (socket)
    addJigsawEdge(ctx, x1, ym, x1, y1, 0); // right flat
    addJigsawEdge(ctx, x1, y1, xm, y1, 0); // bottom flat
    addJigsawEdge(ctx, xm, y1, xm, ym, -1); // left receives tab from BL (socket)
  }
  ctx.closePath();
}

/**
 * Dynamic tab direction generator for interlocking jigsaw grids (rows x cols).
 * Guarantees complementary tabs (+1) and sockets (-1) between adjacent pieces:
 * - Horizontal boundary between row r and row r+1 at col c
 * - Vertical boundary between col c and col c+1 at row r
 */
function getJigsawTabDir(type: 'h' | 'v', r: number, c: number): number {
  if (type === 'h') {
    return ((r + c) % 2 === 0) ? 1 : -1;
  }
  return ((r * 2 + c) % 2 === 0) ? 1 : -1;
}

function buildGridJigsawPiecePath(
  ctx: CanvasRenderingContext2D,
  r: number,
  c: number,
  rows: number,
  cols: number,
  gridX0: number,
  gridY0: number,
  cellW: number,
  cellH: number
) {
  const x0 = gridX0 + c * cellW;
  const y0 = gridY0 + r * cellH;
  const x1 = x0 + cellW;
  const y1 = y0 + cellH;

  ctx.beginPath();
  ctx.moveTo(x0, y0);

  // 1. Top Edge (left to right)
  if (r === 0) {
    ctx.lineTo(x1, y0);
  } else {
    // In row r-1, the bottom edge had direction getJigsawTabDir('h', r - 1, c).
    // Moving left-to-right on row r, the tab direction is opposite.
    addJigsawEdge(ctx, x0, y0, x1, y0, -getJigsawTabDir('h', r - 1, c), 0.22);
  }

  // 2. Right Edge (top to bottom)
  if (c === cols - 1) {
    ctx.lineTo(x1, y1);
  } else {
    addJigsawEdge(ctx, x1, y0, x1, y1, getJigsawTabDir('v', r, c), 0.22);
  }

  // 3. Bottom Edge (right to left)
  if (r === rows - 1) {
    ctx.lineTo(x0, y1);
  } else {
    addJigsawEdge(ctx, x1, y1, x0, y1, getJigsawTabDir('h', r, c), 0.22);
  }

  // 4. Left Edge (bottom to top)
  if (c === 0) {
    ctx.lineTo(x0, y0);
  } else {
    addJigsawEdge(ctx, x0, y1, x0, y0, -getJigsawTabDir('v', r, c - 1), 0.22);
  }

  ctx.closePath();
}

/**
 * Main Bumper Canvas Entry Point
 * Dispatches to:
 * 1. Bumper Logo (Single or Multiple Logo)
 * 2. Video Title Screen (Inspired by IKN Reference)
 * 3. Frame Video Logo Overlay (Inspired by Diagonal Watermark Reference)
 */
export function renderBumperFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  config: BumperConfig,
  time: number
) {
  const speed = config.motionSpeed || 1;

  ctx.save();

  if (config.studioMode === 'frame_video') {
    // Mode 3: Frame Video Logo Overlay
    renderFrameVideoMode(ctx, width, height, config, time);
  } else if (config.studioMode === 'video_title') {
    // Mode 2: Video Title Screen
    renderMasterBackground(ctx, width, height, config, time);
    renderVideoTitleMode(ctx, width, height, config, time, speed);
  } else {
    // Mode 1: Bumper Logo (Single or Multiple)
    renderMasterBackground(ctx, width, height, config, time);
    renderMasterPresentation(ctx, width, height, config, time, speed);
  }

  // Color Tone Grading (Applied across all modes)
  if (config.colorTone && config.colorTone !== 'none') {
    applyColorTone(ctx, width, height, config.colorTone);
  }

  // Post FX: Film Grain
  if (config.filmGrain && config.studioMode !== 'frame_video') {
    applyFilmGrain(ctx, width, height, time);
  }

  // Post FX: Vignette
  if (config.vignette && config.studioMode !== 'frame_video') {
    applyVignette(ctx, width, height);
  }

  // Post FX: Letterbox Cinematic Bars
  if (config.letterbox && config.aspectRatio === '16:9' && config.studioMode !== 'frame_video') {
    const barHeight = height * 0.1;
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, barHeight);
    ctx.fillRect(0, height - barHeight, width, barHeight);
  }

  ctx.restore();
}

/**
 * Master Background Renderer
 * Handles solid colors, multi-stop gradients, fully adjustable volumetric spotlight circles,
 * CAD grid, futuristic effects (laser scanner, cyber hex, hologram, light streaks), and photo backdrops.
 */
function renderMasterBackground(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const scale = Math.min(w, h) / 1000;

  const bgPrimary = cfg.backgroundColor || '#181F2B';
  const bgSecondary = cfg.backgroundSecondaryColor || '#3A0E14';
  const accent = cfg.accentColor || '#DFCEB5';
  const secColor = cfg.secondaryColor || '#DFCEB5';

  // 1. BASE BACKGROUND LAYER
  if (cfg.backgroundStyle === 'solid') {
    ctx.fillStyle = bgPrimary;
    ctx.fillRect(0, 0, w, h);
  } else if (cfg.backgroundStyle === 'custom_image' && cfg.customBackgroundUrl) {
    const bgImg = getCachedImage(cfg.customBackgroundUrl);
    if (bgImg) {
      const imgAspect = bgImg.naturalWidth / bgImg.naturalHeight;
      const canvasAspect = w / h;
      let dw = w, dh = h, dx = 0, dy = 0;
      if (imgAspect > canvasAspect) {
        dw = h * imgAspect;
        dx = (w - dw) / 2;
      } else {
        dh = w / imgAspect;
        dy = (h - dh) / 2;
      }
      ctx.drawImage(bgImg, dx, dy, dw, dh);
      ctx.fillStyle = 'rgba(4, 8, 16, 0.72)';
      ctx.fillRect(0, 0, w, h);
    } else {
      ctx.fillStyle = bgPrimary;
      ctx.fillRect(0, 0, w, h);
    }
  } else {
    const bgGrad = ctx.createLinearGradient(0, 0, w * 0.8, h);
    bgGrad.addColorStop(0, bgPrimary);
    bgGrad.addColorStop(0.5, bgSecondary);
    bgGrad.addColorStop(1, bgPrimary);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);
  }

  // 2. BULATAN CAHAYA (Spotlight Circle) - STRICTLY RESPECTS TOGGLE
  const isRadialGlowStyle = cfg.backgroundStyle === 'radial_glow';
  const isSpotlightEnabled = cfg.spotlightEnabled === true;
  const spotIntensity = cfg.spotlightIntensity !== undefined
    ? cfg.spotlightIntensity
    : (isRadialGlowStyle ? 0.9 : 0.65);

  if (isSpotlightEnabled && spotIntensity > 0 && cfg.backgroundStyle !== 'solid') {
    const pulseSpeed = cfg.spotlightPulseSpeed !== undefined ? cfg.spotlightPulseSpeed : 1.0;
    const pulse = 1.0 + Math.sin(t * 1.8 * pulseSpeed) * 0.08 * (pulseSpeed > 0 ? 1 : 0);

    const radiusMultiplier = (cfg.spotlightRadius !== undefined ? cfg.spotlightRadius : (isRadialGlowStyle ? 90 : 70)) / 100;
    const spotRadius = Math.min(w, h) * 0.58 * radiusMultiplier * pulse;

    const yOffsetPercent = (cfg.spotlightYOffset || 0) / 100;
    const spotY = cy + (h * 0.3) * yOffsetPercent;

    const baseColor = cfg.spotlightColor || secColor;
    const softness = cfg.spotlightSoftness !== undefined ? cfg.spotlightSoftness : 0.75;
    const midStop = Math.max(0.1, Math.min(0.9, softness * 0.65));

    const spotGrad = ctx.createRadialGradient(cx, spotY, 0, cx, spotY, spotRadius);
    spotGrad.addColorStop(0, hexToRgba(baseColor, spotIntensity * (isRadialGlowStyle ? 0.65 : 0.42)));
    spotGrad.addColorStop(midStop, hexToRgba(accent, spotIntensity * (isRadialGlowStyle ? 0.28 : 0.16)));
    spotGrad.addColorStop(1, 'rgba(0,0,0,0)');

    ctx.save();
    ctx.fillStyle = spotGrad;
    ctx.fillRect(0, 0, w, h);

    if (softness < 0.35 || isRadialGlowStyle) {
      ctx.strokeStyle = hexToRgba(baseColor, spotIntensity * 0.3);
      ctx.lineWidth = 1.5 * scale;
      ctx.beginPath();
      ctx.arc(cx, spotY, spotRadius * 0.7, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  // 3. EFEK FUTURISTIK & MODERN
  // A. Digital Laser Scanline
  const isLaserActive = cfg.laserScanline || cfg.futuristicEffect === 'laser_scan';
  if (isLaserActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    const laserY = (Math.sin(t * 1.6) * 0.5 + 0.5) * h;
    const lGrad = ctx.createLinearGradient(0, laserY - 8 * scale, 0, laserY + 8 * scale);
    lGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
    lGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.65)');
    lGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = lGrad;
    ctx.fillRect(0, laserY - 8 * scale, w, 16 * scale);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 1.5 * scale;
    ctx.beginPath();
    ctx.moveTo(0, laserY);
    ctx.lineTo(w, laserY);
    ctx.stroke();
    ctx.restore();
  }

  // B. Cyber Hexagonal Mesh (Always active if cyber_hex style or toggle selected)
  const isHexActive = cfg.cyberHexMesh || cfg.futuristicEffect === 'cyber_hex' || cfg.backgroundStyle === 'cyber_hex';
  if (isHexActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    ctx.strokeStyle = hexToRgba(accent, cfg.backgroundStyle === 'cyber_hex' ? 0.18 : 0.08);
    ctx.lineWidth = 1 * scale;
    const hexR = 36 * scale;
    const hDist = hexR * Math.sqrt(3);
    const vDist = hexR * 1.5;

    for (let hy = -vDist; hy < h + vDist; hy += vDist) {
      const rowIdx = Math.floor(hy / vDist);
      const xOff = (rowIdx % 2 === 0) ? 0 : hDist / 2;
      for (let hx = -hDist + xOff; hx < w + hDist; hx += hDist) {
        ctx.beginPath();
        for (let a = 0; a < 6; a++) {
          const angle = (Math.PI / 3) * a + Math.PI / 6;
          const px = hx + hexR * Math.cos(angle);
          const py = hy + hexR * Math.sin(angle);
          if (a === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();

        // Subtle glowing dot at intersection in cyber_hex mode
        if (cfg.backgroundStyle === 'cyber_hex' && ((Math.floor(hx) + Math.floor(hy)) % 7 === 0)) {
          ctx.fillStyle = hexToRgba(accent, 0.35);
          ctx.beginPath();
          ctx.arc(hx, hy, 1.8 * scale, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    ctx.restore();
  }

  // C. Hologram Scanlines (Active if hologram_lines style or toggle)
  const isHoloActive = cfg.hologramLines || cfg.futuristicEffect === 'hologram_lines' || cfg.backgroundStyle === 'hologram_lines';
  if (isHoloActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    ctx.fillStyle = hexToRgba(accent, cfg.backgroundStyle === 'hologram_lines' ? 0.06 : 0.025);
    const scanStep = 4 * scale;
    for (let sy = 0; sy < h; sy += scanStep) {
      ctx.fillRect(0, sy, w, 1 * scale);
    }
    // Animated slow vertical sweep beam
    const holoSweepY = ((t * 0.15) % 1.0) * h;
    const holoGrad = ctx.createLinearGradient(0, holoSweepY - 30 * scale, 0, holoSweepY + 30 * scale);
    holoGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
    holoGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.18)');
    holoGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = holoGrad;
    ctx.fillRect(0, holoSweepY - 30 * scale, w, 60 * scale);
    ctx.restore();
  }

  // D. Speed Light Streaks
  const isStreaksActive = cfg.lightStreaks || cfg.futuristicEffect === 'light_streaks';
  if (isStreaksActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    for (let i = 0; i < 8; i++) {
      const sProgress = ((t * (0.3 + i * 0.08) + i * 0.22) % 1.0);
      const sx = sProgress * (w * 1.6) - w * 0.3;
      const sy = h * (0.2 + (i * 0.09));
      const sLen = 140 * scale * (0.8 + (i % 3) * 0.4);

      const sGrad = ctx.createLinearGradient(sx - sLen, sy, sx, sy);
      sGrad.addColorStop(0, 'rgba(0,0,0,0)');
      sGrad.addColorStop(0.7, hexToRgba(accent, 0.25));
      sGrad.addColorStop(1, hexToRgba('#FFFFFF', 0.8));

      ctx.fillStyle = sGrad;
      ctx.fillRect(sx - sLen, sy - 1 * scale, sLen, 2 * scale);
    }
    ctx.restore();
  }

  // 4. PRECISION CAD TECHNICAL GRID (Active if technical_grid or showGrid)
  const isCadGridStyle = cfg.backgroundStyle === 'technical_grid';
  const showGrid = (cfg.showGrid || isCadGridStyle) && cfg.backgroundStyle !== 'solid';
  if (showGrid) {
    const gridOp = isCadGridStyle ? 0.09 : (cfg.gridOpacity !== undefined ? cfg.gridOpacity : 0.035);
    ctx.save();
    ctx.strokeStyle = `rgba(255, 255, 255, ${gridOp})`;
    ctx.lineWidth = 1 * scale;
    const step = 50 * scale;

    for (let x = 0; x < w; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // High-tech CAD crosshairs at intersections
    if (isCadGridStyle) {
      ctx.strokeStyle = hexToRgba(accent, 0.4);
      ctx.lineWidth = 1.2 * scale;
      const crossStep = step * 2;
      for (let cxp = crossStep; cxp < w; cxp += crossStep) {
        for (let cyp = crossStep; cyp < h; cyp += crossStep) {
          ctx.beginPath();
          ctx.moveTo(cxp - 5 * scale, cyp);
          ctx.lineTo(cxp + 5 * scale, cyp);
          ctx.moveTo(cxp, cyp - 5 * scale);
          ctx.lineTo(cxp, cyp + 5 * scale);
          ctx.stroke();
        }
      }

      // Technical blueprint coordinate tags in corners
      ctx.font = `700 ${9 * scale}px "JetBrains Mono", monospace`;
      ctx.fillStyle = hexToRgba(accent, 0.55);
      ctx.fillText('CAD REF // DATUM WGS84: 0°58\'12"S 116°50\'44"E', 30 * scale, 30 * scale);
      ctx.fillText('SCALE 1:1000 // ARCHITECTURAL SYSTEM', 30 * scale, h - 30 * scale);
      ctx.textAlign = 'right';
      ctx.fillText('NUSA JAYA WISWAKHARMAN [KSO]', w - 30 * scale, h - 30 * scale);
      ctx.textAlign = 'left';
    }

    ctx.strokeStyle = hexToRgba(secColor, 0.35);
    ctx.beginPath();
    ctx.moveTo(cx - 24 * scale, cy);
    ctx.lineTo(cx + 24 * scale, cy);
    ctx.moveTo(cx, cy - 24 * scale);
    ctx.lineTo(cx, cy + 24 * scale);
    ctx.stroke();
    ctx.restore();
  }

  // Floating Dust Particles
  const isParticlesStyle = cfg.backgroundStyle === 'particles';
  const particleCount = isParticlesStyle ? Math.max(90, cfg.particleCount || 90) : (cfg.particleCount !== undefined ? cfg.particleCount : 45);
  if ((particleCount > 0 || isParticlesStyle) && cfg.backgroundStyle !== 'solid') {
    const pColor = cfg.particleColor || secColor;
    const particles = getParticles(cfg.theme || 'default', Math.min(particleCount, 250));
    particles.forEach((pt) => {
      const py = ((pt.y + 0.5 - t * 0.05 * (0.6 + pt.seed * 0.4)) % 1 + 1) % 1;
      const px = ((pt.x + 0.5 + Math.sin(t * 0.45 + pt.seed * 8) * 0.04) % 1 + 1) % 1;
      const alpha = (0.25 + Math.sin(t * 2.0 + pt.seed * 15) * 0.25) * (1 - Math.abs(py - 0.5) * 1.6);
      if (alpha > 0) {
        ctx.fillStyle = hexToRgba(pColor, alpha * (isParticlesStyle ? 1.0 : 0.8));
        ctx.beginPath();
        ctx.arc(px * w, py * h, pt.size * scale * (isParticlesStyle ? 1.5 : 1.0) * (0.6 + pt.seed * 0.5), 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }
}

/**
 * Single Logo Animated Assembly:
 * 1. Logo starts MUCH LARGER and HERO-CENTERED
 * 2. Piece-by-piece reveal according to shape:
 *    - Phase 1: Green Triangle pops in / scales with bounce
 *    - Phase 2: Blue Triangle locks in
 *    - Phase 3: Yellow/Amber Triangle locks in
 * 3. Emblem is complete, holds center with energetic pulsing halo & flare
 * 4. Smoothly glides to the left
 * 5. Logo text ("NUSA KONSTRUKSI ENJINIRING") emerges on the right with beam wipe
 */
/**
 * Single Logo Animated Assembly & Transitions:
 * Supports:
 * 1. Segitiga Bergantian (NKE Sliced Geometric)
 * 2. Smooth Zoom & Flare Sweep
 * 3. 3D Isometric Flip & Glow
 * 4. Elastic Snap & Pulse Ring
 * 5. Digital Matrix Scan Reveal
 */
function renderSingleLogoSlicedAssemble(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  tAdj: number,
  scale: number,
  secColor: string
) {
  const logoScale = (cfg.singleLogoScale || 1.25) * (cfg.singleLogo?.scale || 1.0);
  const baseH = 80 * scale * logoScale;
  const animType = cfg.singleLogoTransition || cfg.singleLogoAnimation || 'nke_triangles_assemble';

  const customLogoUrl = cfg.singleLogo?.url || cfg.customLogoUrl || '/assets/aistudio/kso_nke_hd.png';
  const customImg = getCachedImage(customLogoUrl);
  const isNke = Boolean(
    customLogoUrl.includes('kso_nke') ||
    customLogoUrl.includes('Logo_NKE') ||
    cfg.singleLogo?.name?.toLowerCase().includes('nke') ||
    (!customLogoUrl && !customImg)
  );

  // Compute accurate aspect ratio and dimensions for active logo
  let aspect = 1.0;
  if (customImg && customImg.naturalHeight > 0) {
    aspect = customImg.naturalWidth / customImg.naturalHeight;
  } else if (isNke) {
    aspect = 1800 / 362; // ~4.97:1 aspect ratio
  } else if (customLogoUrl.includes('jaya')) {
    aspect = 1.0;
  } else if (customLogoUrl.includes('wiswa')) {
    aspect = 1.0;
  }
  const logoW = baseH * aspect;
  const logoH = baseH;

  // Title & Text presence (Only slides left if user enabled title or non-empty title provided)
  const titleText = (cfg.singleLogoTitle || (cfg.singleLogoShowTitle ? cfg.title : '') || '').trim();
  const hasTitle = Boolean(cfg.singleLogoShowTitle && titleText.length > 0);
  const shouldSlide = hasTitle;

  // Glide to the left only when title is present
  const pSlide = clamp((tAdj - 1.9) / 0.85);
  const easeSlide = easeOutCubic(pSlide);
  const slideDistance = Math.min(w * 0.24, (logoW / 2 + 110 * scale));
  const curX = shouldSlide ? -slideDistance * easeSlide : 0;

  // Text emerges on the right after gliding left
  const pText = clamp((tAdj - 2.3) / 0.85);
  const easeText = easeOutCubic(pText);
  const alphaText = shouldSlide ? clamp(pText * 1.4) : 0;

  // Center Ambient Halo (Scaled dynamically to logo's actual dimensions in Warm Sand & Burgundy)
  const haloPulse = 1.0 + Math.sin(tAdj * 2.2) * 0.08;
  const haloRadius = Math.max(logoW, logoH) * 0.75 * haloPulse;
  const haloGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, haloRadius);
  haloGrad.addColorStop(0, hexToRgba('#DFCEB5', 0.40));
  haloGrad.addColorStop(0.5, hexToRgba('#5C1018', 0.20));
  haloGrad.addColorStop(1, 'rgba(0,0,0,0)');

  ctx.save();
  ctx.translate(curX, 0);

  // Background Ambient Halo
  ctx.fillStyle = haloGrad;
  ctx.beginPath();
  ctx.arc(0, 0, haloRadius, 0, Math.PI * 2);
  ctx.fill();

  // Draw Logo with Chosen Animation
  if (animType === 'puzzle_assemble') {
    // =========================================================================
    // A. PUZZLE ASSEMBLE: Interlocking Small Jigsaw Pieces (Biru, Oren, Hijau, Gold)
    // - Emblem is constructed from small precision jigsaw pieces
    // - Zero cut-off / clipping: uses exact emblem aspect ratio & safe bounds
    // - Text emerges smoothly with silky wipe after emblem pieces snap together
    // =========================================================================
    const isWideLogoWithText = aspect > 2.0;
    // For NKE logo, the emblem is 954px of 1800px (~0.53 ratio). For other wide logos, ~0.52.
    const emblemRatio = isNke ? (954 / 1800) : (isWideLogoWithText ? 0.52 : 1.0);
    const emblemW = isWideLogoWithText ? logoW * emblemRatio : logoW;
    const emblemH = logoH;

    const emblemX0 = -logoW / 2;
    const emblemY0 = -logoH / 2;
    const emblemX1 = emblemX0 + emblemW;
    const emblemY1 = emblemY0 + emblemH;
    const emblemCenterX = emblemX0 + emblemW / 2;
    const emblemCenterY = 0;

    const rows = 4;
    const cols = isWideLogoWithText ? 6 : 4;
    const cellW = emblemW / cols;
    const cellH = emblemH / rows;

    // Piece colors based on the official NKE / KSO palette (Hijau, Oren, Biru, Gold)
    const getPieceColor = (r: number, c: number) => {
      if (isWideLogoWithText) {
        if (c <= 1) {
          return r % 2 === 0 ? '#00C853' : '#12A727'; // Hijau NKE
        } else if (c <= 3) {
          if (r <= 1) return (r + c) % 2 === 0 ? '#FF7A00' : '#FF9100'; // Oren / Amber
          return (r + c) % 2 === 0 ? '#1E88E5' : '#144DFF'; // Biru Sapphire
        } else {
          if (r === 0) return '#FFB51C'; // Amber / Gold
          if (r === 3 && c === 5) return '#DFCEB5'; // Warm Sand / Gold Accent
          return (r + c) % 2 === 0 ? '#1E88E5' : '#2979FF'; // Biru NKE
        }
      } else {
        const palette = ['#00C853', '#FF7A00', '#1E88E5', '#DFCEB5'];
        return palette[(r * 2 + c) % palette.length];
      }
    };

    ctx.save();

    // 1. Draw small interlocking puzzle pieces flying in and clicking together
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const pCenterX = emblemX0 + (c + 0.5) * cellW;
        const pCenterY = emblemY0 + (r + 0.5) * cellH;

        // Angle and distance radiating from emblem center
        const angle = Math.atan2(pCenterY - emblemCenterY, pCenterX - emblemCenterX);
        const distFromCenter = Math.hypot((c - (cols - 1) / 2) / cols, (r - (rows - 1) / 2) / rows);
        const pieceDelay = 0.04 + distFromCenter * 0.18 + ((r * 2 + c) % 3) * 0.04;

        // Silky smooth quintic easing for fluid floating flight
        const pProg = clamp((tAdj - pieceDelay) / 0.52);
        const easeP = 1 - Math.pow(1 - pProg, 4);

        const offDist = (1 - easeP) * 150 * scale;
        const dirX = Math.cos(angle) * (1.1 + ((r * 3 + c) % 3) * 0.2);
        const dirY = Math.sin(angle) * (1.1 + ((r + c * 3) % 3) * 0.2);
        const offX = dirX * offDist;
        const offY = dirY * offDist;
        const curRot = (1 - easeP) * ((((r * 3 + c * 5) % 7) - 3) * 0.07);
        const pAlpha = clamp(pProg * 2.2);
        const pieceColor = getPieceColor(r, c);

        ctx.save();
        ctx.translate(pCenterX + offX, pCenterY + offY);
        ctx.rotate(curRot);
        ctx.translate(-pCenterX, -pCenterY);
        ctx.globalAlpha = pAlpha;

        // Soft colored halo aura
        ctx.shadowColor = hexToRgba(pieceColor, 0.65 * (1 - easeP * 0.4));
        ctx.shadowBlur = 12 * scale * (1 - easeP * 0.3);

        // Clip strictly to this piece's authentic interlocking jigsaw contour
        buildGridJigsawPiecePath(ctx, r, c, rows, cols, emblemX0, emblemY0, cellW, cellH);
        ctx.clip();

        // Render full image inside piece - perfectly aligned with natural aspect ratio
        if (customImg) {
          ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
        } else if (isNke) {
          drawLogo1NKE(ctx, 0, 0, logoH, logoW);
        } else {
          drawNkeEmblemDirect(ctx, emblemX0, emblemY0, emblemY1, emblemW / 2, emblemW / 2, scale);
        }

        // Visible jigsaw tab seam stroke in this piece's color while assembling
        if (easeP < 0.99) {
          ctx.strokeStyle = pieceColor;
          ctx.lineWidth = 1.5 * scale;
          buildGridJigsawPiecePath(ctx, r, c, rows, cols, emblemX0, emblemY0, cellW, cellH);
          ctx.stroke();
        }

        ctx.restore();
      }
    }

    // 2. Once all pieces assemble (tAdj >= 0.82), render unified seamless emblem with zero cracks
    if (tAdj >= 0.82) {
      const pSolid = clamp((tAdj - 0.82) / 0.18);
      ctx.save();
      ctx.globalAlpha = pSolid;
      ctx.beginPath();
      ctx.rect(emblemX0 - 4 * scale, -logoH / 2 - 10 * scale, emblemW + 8 * scale, logoH + 20 * scale);
      ctx.clip();
      if (customImg) {
        ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
      } else if (isNke) {
        drawLogo1NKE(ctx, 0, 0, logoH, logoW);
      }
      ctx.restore();
    }

    // 3. Locking ripple wave & energetic sparkles in Blue, Orange, Green, and Gold
    if (tAdj > 0.72 && tAdj < 1.7) {
      const pR = clamp((tAdj - 0.72) / 0.95);
      ctx.save();
      // Ripple ring 1: Warm Sand / Gold
      ctx.strokeStyle = hexToRgba('#DFCEB5', (1 - pR) * 0.9);
      ctx.lineWidth = (3.0 - pR * 2.2) * scale;
      ctx.beginPath();
      ctx.arc(emblemCenterX, emblemCenterY, (emblemW * 0.32) + pR * 90 * scale, 0, Math.PI * 2);
      ctx.stroke();

      // Ripple ring 2: Energetic Blue
      ctx.strokeStyle = hexToRgba('#1E88E5', (1 - pR) * 0.7);
      ctx.lineWidth = (2.2 - pR * 1.6) * scale;
      ctx.beginPath();
      ctx.arc(emblemCenterX, emblemCenterY, (emblemW * 0.26) + pR * 70 * scale, 0, Math.PI * 2);
      ctx.stroke();

      // Sparkle dots in Green, Orange, and Blue
      const sparkColors = ['#00C853', '#FF7A00', '#1E88E5', '#DFCEB5'];
      for (let s = 0; s < 14; s++) {
        const sAngle = (s / 14) * Math.PI * 2 + pR * 0.4;
        const sDist = (emblemW * 0.35) + pR * (65 + (s % 3) * 30) * scale;
        const sx = emblemCenterX + Math.cos(sAngle) * sDist;
        const sy = emblemCenterY + Math.sin(sAngle) * sDist * 0.7;
        const sAlpha = (1 - pR) * 0.85;
        ctx.fillStyle = hexToRgba(sparkColors[s % sparkColors.length], sAlpha);
        ctx.beginPath();
        ctx.arc(sx, sy, (3.0 - pR * 2.0) * scale, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // 4. "Logo KECUALI tulisan": Logo text reveals cleanly AFTER emblem pieces lock together!
    if (isWideLogoWithText && tAdj > 0.65) {
      const pText = clamp((tAdj - 0.65) / 0.65);
      const easeT = 1 - Math.pow(1 - pText, 3);
      const textAlpha = clamp(pText * 1.5);
      const textSlide = (1 - easeT) * 16 * scale;

      ctx.save();
      ctx.globalAlpha = textAlpha;
      ctx.translate(textSlide, 0);

      ctx.save();
      ctx.beginPath();
      // Safe clipping bounds: starts exactly at emblemX1 without slicing any text letter
      const textW = (logoW / 2 - emblemX1) + 40 * scale;
      ctx.rect(emblemX1 - 2 * scale, -logoH / 2 - 20 * scale, textW, logoH + 40 * scale);
      ctx.clip();

      if (customImg) {
        ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
      } else {
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#FFFFFF';
        ctx.font = `800 ${logoH * 0.28}px "Plus Jakarta Sans", sans-serif`;
        drawLetterSpacedTextLeft(ctx, 'N  U  S  A', emblemX1 + 18 * scale, -logoH * 0.26, 3.0);
        ctx.font = `700 ${logoH * 0.22}px "Plus Jakarta Sans", sans-serif`;
        drawLetterSpacedTextLeft(ctx, 'KONSTRUKSI', emblemX1 + 18 * scale, 0.02 * logoH, 1.4);
        drawLetterSpacedTextLeft(ctx, 'ENJINIRING', emblemX1 + 18 * scale, 0.30 * logoH, 1.6);
      }
      ctx.restore();
      ctx.restore();
    }

    // 5. Specular shine sweep across assembled logo
    if (tAdj > 1.0 && tAdj < 2.0) {
      const pF = clamp((tAdj - 1.0) / 0.95);
      const fX = (pF * 2 - 1) * (logoW * 0.9);
      ctx.save();
      ctx.translate(fX, 0);
      const fGrad = ctx.createLinearGradient(-logoW * 0.35, 0, logoW * 0.35, 0);
      fGrad.addColorStop(0, 'rgba(255,255,255,0)');
      fGrad.addColorStop(0.5, `rgba(255, 255, 255, ${Math.sin(pF * Math.PI) * 0.90})`);
      fGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fGrad;
      ctx.fillRect(-logoW * 0.35, -3 * scale, logoW * 0.7, 6 * scale);
      ctx.restore();
    }

    ctx.restore();
  } else if (animType === 'faded' || animType === 'minimalist_soft_fade') {
    // B. FADED: Smooth cinematic blur fade with soft scale expansion
    const pFade = clamp(tAdj / 0.95);
    const easeFade = easeOutCubic(pFade);
    const sLogo = 0.92 + 0.08 * easeFade;
    const aLogo = clamp(pFade * 1.5);

    ctx.save();
    ctx.scale(sLogo, sLogo);
    ctx.globalAlpha = aLogo;

    if (customImg) {
      ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
    } else if (isNke) {
      drawLogo1NKE(ctx, 0, 0, logoH, logoW);
    } else {
      drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
    }
    ctx.restore();
  } else if (animType === 'come_from_anywhere') {
    // =========================================================================
    // C. COME FROM EVERYWHERE: EFEK ANGIN MEMBUKA STIKER LOGO (WIND STICKER PEEL)
    // - Angin berhembus kencang membuka gulungan stiker logo dari kiri ke kanan
    // - Full logo visibility at all times (tidak ada bagian yang kepotong)
    // - Sisi kiri menempel kuat pada kanvas, sisi kanan berkibar aerodinamis
    // - Disertai hembusan garis angin, debu partikel, lekukan silinder vinil, dan kilau gloss
    // =========================================================================
    const pPeel = clamp(tAdj / 1.05);
    const easePeel = 1 - Math.pow(1 - pPeel, 3); // easeOutCubic

    // 1. Wind Gust Streamlines & Breeze Particles
    ctx.save();
    if (tAdj < 1.6) {
      const gustFade = clamp(tAdj < 0.9 ? 1.0 : (1.6 - tAdj) / 0.7);
      // Aerodynamic wind streamlines flowing left to right
      for (let wIdx = 0; wIdx < 8; wIdx++) {
        const streamProgress = ((tAdj * 1.15 + wIdx * 0.14) % 1.0);
        const streamX = -logoW * 1.3 + streamProgress * (logoW * 2.6);
        const streamY = (wIdx - 3.5) * (logoH * 0.26) + Math.sin(tAdj * 7.0 + wIdx * 2.0) * 8 * scale;
        const streamLen = (120 + (wIdx % 3) * 65) * scale;

        ctx.save();
        const sGrad = ctx.createLinearGradient(streamX - streamLen, streamY, streamX, streamY);
        sGrad.addColorStop(0, 'rgba(255,255,255,0)');
        sGrad.addColorStop(0.5, `rgba(223, 206, 181, ${0.45 * gustFade})`);
        sGrad.addColorStop(1, `rgba(255, 255, 255, ${0.75 * gustFade})`);
        ctx.strokeStyle = sGrad;
        ctx.lineWidth = (1.5 + (wIdx % 2) * 1.2) * scale;
        ctx.beginPath();
        ctx.moveTo(streamX - streamLen, streamY);
        ctx.bezierCurveTo(
          streamX - streamLen * 0.5, streamY - 8 * scale,
          streamX - streamLen * 0.2, streamY + 8 * scale,
          streamX, streamY
        );
        ctx.stroke();
        ctx.restore();
      }

      // Wind dust / airborne breeze particles
      for (let pt = 0; pt < 16; pt++) {
        const pSpeed = 1.0 + (pt % 4) * 0.35;
        const ptX = (((tAdj * 650 * pSpeed + pt * 70) % (logoW * 2.6)) - logoW * 1.3);
        const ptY = ((pt * 39) % Math.floor(logoH * 1.2)) - logoH * 0.6 + Math.sin(tAdj * 15 + pt) * 6 * scale;
        const pAlpha = Math.sin(clamp((ptX + logoW * 1.3) / (logoW * 2.6)) * Math.PI) * 0.55 * gustFade;
        ctx.fillStyle = `rgba(255, 255, 255, ${pAlpha})`;
        ctx.fillRect(ptX, ptY, (8 + (pt % 3) * 6) * scale, 1.4 * scale);
      }
    }
    ctx.restore();

    // 2. Wind Sticker Peel Mechanics
    const startX = -logoW / 2;
    const endX = logoW / 2 + 10 * scale;
    const peelX = startX + easePeel * (endX - startX);

    // Damped aerodynamic turbulence wave: decays smoothly to exactly 0 as easePeel -> 1.0
    const decay = Math.pow(Math.max(0, 1 - easePeel), 1.6);
    const flutterWave = Math.sin(tAdj * 22) * decay * 14 * scale;
    const flapRot = -(1 - easePeel) * 0.10 + Math.sin(tAdj * 18) * decay * 0.04;
    const curlWidth = Math.max(0, decay * 38 * scale + Math.sin(easePeel * Math.PI) * 26 * scale);

    ctx.save();

    // A. EXPOSED BASE (Flattened and firmly adhered to canvas by wind)
    const baseW = Math.max(0, peelX - startX);
    if (baseW > 0.5) {
      ctx.save();
      ctx.beginPath();
      // Safe padding bounds so no edge of logo is sliced
      ctx.rect(startX - 20 * scale, -logoH / 2 - 20 * scale, baseW + 20 * scale, logoH + 40 * scale);
      ctx.clip();

      if (customImg) {
        ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
      } else if (isNke) {
        drawLogo1NKE(ctx, 0, 0, logoH, logoW);
      } else {
        drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
      }
      ctx.restore();
    }

    // B. CURLED FLAP & CYLINDER ADHESIVE BACKING (at peel front)
    if (easePeel < 0.99 && curlWidth > 1) {
      // Drop shadow cast by the curl onto the surface
      ctx.save();
      const shadowGrad = ctx.createLinearGradient(peelX, 0, peelX + curlWidth * 1.25, 0);
      shadowGrad.addColorStop(0, 'rgba(0, 0, 0, 0.42)');
      shadowGrad.addColorStop(0.5, 'rgba(0, 0, 0, 0.15)');
      shadowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = shadowGrad;
      ctx.fillRect(peelX, -logoH / 2 - 10 * scale, curlWidth * 1.25, logoH + 20 * scale);
      ctx.restore();

      // Curled vinyl backing flap
      const flapLeft = peelX - curlWidth;
      const flapTopY = -logoH / 2 + flutterWave;
      const flapBottomY = logoH / 2 - flutterWave * 0.5;

      ctx.save();
      const backGrad = ctx.createLinearGradient(flapLeft, 0, peelX, 0);
      backGrad.addColorStop(0.0, '#94A3B8'); // shadow rim
      backGrad.addColorStop(0.25, '#FFFFFF'); // specular highlight catching wind light!
      backGrad.addColorStop(0.65, '#E2E8F0'); // smooth vinyl backing
      backGrad.addColorStop(0.92, '#94A3B8'); // crease shadow
      backGrad.addColorStop(1.0, '#475569'); // tight fold line

      ctx.fillStyle = backGrad;
      ctx.beginPath();
      ctx.moveTo(peelX, -logoH / 2);
      ctx.bezierCurveTo(
        peelX - curlWidth * 0.4, -logoH / 2 + flutterWave * 0.4,
        flapLeft + curlWidth * 0.2, flapTopY,
        flapLeft, flapTopY
      );
      ctx.lineTo(flapLeft, flapBottomY);
      ctx.bezierCurveTo(
        flapLeft + curlWidth * 0.2, flapBottomY,
        peelX - curlWidth * 0.4, logoH / 2 - flutterWave * 0.3,
        peelX, logoH / 2
      );
      ctx.closePath();
      ctx.fill();

      // Curled flap outer rim stroke
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.lineWidth = 1.2 * scale;
      ctx.stroke();

      // Specular ridge glint along the fold crease
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.95)';
      ctx.lineWidth = 2.0 * scale;
      ctx.beginPath();
      ctx.moveTo(peelX, -logoH / 2 - 4 * scale);
      ctx.lineTo(peelX, logoH / 2 + 4 * scale);
      ctx.stroke();
      ctx.restore();
    }

    // C. LIFTED FLAP (Right of peelX): Fluttering in the wind with 3D perspective and shadow
    // Ensures the entire logo is always visible and never cut off in half!
    if (easePeel < 0.99 && peelX < logoW / 2) {
      const unpeeledW = (logoW / 2 - peelX) + 30 * scale;
      ctx.save();
      ctx.beginPath();
      // Safe clip to the right region with generous bounds
      ctx.rect(peelX, -logoH / 2 - 60 * scale, unpeeledW, logoH + 120 * scale);
      ctx.clip();

      // Aerodynamic flutter transform pivoted at peelX
      ctx.translate(peelX, 0);
      ctx.rotate(flapRot);
      ctx.translate(-peelX, flutterWave * 0.4);

      // Soft floating drop shadow beneath lifted flap
      ctx.shadowColor = 'rgba(0, 0, 0, 0.30)';
      ctx.shadowBlur = 14 * scale * decay;
      ctx.shadowOffsetY = 6 * scale * decay;

      if (customImg) {
        ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
      } else if (isNke) {
        drawLogo1NKE(ctx, 0, 0, logoH, logoW);
      } else {
        drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
      }
      ctx.restore();
    }

    // D. FULLY SETTLED STICKER: Crisp pristine render with microscopic elastic settle
    if (easePeel >= 0.99) {
      const pSettle = clamp((tAdj - 1.05) / 0.40);
      const sSettle = 1.0 + 0.015 * (1 - pSettle) * Math.sin(pSettle * Math.PI * 2);

      ctx.save();
      ctx.scale(sSettle, sSettle);
      if (customImg) {
        ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
      } else if (isNke) {
        drawLogo1NKE(ctx, 0, 0, logoH, logoW);
      } else {
        drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
      }
      ctx.restore();
    }

    // E. ANAMORPHIC GLOSS SWEEP (when sticker finishes settling flat)
    if (tAdj > 1.05 && tAdj < 2.2) {
      const pF = clamp((tAdj - 1.05) / 0.95);
      const fX = (pF * 2 - 1) * (logoW * 0.9);
      ctx.save();
      ctx.translate(fX, 0);
      const fGrad = ctx.createLinearGradient(-logoW * 0.35, 0, logoW * 0.35, 0);
      fGrad.addColorStop(0, 'rgba(255,255,255,0)');
      fGrad.addColorStop(0.5, `rgba(255, 255, 255, ${Math.sin(pF * Math.PI) * 0.92})`);
      fGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fGrad;
      ctx.fillRect(-logoW * 0.35, -3 * scale, logoW * 0.7, 6 * scale);
      ctx.restore();
    }

    ctx.restore();
  } else if (animType === 'smooth_zoom_flare') {
    // Smooth Zoom & Flare
    const pZoom = clamp(tAdj / 0.85);
    const easeZoom = easeOutCubic(pZoom);
    const sLogo = 0.78 + 0.22 * easeZoom;
    const aLogo = clamp(pZoom * 1.6);

    ctx.save();
    ctx.scale(sLogo, sLogo);
    ctx.globalAlpha = aLogo;

    if (customImg) {
      ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
    } else if (isNke) {
      drawLogo1NKE(ctx, 0, 0, logoH, logoW);
    } else {
      drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
    }

    // Flare Sweep
    if (tAdj > 0.8 && tAdj < 1.9) {
      const pF = clamp((tAdj - 0.8) / 0.9);
      const fX = (pF * 2 - 1) * (logoW * 0.9);
      ctx.save();
      ctx.translate(fX, 0);
      const fGrad = ctx.createLinearGradient(-logoW * 0.35, 0, logoW * 0.35, 0);
      fGrad.addColorStop(0, 'rgba(255,255,255,0)');
      fGrad.addColorStop(0.5, `rgba(255,255,255,${Math.sin(pF * Math.PI) * 0.9})`);
      fGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fGrad;
      ctx.fillRect(-logoW * 0.35, -2 * scale, logoW * 0.7, 4 * scale);
      ctx.restore();
    }
    ctx.restore();
  } else if (animType === 'flip_3d_reveal') {
    // 3. 3D Isometric Flip & Glow
    const pFlip = clamp(tAdj / 0.95);
    const easeFlip = easeOutCubic(pFlip);
    const flipAngle = (1 - easeFlip) * Math.PI * 0.5;
    const sFlip = 0.75 + 0.25 * easeFlip;

    ctx.save();
    ctx.scale(Math.cos(flipAngle) * sFlip, sFlip);
    ctx.globalAlpha = clamp(pFlip * 1.8);

    if (customImg) {
      ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
    } else if (isNke) {
      drawLogo1NKE(ctx, 0, 0, logoH, logoW);
    } else {
      drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
    }
    ctx.restore();
  } else if (animType === 'elastic_snap_pulse') {
    // 4. Elastic Snap & Pulse Ring
    const pSnap = clamp(tAdj / 0.80);
    const easeSnap = easeOutBack(pSnap);
    const sSnap = 0.5 + 0.5 * easeSnap;

    ctx.save();
    ctx.scale(sSnap, sSnap);
    ctx.globalAlpha = clamp(pSnap * 1.6);

    if (customImg) {
      ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
    } else if (isNke) {
      drawLogo1NKE(ctx, 0, 0, logoH, logoW);
    } else {
      drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
    }
    ctx.restore();

    // Shockwave Rings
    if (tAdj > 0.5 && tAdj < 1.7) {
      const pR = clamp((tAdj - 0.5) / 1.0);
      const ringR = (logoH * 0.6) + pR * 140 * scale;
      const ringAlpha = (1 - pR) * 0.8;
      ctx.save();
      ctx.strokeStyle = `rgba(223, 206, 181, ${ringAlpha})`;
      ctx.lineWidth = (3 - pR * 2) * scale;
      ctx.beginPath();
      ctx.arc(0, 0, ringR, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  } else if (animType === 'matrix_scan_reveal') {
    // 5. Digital Matrix Scan Reveal
    const pScan = clamp(tAdj / 1.0);
    const easeScan = easeOutCubic(pScan);

    ctx.save();
    const clipH = logoH * easeScan;
    ctx.beginPath();
    ctx.rect(-logoW, -logoH / 2, logoW * 2, clipH);
    ctx.clip();

    if (customImg) {
      ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
    } else if (isNke) {
      drawLogo1NKE(ctx, 0, 0, logoH, logoW);
    } else {
      drawNkeEmblemDirect(ctx, -logoW / 2, -logoH / 2, logoH / 2, logoW / 2, logoW / 2, scale);
    }

    // Laser Line at the cutting edge
    const edgeY = -logoH / 2 + clipH;
    ctx.strokeStyle = 'rgba(223, 206, 181, 0.95)';
    ctx.lineWidth = 2 * scale;
    ctx.beginPath();
    ctx.moveTo(-logoW * 0.7, edgeY);
    ctx.lineTo(logoW * 0.7, edgeY);
    ctx.stroke();

    ctx.restore();
  } else {
    // 1. DEFAULT: NKE Triangles Assemble OR Multi-phase Pop
    if (!customImg && isNke) {
      // Procedural Triangles Assemble
      const pGreen = clamp(tAdj / 0.55);
      const pBlue = clamp((tAdj - 0.38) / 0.55);
      const pYellow = clamp((tAdj - 0.75) / 0.55);

      const greenW = logoW / 2;
      const rectW = logoW / 2;
      const startX = -logoW / 2;
      const topY = -logoH / 2;
      const botY = logoH / 2;

      // Green Triangle
      if (pGreen > 0) {
        const sGreen = 0.6 + 0.4 * easeOutBack(pGreen);
        ctx.save();
        ctx.translate(startX + greenW / 2, botY);
        ctx.scale(sGreen, sGreen);
        ctx.translate(-(startX + greenW / 2), -botY);
        ctx.globalAlpha = clamp(pGreen * 1.8);
        ctx.fillStyle = '#12A727';
        ctx.beginPath();
        ctx.moveTo(startX, botY);
        ctx.lineTo(startX + greenW, topY);
        ctx.lineTo(startX + greenW, botY);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.7)';
        ctx.lineWidth = 1.2 * scale;
        ctx.stroke();
        ctx.restore();
      }

      // Blue Triangle
      if (pBlue > 0) {
        const sBlue = 0.6 + 0.4 * easeOutBack(pBlue);
        const emblemEnd = startX + greenW + rectW;
        ctx.save();
        ctx.translate(startX + greenW + rectW / 2, 0);
        ctx.scale(sBlue, sBlue);
        ctx.translate(-(startX + greenW + rectW / 2), 0);
        ctx.globalAlpha = clamp(pBlue * 1.8);
        ctx.fillStyle = '#144DFF';
        ctx.beginPath();
        ctx.moveTo(startX + greenW, topY);
        ctx.lineTo(startX + greenW, botY);
        ctx.lineTo(emblemEnd, botY);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.7)';
        ctx.lineWidth = 1.2 * scale;
        ctx.stroke();
        ctx.restore();
      }

      // Yellow/Amber Triangle
      if (pYellow > 0) {
        const sYellow = 0.6 + 0.4 * easeOutBack(pYellow);
        const emblemEnd = startX + greenW + rectW;
        ctx.save();
        ctx.translate(startX + greenW + rectW / 2, 0);
        ctx.scale(sYellow, sYellow);
        ctx.translate(-(startX + greenW + rectW / 2), 0);
        ctx.globalAlpha = clamp(pYellow * 1.8);
        ctx.fillStyle = '#FFB51C';
        ctx.beginPath();
        ctx.moveTo(startX + greenW, topY);
        ctx.lineTo(emblemEnd, topY);
        ctx.lineTo(emblemEnd, botY);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.7)';
        ctx.lineWidth = 1.2 * scale;
        ctx.stroke();
        ctx.restore();
      }
    } else {
      // Image based pop with elastic bounce
      const pImg = clamp(tAdj / 0.85);
      const easeImg = easeOutBack(pImg);
      const scaleImg = 0.75 + 0.25 * easeImg;
      ctx.save();
      ctx.scale(scaleImg, scaleImg);
      ctx.globalAlpha = clamp(pImg * 1.5);
      if (customImg) {
        ctx.drawImage(customImg, -logoW / 2, -logoH / 2, logoW, logoH);
      } else {
        drawLogo1NKE(ctx, 0, 0, logoH, logoW);
      }
      ctx.restore();
    }

    // Anamorphic flare sweep across the formed emblem
    if (tAdj > 1.2 && tAdj < 2.1) {
      const pFlare = clamp((tAdj - 1.2) / 0.85);
      const flareX = (pFlare * 2 - 1) * (logoW * 0.9);
      const flareA = Math.sin(pFlare * Math.PI) * 0.9;
      ctx.save();
      ctx.translate(flareX, 0);
      const fGrad = ctx.createLinearGradient(-logoW * 0.4, 0, logoW * 0.4, 0);
      fGrad.addColorStop(0, 'rgba(255,255,255,0)');
      fGrad.addColorStop(0.5, `rgba(255,255,255,${flareA})`);
      fGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fGrad;
      ctx.fillRect(-logoW * 0.4, -3 * scale, logoW * 0.8, 6 * scale);
      ctx.restore();
    }
  }

  // ---------------------------------------------------------
  // LOGO TEXT / TITLE ON RIGHT SIDE (ONLY IF hasTitle)
  // ---------------------------------------------------------
  if (alphaText > 0 && hasTitle) {
    const logoRightEdge = logoW / 2;
    const dividerX = logoRightEdge + 24 * scale;
    const textStartX = dividerX + 22 * scale;
    const textSlide = (1 - easeText) * 26 * scale;

    ctx.save();
    ctx.globalAlpha = alphaText;

    // Glowing Divider
    const divH = logoH * 0.72 * easeText;
    const divGrad = ctx.createLinearGradient(0, -divH, 0, divH);
    divGrad.addColorStop(0, 'rgba(255,255,255,0)');
    divGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.95)');
    divGrad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.strokeStyle = divGrad;
    ctx.lineWidth = 2.0 * scale;
    ctx.beginPath();
    ctx.moveTo(dividerX, -divH);
    ctx.lineTo(dividerX, divH);
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';

    const fontFam = cfg.singleLogoTitleFont || cfg.bumperTitleFont || cfg.fontFamily || 'Plus Jakarta Sans';
    const titleCol = cfg.singleLogoTitleColor || cfg.titleColor || '#FFFFFF';
    const fs = (cfg.singleLogoTitleSize || 28) * scale;

    ctx.font = `800 ${fs}px "${fontFam}", sans-serif`;
    ctx.fillStyle = 'rgba(0,0,0,0.85)';
    ctx.fillText(titleText, textStartX + textSlide, 2 * scale);
    ctx.fillStyle = titleCol;
    ctx.fillText(titleText, textStartX + textSlide, 0);

    // Subtitle if provided
    const subText = (cfg.singleLogoSubtitle || cfg.subtitle || '').trim();
    if (subText) {
      ctx.font = `700 ${fs * 0.42}px "${fontFam}", sans-serif`;
      ctx.fillStyle = hexToRgba(titleCol, 0.85);
      ctx.fillText(subText, textStartX + textSlide, fs * 0.75);
    }

    ctx.restore();
  }

  ctx.restore();
}

/**
 * Direct drawing of complete NKE emblem vector
 */
function drawNkeEmblemDirect(
  ctx: CanvasRenderingContext2D,
  startX: number,
  topY: number,
  botY: number,
  greenW: number,
  rectW: number,
  scale: number
) {
  const emblemEnd = startX + greenW + rectW;

  // Green
  ctx.fillStyle = '#12A727';
  ctx.beginPath();
  ctx.moveTo(startX, botY);
  ctx.lineTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.closePath();
  ctx.fill();

  // Blue
  ctx.fillStyle = '#144DFF';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  // Yellow
  ctx.fillStyle = '#FFB51C';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(emblemEnd, topY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = 'rgba(255,255,255,0.7)';
  ctx.lineWidth = 1.2 * scale;
  ctx.stroke();
}

/**
 * Color Tone (Color Grading) Engine
 */
function applyColorTone(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  tone?: string
) {
  if (!tone || tone === 'none') return;

  ctx.save();
  if (tone === 'warm_cinematic') {
    ctx.globalCompositeOperation = 'soft-light';
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, 'rgba(245, 158, 11, 0.35)');
    grad.addColorStop(1, 'rgba(180, 83, 9, 0.45)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'cool_tech') {
    ctx.globalCompositeOperation = 'soft-light';
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, 'rgba(14, 165, 233, 0.35)');
    grad.addColorStop(1, 'rgba(3, 105, 161, 0.45)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'cyber_neon') {
    ctx.globalCompositeOperation = 'screen';
    const grad = ctx.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, 'rgba(6, 182, 212, 0.22)');
    grad.addColorStop(1, 'rgba(217, 70, 239, 0.22)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'emerald_signature') {
    ctx.globalCompositeOperation = 'soft-light';
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, 'rgba(16, 185, 129, 0.35)');
    grad.addColorStop(1, 'rgba(234, 179, 8, 0.30)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'sunset_amber') {
    ctx.globalCompositeOperation = 'color-dodge';
    const grad = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.7);
    grad.addColorStop(0, 'rgba(249, 115, 22, 0.25)');
    grad.addColorStop(1, 'rgba(124, 45, 18, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'noir_luxe') {
    ctx.globalCompositeOperation = 'saturation';
    ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
    ctx.fillRect(0, 0, w, h);
    ctx.globalCompositeOperation = 'soft-light';
    ctx.fillStyle = 'rgba(217, 119, 6, 0.25)';
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

/**
 * ==============================================================================
 * MODE 1: MASTER BUMPER LOGO PRESENTATION
 * Supports:
 * a. Multiple Logo (Up to 2 logos with sequential reveal, dividers, and slide left)
 * b. Single Logo (Hero centered, triangle pieces assemble, slide left, text reveal)
 * ==============================================================================
 */
function renderMasterPresentation(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number,
  speed: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const dur = Math.max(1, cfg.duration);
  const scale = Math.min(w, h) / 1000;
  const tAdj = t * speed;

  const cameraZoom = 1.0 + 0.025 * clamp(t / dur);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(cameraZoom, cameraZoom);

  const primaryTitleColor = cfg.titleColor || cfg.primaryColor || '#FFFFFF';
  const secColor = cfg.secondaryColor || '#DF9B35';
  const isSingleLogo = cfg.logoCountMode === 'single';

  // ===========================================================================
  // SUB-MODE A: SINGLE LOGO (Hero Center, Segmented Triangles, Slide Left, Logo Text Reveal)
  // ===========================================================================
  if (isSingleLogo) {
    renderSingleLogoSlicedAssemble(ctx, w, h, cfg, tAdj, scale, secColor);
    ctx.restore();
    return;
  }

  // ===========================================================================
  // SUB-MODE B: MULTIPLE LOGO (Supports Dynamic Active Logos - No ghost slots!)
  // ===========================================================================
  const targetH = 54 * scale;
  const rawLogos = (cfg.bumperLogos && cfg.bumperLogos.length > 0)
    ? cfg.bumperLogos
    : [
        { id: '1', enabled: true, name: 'Nusa Konstruksi', url: '/assets/aistudio/kso_nke_hd.png' },
        { id: '2', enabled: true, name: 'Jaya Konstruksi', url: '/assets/aistudio/kso_jaya_hd.png' },
      ];

  // Strictly filter only active enabled logos with an image or name
  const activeSlots = rawLogos.filter((s) => s.enabled && (s.url || s.name));

  const logoItems = activeSlots.map((slot) => {
    const img = slot.url ? getCachedImage(slot.url) : null;
    let aspect = 1.5;
    if (img && img.naturalHeight > 0) {
      aspect = img.naturalWidth / img.naturalHeight;
    } else if (slot.url?.includes('kso_nke') || slot.name?.toLowerCase().includes('nke')) {
      aspect = 1800 / 362;
    } else if (slot.url?.includes('jaya')) {
      aspect = 1.0;
    } else if (slot.url?.includes('wiswa')) {
      aspect = 1.0;
    }
    const lw = targetH * aspect;
    return { slot, img, aspect, w: lw };
  });

  const gap = 32 * scale;
  const totalLogosW = logoItems.reduce((acc, it) => acc + it.w, 0) + Math.max(0, logoItems.length - 1) * gap;
  const startX = -totalLogosW / 2;

  // Calculate coordinates for active logos and dividers
  let currentLeft = startX;
  const positionedLogos: { x: number; w: number; slot: any; img: any; idx: number }[] = [];

  logoItems.forEach((it, idx) => {
    const xCenter = currentLeft + it.w / 2;
    positionedLogos.push({ x: xCenter, w: it.w, slot: it.slot, img: it.img, idx });
    currentLeft += it.w;
    if (idx < logoItems.length - 1) {
      currentLeft += gap;
    }
  });

  const displayTitle = (cfg.title || '').trim();
  const isSlideLeft = (cfg.transitionStyle || 'slide_left') === 'slide_left' && cfg.aspectRatio !== '9:16';
  const shouldSlide = displayTitle.length > 0 && isSlideLeft;

  // Stagger timing: Logo muncul SATU PER SATU secara berurutan, TANPA PERNAH BERTUMPUK!
  // Setiap logo masuk langsung ke posisinya masing-masing dengan jeda berurutan dan pop elastis
  const stepDur = 0.65;
  const lastLogoIdx = Math.max(0, positionedLogos.length - 1);
  const allLogosArrivedTime = 0.20 + lastLogoIdx * stepDur + 0.45;

  const pClusterSlide = clamp((tAdj - (allLogosArrivedTime + 0.15)) / 0.85);
  const easeClusterSlide = easeOutCubic(pClusterSlide);

  let clusterX = 0;
  let clusterY = 0;

  if (shouldSlide) {
    const targetLeftX = -Math.min(w * 0.22, (totalLogosW / 2 + 100 * scale));
    clusterX = targetLeftX * easeClusterSlide;
  } else if ((cfg.transitionStyle || 'slide_left') === 'slide_up' && displayTitle.length > 0) {
    const targetUpY = -70 * scale;
    clusterY = targetUpY * easeClusterSlide;
  }

  // Anamorphic Lens Flare in Warm Sand when all logos have arrived
  if (cfg.anamorphicFlare !== false && tAdj > (allLogosArrivedTime - 0.2) && tAdj < (allLogosArrivedTime + 1.2)) {
    const flareP = clamp((tAdj - (allLogosArrivedTime - 0.2)) / 1.1);
    const flareX = (flareP * 2.2 - 1.1) * (w * 0.45);
    const flareAlpha = Math.sin(flareP * Math.PI) * 0.85;

    ctx.save();
    ctx.translate(clusterX + flareX, clusterY);
    const beamGrad = ctx.createLinearGradient(-w * 0.4, 0, w * 0.4, 0);
    beamGrad.addColorStop(0, 'rgba(255,255,255,0)');
    beamGrad.addColorStop(0.35, hexToRgba('#DFCEB5', flareAlpha * 0.35));
    beamGrad.addColorStop(0.5, `rgba(255,255,255,${flareAlpha * 0.95})`);
    beamGrad.addColorStop(0.65, hexToRgba('#DFCEB5', flareAlpha * 0.35));
    beamGrad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = beamGrad;
    ctx.fillRect(-w * 0.4, -3 * scale, w * 0.8, 6 * scale);
    ctx.restore();
  }

  ctx.save();
  ctx.translate(clusterX, clusterY);

  // Render each active logo: MUNCUL SATU-SATU BERURUTAN (TIDAK BERTUMPUK!)
  positionedLogos.forEach((pl) => {
    const tAppear = 0.20 + pl.idx * stepDur;
    if (tAdj < tAppear) {
      return; // Belum muncul
    }

    const pPop = clamp((tAdj - tAppear) / 0.45);
    const scaleLogo = 0.72 + 0.28 * easeOutBack(pPop);
    const alphaLogo = clamp(pPop * 1.8);
    const curLogoX = pl.x; // Posisi langsung pada slotnya, aman terpisah gap tanpa pernah tumpang-tindih

    // Soft Warm Sand halo at slot while popping in
    if (pPop > 0.05 && pPop < 0.95) {
      ctx.save();
      const popHalo = ctx.createRadialGradient(curLogoX, 0, 0, curLogoX, 0, targetH * 1.1);
      popHalo.addColorStop(0, hexToRgba('#DFCEB5', 0.35 * alphaLogo));
      popHalo.addColorStop(0.6, hexToRgba('#5C1018', 0.15 * alphaLogo));
      popHalo.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = popHalo;
      ctx.beginPath();
      ctx.arc(curLogoX, 0, targetH * 1.1, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.save();
    ctx.translate(curLogoX, 0);
    ctx.scale(scaleLogo, scaleLogo);
    ctx.globalAlpha = alphaLogo;

    if (pl.img) {
      const aspect = pl.img.naturalWidth / pl.img.naturalHeight;
      const dw = targetH * aspect;
      ctx.drawImage(pl.img, -dw / 2, -targetH / 2, dw, targetH);
    } else if (pl.slot.url?.includes('kso_nke') || pl.slot.name?.toLowerCase().includes('nke')) {
      drawLogo1NKE(ctx, 0, 0, targetH, pl.w);
    } else if (pl.slot.url?.includes('jaya') || pl.slot.name?.toLowerCase().includes('jaya')) {
      drawLogo2Jaya(ctx, 0, 0, targetH, pl.w);
    } else if (pl.slot.url?.includes('wiswa') || pl.slot.name?.toLowerCase().includes('wiswa')) {
      drawLogo3Wiswa(ctx, 0, 0, targetH, pl.w);
    } else {
      ctx.fillStyle = '#FFFFFF';
      ctx.font = `700 ${14 * scale}px "Plus Jakarta Sans", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(pl.slot.name, 0, 0);
    }
    ctx.restore();
  });

  // Render dividers strictly between active logos once the adjacent logo enters
  for (let idx = 0; idx < positionedLogos.length - 1; idx++) {
    const nextLogoAppear = 0.20 + (idx + 1) * stepDur;
    const pDiv = clamp((tAdj - nextLogoAppear) / 0.38);

    if (pDiv > 0) {
      const x1 = positionedLogos[idx].x + positionedLogos[idx].w / 2;
      const x2 = positionedLogos[idx + 1].x - positionedLogos[idx + 1].w / 2;
      const divX = (x1 + x2) / 2;
      const divH = targetH * 0.5 * easeOutCubic(pDiv);

      ctx.save();
      ctx.strokeStyle = hexToRgba('#DFCEB5', 0.85);
      ctx.lineWidth = 1.5 * scale;
      ctx.globalAlpha = clamp(pDiv * 1.5);
      ctx.beginPath();
      ctx.moveTo(divX, -divH);
      ctx.lineTo(divX, divH);
      ctx.stroke();
      ctx.restore();
    }
  }


  ctx.restore();

  // ===========================================================================
  // OPTIONAL TITLE FOR MULTIPLE LOGO (Revealed after logos settle)
  // ===========================================================================
  const pText = clamp((tAdj - (allLogosArrivedTime + 0.20)) / 0.85);
  const easeText = easeOutCubic(pText);
  const alphaText = clamp(pText * 1.3);

  if (displayTitle && alphaText > 0 && activeSlots.length > 0) {
    ctx.save();
    ctx.globalAlpha = alphaText;

    const titleFont = cfg.bumperTitleFont || cfg.fontFamily || 'Outfit';

    if (isSlideLeft) {
      const logoRightEdge = clusterX + totalLogosW / 2;
      const midDividerX = logoRightEdge + 25 * scale;

      const beamHeight = 58 * scale * easeText;
      ctx.save();
      const divBeamGrad = ctx.createLinearGradient(0, -beamHeight, 0, beamHeight);
      divBeamGrad.addColorStop(0, 'rgba(255,255,255,0)');
      divBeamGrad.addColorStop(0.5, hexToRgba(secColor, 0.9));
      divBeamGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = divBeamGrad;
      ctx.lineWidth = 2 * scale;
      ctx.beginPath();
      ctx.moveTo(midDividerX, -beamHeight);
      ctx.lineTo(midDividerX, beamHeight);
      ctx.stroke();
      ctx.restore();

      const textSlideOffset = (1 - easeText) * 32 * scale;
      const textStartX = midDividerX + 24 * scale + textSlideOffset;

      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';

      const fontSize1 = 26 * scale * (cfg.fontSize || 1.0);
      ctx.font = `800 ${fontSize1}px "${titleFont}", sans-serif`;

      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText(displayTitle, textStartX, 2 * scale);

      ctx.fillStyle = primaryTitleColor;
      ctx.fillText(displayTitle, textStartX, 0);
    } else {
      const titleY = 46 * scale;
      const fontSize = 34 * scale * (cfg.fontSize || 1.0);
      ctx.font = `800 ${fontSize}px "${titleFont}", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText(displayTitle, 0, titleY + 3 * scale);

      ctx.fillStyle = primaryTitleColor;
      ctx.fillText(displayTitle, 0, titleY);
    }
    ctx.restore();
  }

  ctx.restore();
}

/**
 * ==============================================================================
 * MODE 2: VIDEO TITLE SCREEN
 * Directly matched from the reference user image (image_737631e5.png):
 * - Radiant Golden Tree of Life (Pohon Hayat IKN) emblem with ambient breathing halo
 * - Category Overline ("SIMULASI KONSTRUKSI")
 * - Main Bold Title ("PEMBANGUNAN")
 * - Secondary Subtitle ("HUNIAN VERTIKAL NEGARA")
 * - Pill Tag Badge ("TIPE 65")
 * - Location Footer ("DI IBU KOTA NUSANTARA")
 * - Precision bottom horizon line with partner icons
 * ==============================================================================
 */
function renderVideoTitleMode(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number,
  speed: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const scale = Math.min(w, h) / 1000;
  const tAdj = t * speed;

  const accentColor = cfg.accentColor || '#DFCEB5';
  const goldColor = cfg.secondaryColor || '#DFCEB5';

  const titleFont = cfg.titleFont || cfg.fontFamily || 'Plus Jakarta Sans';
  const topColor = cfg.titleTopColor || accentColor;
  const mainColor = cfg.titleMainColor || '#FFFFFF';
  const bottomColor = cfg.titleBottomColor || accentColor;

  const hasEmblem = cfg.titleEmblemEnabled !== false;
  const textTop = (cfg.titleTop || '').trim();
  const textMain = (cfg.titleMain || '').trim();
  const rawBadge = (cfg.titleBadgeText || '').trim();
  const hasBadge = Boolean(cfg.titleBadgeEnabled) && Boolean(rawBadge) && rawBadge.toLowerCase() !== 'tipe 65';
  const textBottom = (cfg.titleBottom || '').trim();

  // Transition Timing: Staggered reveal
  const pEmblem = clamp(tAdj / 0.8);
  const pCat = clamp((tAdj - 0.4) / 0.6);
  const pMain = clamp((tAdj - 0.7) / 0.8);
  const pBadge = clamp((tAdj - 1.2) / 0.6);
  const pFooter = clamp((tAdj - 1.5) / 0.6);

  // Dynamic stack elements calculation to prevent unnatural vertical gaps
  interface StackElement {
    type: 'emblem' | 'top' | 'main' | 'badge' | 'bottom';
    height: number;
  }
  const stack: StackElement[] = [];
  const logoScale = cfg.titleLogoScale || 1.0;
  const isMultiTitleLogo = cfg.titleLogoMode === 'multiple';
  if (hasEmblem) {
    stack.push({
      type: 'emblem',
      height: (isMultiTitleLogo ? 58 : 75) * scale * logoScale,
    });
  }
  if (textTop) stack.push({ type: 'top', height: (cfg.titleTopSize || 20) * scale });
  if (textMain) stack.push({ type: 'main', height: (cfg.titleMainSize || 48) * scale * 1.05 });
  if (hasBadge) stack.push({ type: 'badge', height: 38 * scale });
  if (textBottom) stack.push({ type: 'bottom', height: (cfg.titleBottomSize || 18) * scale });

  const spacing = (cfg.videoTitleSpacing !== undefined ? cfg.videoTitleSpacing : 22) * scale;
  const totalStackH = stack.reduce((sum, item) => sum + item.height, 0) + Math.max(0, stack.length - 1) * spacing;

  let currentY = -totalStackH / 2;

  ctx.save();
  ctx.translate(cx, cy);

  stack.forEach((item) => {
    const itemCenterY = currentY + item.height / 2;

    if (item.type === 'emblem' && pEmblem > 0) {
      const emblemScale = (0.8 + 0.2 * easeOutBack(pEmblem)) * logoScale;
      const emblemAlpha = clamp(pEmblem * 1.5);
      ctx.save();
      ctx.translate(0, itemCenterY);
      ctx.scale(emblemScale, emblemScale);
      ctx.globalAlpha = emblemAlpha;

      if (cfg.titleLogoGlow !== false) {
        const haloPulse = 1.0 + Math.sin(t * 2.0) * 0.1;
        const haloRadius = (isMultiTitleLogo ? 120 : 70) * scale * haloPulse;
        const haloGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, haloRadius);
        haloGrad.addColorStop(0, 'rgba(223, 155, 53, 0.45)');
        haloGrad.addColorStop(0.5, 'rgba(223, 155, 53, 0.12)');
        haloGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = haloGrad;
        ctx.beginPath();
        ctx.arc(0, 0, haloRadius, 0, Math.PI * 2);
        ctx.fill();
      }

      if (isMultiTitleLogo) {
        // Render Multiple Logos Row for Video Title
        const activeSlots = (cfg.titleLogos || cfg.bumperLogos || []).filter((s) => s.enabled);
        if (activeSlots.length > 0) {
          const targetH = 50 * scale;
          const gap = 28 * scale;
          const loadedLogos = activeSlots.map((slot) => {
            const img = slot.url ? getCachedImage(slot.url) : null;
            const aspect = img && img.naturalWidth && img.naturalHeight ? img.naturalWidth / img.naturalHeight : 2.5;
            const wLogo = targetH * aspect;
            return { slot, img, w: wLogo };
          });
          const totalW = loadedLogos.reduce((acc, l) => acc + l.w, 0) + (loadedLogos.length - 1) * gap;
          let currentLogoX = -totalW / 2;

          loadedLogos.forEach((pl, lIdx) => {
            const centerX = currentLogoX + pl.w / 2;
            ctx.save();
            ctx.translate(centerX, 0);
            if (pl.img) {
              ctx.drawImage(pl.img, -pl.w / 2, -targetH / 2, pl.w, targetH);
            } else if (pl.slot.url?.includes('kso_nke') || pl.slot.name?.toLowerCase().includes('nke')) {
              drawLogo1NKE(ctx, 0, 0, targetH, pl.w);
            } else if (pl.slot.url?.includes('jaya') || pl.slot.name?.toLowerCase().includes('jaya')) {
              drawLogo2Jaya(ctx, 0, 0, targetH, pl.w);
            } else if (pl.slot.url?.includes('wiswa') || pl.slot.name?.toLowerCase().includes('wiswa')) {
              drawLogo3Wiswa(ctx, 0, 0, targetH, pl.w);
            } else {
              ctx.fillStyle = '#FFFFFF';
              ctx.font = `700 ${14 * scale}px "Plus Jakarta Sans", sans-serif`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(pl.slot.name, 0, 0);
            }
            ctx.restore();

            // Divider between logos
            if (lIdx < loadedLogos.length - 1) {
              const divX = currentLogoX + pl.w + gap / 2;
              ctx.save();
              ctx.strokeStyle = hexToRgba(goldColor, 0.6);
              ctx.lineWidth = 1.5 * scale;
              ctx.beginPath();
              ctx.moveTo(divX, -targetH * 0.4);
              ctx.lineTo(divX, targetH * 0.4);
              ctx.stroke();
              ctx.restore();
            }

            currentLogoX += pl.w + gap;
          });
        }
      } else {
        // Single Emblem / Logo
        const customEmblem = cfg.titleEmblemUrl ? getCachedImage(cfg.titleEmblemUrl) : null;
        if (customEmblem) {
          const eAspect = customEmblem.naturalWidth / customEmblem.naturalHeight;
          const eH = 70 * scale;
          const eW = eH * eAspect;
          ctx.drawImage(customEmblem, -eW / 2, -eH / 2, eW, eH);
        } else if (cfg.titleEmblemUrl && (cfg.titleEmblemUrl.includes('kso_nke') || cfg.titleEmblemUrl.includes('nke'))) {
          drawLogo1NKE(ctx, 0, 0, 70 * scale, 180 * scale);
        } else if (cfg.titleEmblemUrl && cfg.titleEmblemUrl.includes('jaya')) {
          drawLogo2Jaya(ctx, 0, 0, 70 * scale, 160 * scale);
        } else if (cfg.titleEmblemUrl && cfg.titleEmblemUrl.includes('wiswa')) {
          drawLogo3Wiswa(ctx, 0, 0, 70 * scale, 160 * scale);
        } else {
          drawTreeOfLifeEmblem(ctx, 0, 0, 62 * scale, goldColor);
        }
      }
      ctx.restore();
    } else if (item.type === 'top' && pCat > 0) {
      const catAlpha = clamp(pCat * 1.4);
      const catSlide = (1 - easeOutCubic(pCat)) * 14 * scale;
      const topFontSize = (cfg.titleTopSize || 20) * scale;
      ctx.save();
      ctx.globalAlpha = catAlpha;
      ctx.font = `700 ${topFontSize}px "${titleFont}", sans-serif`;
      ctx.fillStyle = topColor;
      drawLetterSpacedText(ctx, textTop.toUpperCase(), 0, itemCenterY + catSlide, 6 * scale);
      ctx.restore();
    } else if (item.type === 'main' && pMain > 0) {
      const mainAlpha = clamp(pMain * 1.5);
      const mainScale = 0.92 + 0.08 * easeOutBack(pMain);
      const mainFontSize = (cfg.titleMainSize || 48) * scale;

      ctx.save();
      ctx.globalAlpha = mainAlpha;
      ctx.translate(0, itemCenterY);
      ctx.scale(mainScale, mainScale);

      ctx.font = `900 ${mainFontSize}px "${titleFont}", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
      ctx.fillText(textMain.toUpperCase(), 0, 3 * scale);

      ctx.fillStyle = mainColor;
      ctx.fillText(textMain.toUpperCase(), 0, 0);

      // Specular shine pass across letters
      if (tAdj > 1.2) {
        const shineP = ((tAdj - 1.2) * 0.6) % 2.5;
        if (shineP < 1.0) {
          ctx.save();
          ctx.globalCompositeOperation = 'source-atop';
          const sX = (shineP * 2 - 1) * (w * 0.35);
          const sGrad = ctx.createLinearGradient(sX - 60 * scale, 0, sX + 60 * scale, 0);
          sGrad.addColorStop(0, 'rgba(255,255,255,0)');
          sGrad.addColorStop(0.5, 'rgba(255,255,255,0.85)');
          sGrad.addColorStop(1, 'rgba(255,255,255,0)');
          ctx.fillStyle = sGrad;
          ctx.fillRect(-w * 0.4, -50 * scale, w * 0.8, 100 * scale);
          ctx.restore();
        }
      }
      ctx.restore();
    } else if (item.type === 'badge' && pBadge > 0) {
      const badgeAlpha = clamp(pBadge * 1.5);
      const badgeScale = 0.8 + 0.2 * easeOutBack(pBadge);
      const textBadge = cfg.titleBadgeText;

      ctx.save();
      ctx.translate(0, itemCenterY);
      ctx.scale(badgeScale, badgeScale);
      ctx.globalAlpha = badgeAlpha;

      ctx.font = `900 ${18 * scale}px "${titleFont}", sans-serif`;
      const bW = ctx.measureText(textBadge).width + 42 * scale;
      const bH = 34 * scale;
      const bR = 8 * scale;

      // Drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      drawRoundedRect(ctx, -bW / 2, -bH / 2 + 3 * scale, bW, bH, bR);
      ctx.fill();

      // Badge Background
      const badgeBgGrad = ctx.createLinearGradient(0, -bH / 2, 0, bH / 2);
      badgeBgGrad.addColorStop(0, '#EAB308');
      badgeBgGrad.addColorStop(1, '#DF9B35');
      ctx.fillStyle = cfg.titleBadgeBgColor || badgeBgGrad;
      drawRoundedRect(ctx, -bW / 2, -bH / 2, bW, bH, bR);
      ctx.fill();

      ctx.fillStyle = cfg.titleBadgeTextColor || '#08101E';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(textBadge, 0, 1 * scale);
      ctx.restore();
    } else if (item.type === 'bottom' && pFooter > 0) {
      const footerAlpha = clamp(pFooter * 1.4);
      const footerSlide = (1 - easeOutCubic(pFooter)) * 12 * scale;
      const bottomFontSize = (cfg.titleBottomSize || 18) * scale;

      ctx.save();
      ctx.globalAlpha = footerAlpha;
      ctx.font = `700 ${bottomFontSize}px "${titleFont}", sans-serif`;
      ctx.fillStyle = bottomColor;
      drawLetterSpacedText(ctx, textBottom.toUpperCase(), 0, itemCenterY + footerSlide, 6 * scale);
      ctx.restore();
    }

    currentY += item.height + spacing;
  });

  // 6. BOTTOM HORIZON DIVIDER
  const baselineY = h * 0.44;
  ctx.save();
  const lineGrad = ctx.createLinearGradient(-w * 0.4, 0, w * 0.4, 0);
  lineGrad.addColorStop(0, 'rgba(255,255,255,0)');
  lineGrad.addColorStop(0.3, hexToRgba(goldColor, 0.3));
  lineGrad.addColorStop(0.5, 'rgba(255,255,255,0.95)');
  lineGrad.addColorStop(0.7, hexToRgba(goldColor, 0.3));
  lineGrad.addColorStop(1, 'rgba(255,255,255,0)');

  ctx.strokeStyle = lineGrad;
  ctx.lineWidth = 1.5 * scale;
  ctx.beginPath();
  ctx.moveTo(-w * 0.42, baselineY);
  ctx.lineTo(w * 0.42, baselineY);
  ctx.stroke();

  // Central dot marker
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(0, baselineY, 3 * scale, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.restore();
}

/**
 * ==============================================================================
 * MODE 3: FRAME VIDEO LOGO OVERLAY
 * Directly matched from the reference user image (LOGO_WM_NKE_R3_c1d75e16.png):
 * - Top-Right corner modern diagonal architectural badge
 * - Dual dynamic racing accent stripes: Electric Cyan & Amber Gold
 * - Crisp white or frosted interior surface
 * - Displays up to 3 partner / contractor logos cleanly inside
 * - Multiple style options: Diagonal badge, Glassmorphism bar, Cyber HUD,
 *   Broadcast lower third, Minimal watermark, Cinema letterbox.
 * ==============================================================================
 */
function renderFrameVideoMode(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number
) {
  const scale = Math.min(w, h) / 1000;
  const bgMode = cfg.frameBackgroundMode || 'slate';

  // 1. RENDER BACKGROUND (Matches template: slate, putih, video, alpha)
  if (bgMode === 'transparent' || bgMode === 'alpha') {
    // Subtle checkerboard pattern to visualize transparency in editor viewport
    const checkSize = 24 * scale;
    ctx.fillStyle = '#171C25';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#202733';
    for (let y = 0; y < h; y += checkSize) {
      for (let x = 0; x < w; x += checkSize) {
        if ((Math.floor(x / checkSize) + Math.floor(y / checkSize)) % 2 === 0) {
          ctx.fillRect(x, y, checkSize, checkSize);
        }
      }
    }
  } else if (bgMode === 'putih') {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);
  } else if (bgMode === 'video' || bgMode === 'simulated_video') {
    // Cinematic gradient using user palette: Base Slate to Deep Burgundy to Noir
    const vGrad = ctx.createLinearGradient(0, 0, w, h);
    vGrad.addColorStop(0, '#181F2B');
    vGrad.addColorStop(0.5, '#4E0E15');
    vGrad.addColorStop(1, '#1A0609');
    ctx.fillStyle = vGrad;
    ctx.fillRect(0, 0, w, h);

    // Subtle moving ambient lighting scan in warm sand
    ctx.strokeStyle = 'rgba(223, 206, 181, 0.12)';
    ctx.lineWidth = 1.5 * scale;
    const waveY = (Math.sin(t * 0.8) * 0.15 + 0.5) * h;
    ctx.beginPath();
    ctx.moveTo(0, waveY);
    ctx.lineTo(w, waveY);
    ctx.stroke();
  } else if (bgMode === 'slate') {
    // Base Slate from user palette
    ctx.fillStyle = '#181F2B';
    ctx.fillRect(0, 0, w, h);
  } else if (bgMode === 'solid') {
    ctx.fillStyle = cfg.backgroundColor || '#181F2B';
    ctx.fillRect(0, 0, w, h);
  } else {
    // Gradient mode
    const gGrad = ctx.createLinearGradient(0, 0, w, h);
    gGrad.addColorStop(0, cfg.backgroundColor || '#181F2B');
    gGrad.addColorStop(1, cfg.backgroundSecondaryColor || '#3A0E14');
    ctx.fillStyle = gGrad;
    ctx.fillRect(0, 0, w, h);
  }

  // 2. RENDER THE CHOSEN FRAME STYLE (POJOK KANAN ATAS, DYNAMIC ACTIVE LOGOS)
  const rawFrameLogos = (cfg.frameLogos && cfg.frameLogos.length > 0)
    ? cfg.frameLogos
    : [
        { id: '1', enabled: true, name: 'Logo UNP', url: '/assets/aistudio/kso_wiswa_hd.png' },
        { id: '2', enabled: true, name: 'Nusa Konstruksi', url: '/assets/aistudio/kso_nke_hd.png' },
      ];
  const activeLogos = rawFrameLogos.filter((l) => l.enabled && (l.url || l.name));
  const logoCount = Math.max(1, activeLogos.length);

  const frameStyle = cfg.frameStyle || 'klasik';

  const officialWatermarkStyles = [
    'klasik',
    'kapsul',
    'chevron',
    'potong',
    'gelombang',
    'bar',
    'kaca',
    'jajar',
    'miring',
    'segitiga',
    'pita',
    'tangga',
    'lengkung',
    'dua',
  ];

  const selectedStyle = officialWatermarkStyles.includes(frameStyle) ? frameStyle : 'klasik';

  // Watermark dimensions: 240 x 64 px ratio (18.75% of canvas width as per specification)
  const wmScale = cfg.frameWatermarkScale || 1.0;
  const wmWidth = Math.round(w * 0.1875 * wmScale);
  const wmHeight = Math.round((wmWidth * 64) / 240);
  const wmX = w - wmWidth;
  const wmY = 0;

  const toneOptions = {
    accent1: cfg.frameAccentColor || '#5C1018',
    accent2: cfg.frameSecondaryAccent || '#DFCEB5',
    accent3: cfg.frameTertiaryAccent || '#98AFC3',
    bgCard: cfg.frameCardBgColor || '#F8F5EE',
  };

  const wmImg = getWatermarkImage(selectedStyle, toneOptions);

  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.45)';
  ctx.shadowBlur = (cfg.frameGlowIntensity || 0.7) * 16 * scale;
  ctx.shadowOffsetY = 4 * scale;

  const hasCustomLogos = activeLogos.some((l) => l.url && l.url.startsWith('data:')) || activeLogos.length > 2;

  if (!hasCustomLogos && wmImg && wmImg.complete && wmImg.naturalWidth > 0) {
    ctx.drawImage(wmImg, wmX, wmY, wmWidth, wmHeight);
  } else {
    // Dynamic rendering with activeLogos inside the official frame shape
    const slotW = 100 * scale;
    const dynW = Math.max(wmWidth, 40 * scale + logoCount * slotW);
    const dynH = (dynW * 64) / 240;
    const dynX = w - dynW;

    ctx.fillStyle = '#FFFFFF';
    drawRoundedRect(ctx, dynX, 0, dynW, dynH, 12 * scale);
    ctx.fill();
    ctx.strokeStyle = toneOptions.accent1;
    ctx.lineWidth = 2.4 * scale;
    ctx.stroke();

    // Accent line at bottom
    ctx.fillStyle = toneOptions.accent2;
    ctx.fillRect(dynX + 20 * scale, dynH - 4 * scale, dynW - 20 * scale, 4 * scale);

    const contentStartX = dynX + 16 * scale;
    activeLogos.forEach((logo, idx) => {
      const lx = contentStartX + idx * slotW + slotW / 2;
      const ly = dynH / 2;
      const lImg = logo.url ? getCachedImage(logo.url) : null;
      if (lImg) {
        const aspect = lImg.naturalWidth / lImg.naturalHeight;
        const maxH = dynH * 0.68;
        const maxW = slotW * 0.85;
        let dw = maxH * aspect;
        let dh = maxH;
        if (dw > maxW) {
          dw = maxW;
          dh = dw / aspect;
        }
        ctx.drawImage(lImg, lx - dw / 2, ly - dh / 2, dw, dh);
      } else {
        ctx.fillStyle = '#1B2432';
        ctx.font = `700 ${10 * scale}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(logo.name, lx, ly);
      }
    });
  }
  ctx.restore();
}

/**
 * Procedural Vector Drawing:
 * Indonesian Golden Tree of Life (Pohon Hayat Nusantara)
 */
function drawTreeOfLifeEmblem(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  goldColor: string
) {
  ctx.save();
  ctx.translate(x, y);

  const R = size * 0.22;
  const numRays = 15;

  // Central Solar Sun Core
  const sunGrad = ctx.createRadialGradient(0, -size * 0.15, 0, 0, -size * 0.15, R);
  sunGrad.addColorStop(0, '#FFFBEB');
  sunGrad.addColorStop(0.5, '#F59E0B');
  sunGrad.addColorStop(1, '#B45309');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(0, -size * 0.15, R * 0.65, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#FDE68A';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Radiating Golden Crown Fan Rays
  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 2.2;
  ctx.lineCap = 'round';

  for (let i = 0; i < numRays; i++) {
    const angle = -Math.PI / 2 + ((i - (numRays - 1) / 2) / (numRays - 1)) * (Math.PI * 0.82);
    const innerR = R * 0.8;
    const outerR = size * 0.52 - Math.abs(i - (numRays - 1) / 2) * 1.8;

    const x1 = Math.cos(angle) * innerR;
    const y1 = -size * 0.15 + Math.sin(angle) * innerR;
    const x2 = Math.cos(angle) * outerR;
    const y2 = -size * 0.15 + Math.sin(angle) * outerR;

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }

  // Intertwined Organic Tree Trunk & Roots Below
  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 2.4;
  ctx.beginPath();

  // Left symmetric branches
  ctx.moveTo(0, -size * 0.05);
  ctx.bezierCurveTo(-size * 0.2, size * 0.1, -size * 0.05, size * 0.25, -size * 0.22, size * 0.45);

  ctx.moveTo(0, 0);
  ctx.bezierCurveTo(-size * 0.12, size * 0.15, -size * 0.15, size * 0.3, 0, size * 0.48);

  // Right symmetric branches
  ctx.moveTo(0, -size * 0.05);
  ctx.bezierCurveTo(size * 0.2, size * 0.1, size * 0.05, size * 0.25, size * 0.22, size * 0.45);

  ctx.moveTo(0, 0);
  ctx.bezierCurveTo(size * 0.12, size * 0.15, size * 0.15, size * 0.3, 0, size * 0.48);

  ctx.stroke();

  ctx.restore();
}

/**
 * Sliced Ultra-HD Logo Renderers
 */
function drawLogo1NKE(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgNKE = getCachedImage('/assets/aistudio/kso_nke_hd.png');
  if (imgNKE) {
    ctx.drawImage(imgNKE, x - w / 2, y - h / 2, w, h);
    return;
  }

  // Fallback Procedural
  ctx.save();
  ctx.translate(x, y);
  const startX = -w / 2;
  const topY = -h / 2;
  const botY = h / 2;

  const greenW = 1.33 * h;
  ctx.fillStyle = '#12A727';
  ctx.beginPath();
  ctx.moveTo(startX, botY);
  ctx.lineTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.closePath();
  ctx.fill();

  const rectW = 1.33 * h;
  const emblemEnd = startX + greenW + rectW;
  ctx.fillStyle = '#144DFF';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#FFB51C';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(emblemEnd, topY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  const textX = emblemEnd + 0.22 * h;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#FFFFFF';
  ctx.font = `800 ${h * 0.28}px "Plus Jakarta Sans", sans-serif`;
  drawLetterSpacedTextLeft(ctx, 'N  U  S  A', textX, -h * 0.26, 3.0);
  ctx.font = `700 ${h * 0.22}px "Plus Jakarta Sans", sans-serif`;
  drawLetterSpacedTextLeft(ctx, 'KONSTRUKSI', textX, 0.02 * h, 1.4);
  drawLetterSpacedTextLeft(ctx, 'ENJINIRING', textX, 0.30 * h, 1.6);
  ctx.restore();
}

function drawLogo2Jaya(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgJaya = getCachedImage('/assets/aistudio/kso_jaya_hd.png');
  if (imgJaya) {
    ctx.drawImage(imgJaya, x - w / 2, y - h / 2, w, h);
    return;
  }

  ctx.save();
  ctx.translate(x, y);
  const R = h / 2;
  const strokeW = Math.max(2.6, h * 0.065);

  ctx.strokeStyle = '#FFAE19';
  ctx.lineWidth = strokeW;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.arc(0, 0, R - strokeW / 2, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(0.08 * R, 0.65 * R);
  ctx.lineTo(0.08 * R, -0.72 * R);
  ctx.lineTo(0.22 * R, -0.62 * R);
  ctx.lineTo(0.22 * R, -0.15 * R);
  ctx.lineTo(0.38 * R, 0);
  ctx.lineTo(0.38 * R, 0.40 * R);
  ctx.lineTo(0.55 * R, 0.65 * R);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-0.55 * R, 0.65 * R);
  ctx.lineTo(-0.38 * R, 0.40 * R);
  ctx.lineTo(-0.38 * R, -0.15 * R);
  ctx.lineTo(-0.20 * R, -0.28 * R);
  ctx.lineTo(-0.20 * R, 0.35 * R);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-0.55 * R, 0.65 * R);
  ctx.lineTo(0.55 * R, 0.65 * R);
  ctx.stroke();
  ctx.restore();
}

function drawLogo3Wiswa(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgWiswa = getCachedImage('/assets/aistudio/kso_wiswa_hd.png');
  if (imgWiswa) {
    ctx.drawImage(imgWiswa, x - w / 2, y - h / 2, w, h);
    return;
  }

  ctx.save();
  ctx.translate(x, y);
  const H = h;
  const strokeW = Math.max(2.4, H * 0.06);

  ctx.strokeStyle = '#C92B27';
  ctx.lineWidth = strokeW;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.beginPath();
  ctx.moveTo(0, -H * 0.46);
  ctx.lineTo(H * 0.44, 0);
  ctx.lineTo(0, H * 0.46);
  ctx.lineTo(-H * 0.44, 0);
  ctx.closePath();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(0, -H * 0.46);
  ctx.lineTo(0, H * 0.46);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-H * 0.44, 0);
  ctx.lineTo(H * 0.44, 0);
  ctx.stroke();
  ctx.restore();
}

/**
 * Text Typography Helpers
 */
function drawLetterSpacedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  spacing: number
) {
  const chars = text.split('');
  const widths = chars.map((c) => ctx.measureText(c).width);
  const totalWidth = widths.reduce((a, b) => a + b, 0) + (chars.length - 1) * spacing;
  let curX = x - totalWidth / 2;

  chars.forEach((char, idx) => {
    ctx.fillText(char, curX + widths[idx] / 2, y);
    curX += widths[idx] + spacing;
  });
}

function drawLetterSpacedTextLeft(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  spacing: number
) {
  let curX = x;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    ctx.fillText(ch, curX, y);
    curX += ctx.measureText(ch).width + spacing;
  }
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function applyFilmGrain(ctx: CanvasRenderingContext2D, w: number, h: number, time: number) {
  const grainCanvas = document.createElement('canvas');
  grainCanvas.width = 120;
  grainCanvas.height = 120;
  const gctx = grainCanvas.getContext('2d');
  if (!gctx) return;

  const imgData = gctx.createImageData(120, 120);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const val = Math.floor(Math.random() * 255);
    data[i] = val;
    data[i + 1] = val;
    data[i + 2] = val;
    data[i + 3] = 16;
  }
  gctx.putImageData(imgData, 0, 0);

  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const pattern = ctx.createPattern(grainCanvas, 'repeat');
  if (pattern) {
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

function applyVignette(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.save();
  const radius = Math.max(w, h) * 0.75;
  const vig = ctx.createRadialGradient(w / 2, h / 2, radius * 0.35, w / 2, h / 2, radius);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(0,0,0,0.65)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

function hexToRgba(hex: string, alpha: number = 1): string {
  if (!hex || !hex.startsWith('#')) return `rgba(255,255,255,${alpha})`;
  let c = hex.substring(1);
  if (c.length === 3) c = c.split('').map((x) => x + x).join('');
  const num = parseInt(c, 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}
