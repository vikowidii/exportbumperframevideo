/**
 * Watermark Templates for NKE × UNP (14 Official Styles)
 * Directly extracted from Template_Watermark_NKE___UNP__1__66b7cfdf.html
 */

export interface WatermarkVariation {
  id:
    | 'klasik'
    | 'kapsul'
    | 'chevron'
    | 'potong'
    | 'gelombang'
    | 'bar'
    | 'kaca'
    | 'jajar'
    | 'miring'
    | 'segitiga'
    | 'pita'
    | 'tangga'
    | 'lengkung'
    | 'dua';
  name: string;
  desc: string;
  svgSymbol: string;
}

export const WATERMARK_VARIATIONS: WatermarkVariation[] = [
  {
    id: 'klasik',
    name: 'Klasik',
    desc: 'Lekukan diagonal dinamis dengan pita biru dan oranye emas',
    svgSymbol: `<path d="M9 0H17L35 54 23 28Z" fill="VAR_ACCENT1"/><path d="M22.5 28 30 60 150 50 35 54Z" fill="VAR_ACCENT2"/><path d="M17 0H240V45L35 54Z" fill="VAR_BG"/><path d="M145 49.2 240 45V49.2Z" fill="VAR_ACCENT1"/>`,
  },
  {
    id: 'kapsul',
    name: 'Kapsul',
    desc: 'Sudut membulat kapsul dengan kontur ganda biru dan emas elegan',
    svgSymbol: `<path d="M14 0H240V50H28A14 14 0 0 1 14 36Z" fill="VAR_BG"/><path d="M14 0V36A14 14 0 0 0 28 50H240" fill="none" stroke="VAR_ACCENT1" stroke-width="2.6"/><path d="M10.8 0V36.5A17.2 17.2 0 0 0 28 53.7H240" fill="none" stroke="VAR_ACCENT2" stroke-width="2.2"/>`,
  },
  {
    id: 'chevron',
    name: 'Garis Tiga Warna',
    desc: 'Garis miring tiga warna korporat: biru, oranye, dan hijau presisi',
    svgSymbol: `<path d="M24 0H240V50H40Z" fill="VAR_BG"/><g fill="none" stroke-width="3.4"><path d="M18.5 0 34.5 50" stroke="VAR_ACCENT1"/><path d="M13 0 29 50" stroke="VAR_ACCENT2"/><path d="M7.5 0 23.5 50" stroke="VAR_ACCENT3"/></g><path d="M40 51.5H240" stroke="VAR_ACCENT1" stroke-width="2.6"/><path d="M40 54.7H240" stroke="VAR_ACCENT2" stroke-width="2.2"/>`,
  },
  {
    id: 'potong',
    name: 'Sudut Potong',
    desc: 'Bentuk geometris sudut potong 45° dengan garis kontur modern',
    svgSymbol: `<path d="M30 0H240V50H48L30 32Z" fill="VAR_BG"/><path d="M30 0V32L48 50H240" fill="none" stroke="VAR_ACCENT1" stroke-width="2.8"/><path d="M24.5 0V34.3L46.7 56.5H240" fill="none" stroke="VAR_ACCENT2" stroke-width="2.2"/>`,
  },
  {
    id: 'gelombang',
    name: 'Gelombang',
    desc: 'Lekukan pita gelombang halus bawah dengan gradasi biru-emas',
    svgSymbol: `<path d="M22 0H240V46C220 52 190 58 160 54C110 46 60 62 22 44Z" fill="VAR_BG"/><path d="M22 44C60 62 110 46 160 54C190 58 220 52 240 46" fill="none" stroke="VAR_ACCENT1" stroke-width="2.4"/><path d="M22 48C60 66 110 50 160 58C190 62 220 56 240 50" fill="none" stroke="VAR_ACCENT2" stroke-width="2.2"/>`,
  },
  {
    id: 'bar',
    name: 'Bar Tiga Warna',
    desc: 'Tab penanda vertikal dengan bar garis tiga warna di tepi bawah',
    svgSymbol: `<path d="M36 0H240V47H36Z" fill="VAR_BG"/><rect x="30.5" width="5.5" height="51.4" fill="VAR_ACCENT1"/><rect x="30.5" y="47" width="119.5" height="4.4" fill="VAR_ACCENT1"/><rect x="150" y="47" width="52" height="4.4" fill="VAR_ACCENT2"/><rect x="202" y="47" width="38" height="4.4" fill="VAR_ACCENT3"/>`,
  },
  {
    id: 'kaca',
    name: 'Kartu Melayang',
    desc: 'Kartu semi-transparan melayang dengan sudut melengkung dan garis dasar emas',
    svgSymbol: `<rect x="38" y="1" width="198" height="48" rx="10" fill="VAR_BG" fill-opacity=".95" stroke="VAR_ACCENT1" stroke-width="1"/><path d="M50 49H224" stroke="VAR_ACCENT2" stroke-width="2.4" stroke-linecap="round"/>`,
  },
  {
    id: 'jajar',
    name: 'Jajar Genjang',
    desc: 'Geometris jajar genjang modern dengan garis tepi berjenjang',
    svgSymbol: `<path d="M36 0H240V47H20Z" fill="VAR_BG"/><path d="M28 0H36L20 47H12Z" fill="VAR_ACCENT1"/><path d="M18 0H26L10 47H2Z" fill="VAR_ACCENT2"/><path d="M20 47H240" stroke="VAR_ACCENT1" stroke-width="2.6"/><path d="M4 50.6H240" stroke="VAR_ACCENT2" stroke-width="2.2"/>`,
  },
  {
    id: 'miring',
    name: 'Miring Naik',
    desc: 'Gaya kemiringan dinamis naik ke sudut kanan dengan aksen strip',
    svgSymbol: `<path d="M40 0H240V42L40 52Z" fill="VAR_BG"/><path d="M40 52 240 42V46.2L40 56.2Z" fill="VAR_ACCENT1"/><path d="M40 56.2 150 50.7V53.4L40 58.9Z" fill="VAR_ACCENT2"/><path d="M34 0H40V52L34 56Z" fill="VAR_ACCENT1"/>`,
  },
  {
    id: 'segitiga',
    name: 'Segitiga NKE',
    desc: 'Bentuk segitiga ikonik NKE di sudut kiri bawah bingkai',
    svgSymbol: `<path d="M44 0H240V48H44Z" fill="VAR_BG"/><path d="M20 0H44V24Z" fill="VAR_ACCENT2"/><path d="M20 48H44V24Z" fill="VAR_ACCENT1"/><path d="M44 48H240V51.4H44Z" fill="VAR_ACCENT3"/><path d="M44 51.4H150V54.2H44Z" fill="VAR_ACCENT2"/>`,
  },
  {
    id: 'pita',
    name: 'Pita',
    desc: 'Lipatan ujung pita diagonal dengan garis aksen footer ganda',
    svgSymbol: `<path d="M26 0H240V50H26L37 25Z" fill="VAR_BG"/><path d="M20 0H26L37 25 26 50H20L31 25Z" fill="VAR_ACCENT1"/><path d="M26 50H240V53.4H26Z" fill="VAR_ACCENT1"/><path d="M26 53.4H120V56.4H26Z" fill="VAR_ACCENT2"/>`,
  },
  {
    id: 'tangga',
    name: 'Bertingkat',
    desc: 'Siluet tangga bertingkat arsitektural dengan garis kontur tegas',
    svgSymbol: `<path d="M32 0H240V42H120V50H32Z" fill="VAR_BG"/><path d="M32 0V50H120V42H240" fill="none" stroke="VAR_ACCENT1" stroke-width="2.8"/><path d="M27 0V55H125V47H240" fill="none" stroke="VAR_ACCENT2" stroke-width="2.2"/>`,
  },
  {
    id: 'lengkung',
    name: 'Lengkung Besar',
    desc: 'Sudut kurva lengkung besar lembut dengan garis ganda kontemporer',
    svgSymbol: `<path d="M20 0H240V46H60A40 40 0 0 1 20 6Z" fill="VAR_BG"/><path d="M20 6A40 40 0 0 0 60 46H240" fill="none" stroke="VAR_ACCENT1" stroke-width="2.6"/><path d="M16.5 6A43.5 43.5 0 0 0 60 49.5H240" fill="none" stroke="VAR_ACCENT2" stroke-width="2.2"/>`,
  },
  {
    id: 'dua',
    name: 'Dua Kartu',
    desc: 'Format split dua kartu terpisah elegan dengan aksen garis bawah',
    svgSymbol: `<path d="M42 0H96V40A8 8 0 0 1 88 48H50A8 8 0 0 1 42 40Z" fill="VAR_BG"/><path d="M97.5 0H240V40A8 8 0 0 1 232 48H105.5A8 8 0 0 1 97.5 40Z" fill="VAR_BG"/><path d="M46 49.5H92" stroke="VAR_ACCENT2" stroke-width="2.6" stroke-linecap="round"/><path d="M102 49.5H236" stroke="VAR_ACCENT1" stroke-width="2.6" stroke-linecap="round"/>`,
  },
];

// Logos Definition (UNP Vector Crest + NKE Vector Triangles)
const LOGOS_SVG_DEF = `
  <defs>
    <linearGradient id="gHijau" x1="0" y1="1" x2="0" y2="0">
      <stop offset="0" stop-color="#1DB13A"/>
      <stop offset="1" stop-color="#0B8A1E"/>
    </linearGradient>
    <path id="arcUNP" d="M59.05 35.45A16.9 16.9 0 1 1 82.95 35.45"/>
  </defs>
  <!-- 1. UNP Official Vector Emblem -->
  <g>
    <circle cx="71" cy="23.5" r="21" fill="#FFFFFF" stroke="#1C1C1C" stroke-width=".5"/>
    <circle cx="71" cy="23.5" r="15.9" fill="none" stroke="#1C1C1C" stroke-width=".35"/>
    <text font-family="'Plus Jakarta Sans', Arial, sans-serif" font-weight="700" font-size="3.2" fill="#1C1C1C">
      <textPath href="#arcUNP" startOffset="1.5" textLength="76" lengthAdjust="spacing">UNIVERSITAS NEGERI PADANG</textPath>
    </text>
    <text x="71" y="42.4" text-anchor="middle" font-family="'Arial Black', Arial, sans-serif" font-weight="900" font-size="3.6" letter-spacing=".3" fill="#1C1C1C">UNP</text>
    <g transform="translate(71 23.5)">
      <circle r="14.2" fill="#1D4EA6"/>
      <g id="tandukUNP" fill="#FFB51C">
        <path d="M-5.2 6C-9.5 2-8.5-6-5.6-11.2-5.4-6.8-3.8-3.6-3.3-.6-4.2 1.6-4.6 3.6-4 5.4Z"/>
        <path d="M-12 1C-11.2-3-9.5-5.5-8.4-7.2-8.4-4-8.8-1.2-7.2 2.2Z"/>
      </g>
      <use href="#tandukUNP" transform="scale(-1 1)"/>
      <path d="M-9.4 3.2C-9.4 8.4-4.6 11.4 0 11.4S9.4 8.4 9.4 3.2C7 6.4 3.8 7.8 0 7.8S-7 6.4-9.4 3.2Z" fill="#F59A05"/>
      <path d="M-7 5.2C-5 8 -2.5 8.8 0 8.8S5 8 7 5.2" fill="none" stroke="#FFD25E" stroke-width=".5"/>
      <rect x="-2.3" y="-2.4" width="4.6" height="9.2" rx="1" fill="#FFF6D6"/>
      <g fill="#E58A00">
        <rect x="-2.3" y="-.6" width="4.6" height="1.1"/>
        <rect x="-2.3" y="1.9" width="4.6" height="1.1"/>
        <rect x="-2.3" y="4.4" width="4.6" height="1.1"/>
      </g>
      <path d="M0-8C1.9-5.4 2.5-3.8 0-2.4-2.5-3.8-1.9-5.4 0-8Z" fill="#E8262E"/>
    </g>
  </g>
  <!-- 2. NKE Official Vector Emblem -->
  <g>
    <path d="M100.8 38.8 133.3 14.2V38.8Z" fill="url(#gHijau)"/>
    <path d="M133.3 14.2 166.7 38.8H133.3Z" fill="#144DFF"/>
    <path d="M133.3 14.2H166.7V38.8Z" fill="#FFB51C"/>
    <g font-family="'Cinzel', 'Times New Roman', serif" font-weight="700" fill="#333F50" font-size="6.6">
      <text x="171" y="19.7" textLength="54" lengthAdjust="spacing">NUSA</text>
      <text x="171" y="29.7" textLength="54" lengthAdjust="spacingAndGlyphs">KONSTRUKSI</text>
      <text x="171" y="37.6" textLength="54" lengthAdjust="spacing">ENJINIRING</text>
    </g>
  </g>
`;

export interface WatermarkToneOptions {
  accent1?: string; // default #5C1018 (Deep Burgundy)
  accent2?: string; // default #DFCEB5 (Warm Sand)
  accent3?: string; // default #98AFC3 (Dusty Slate)
  bgCard?: string;  // default #F8F5EE (Soft Cream)
}

/**
 * Generate full SVG string for a given variation with tone options
 */
export function generateWatermarkSvgString(
  styleId: string,
  tone?: WatermarkToneOptions
): string {
  const variation = WATERMARK_VARIATIONS.find((v) => v.id === styleId) || WATERMARK_VARIATIONS[0];

  const a1 = tone?.accent1 || '#5C1018';
  const a2 = tone?.accent2 || '#DFCEB5';
  const a3 = tone?.accent3 || '#98AFC3';
  const bg = tone?.bgCard || '#F8F5EE';

  let rawSymbol = variation.svgSymbol
    .replace(/VAR_ACCENT1/g, a1)
    .replace(/VAR_ACCENT2/g, a2)
    .replace(/VAR_ACCENT3/g, a3)
    .replace(/VAR_BG/g, bg);

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 64" width="1920" height="512">
    ${rawSymbol}
    ${LOGOS_SVG_DEF}
  </svg>`;
}

// In-memory image cache for fast canvas rendering with tone hashing
const watermarkImageCache = new Map<string, HTMLImageElement>();

/**
 * Returns a cached HTMLImageElement for the given watermark variation and tone
 */
export function getWatermarkImage(
  styleId: string,
  tone?: WatermarkToneOptions
): HTMLImageElement | null {
  const validIds = WATERMARK_VARIATIONS.map((v) => v.id);
  const normalizedId = (validIds as string[]).includes(styleId) ? styleId : 'klasik';

  const cacheKey = `${normalizedId}_${tone?.accent1 || ''}_${tone?.accent2 || ''}_${tone?.accent3 || ''}_${tone?.bgCard || ''}`;

  if (watermarkImageCache.has(cacheKey)) {
    return watermarkImageCache.get(cacheKey)!;
  }

  const svgStr = generateWatermarkSvgString(normalizedId, tone);
  const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const img = new Image();
  img.src = url;

  watermarkImageCache.set(cacheKey, img);
  return img;
}
