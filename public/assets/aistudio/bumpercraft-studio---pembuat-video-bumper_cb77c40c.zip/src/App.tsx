import React, { useState } from 'react';
import { Header } from './components/Header';
import { LeftNavigation, LeftNavSection } from './components/LeftNavigation';
import { CenterPlayer } from './components/CenterPlayer';
import { ChooseInspector } from './components/ChooseInspector';
import { ExportModal } from './components/ExportModal';
import { AIBumperModal } from './components/AIBumperModal';
import { BumperConfig, StudioMode, AIConcept } from './types/bumper';

const INITIAL_CONFIG: BumperConfig = {
  // 3 Primary Studio Modes: 'bumper_logo' | 'video_title' | 'frame_video'
  studioMode: 'bumper_logo',

  // 1. Bumper Logo Settings
  logoCountMode: 'single',
  bumperLogos: [
    { id: 'logo1', enabled: true, name: 'PT Nusa Konstruksi Enjiniring', url: '/assets/aistudio/kso_nke_hd.png', scale: 1 },
    { id: 'logo2', enabled: true, name: 'PT Jaya Konstruksi', url: '/assets/aistudio/kso_jaya_hd.png', scale: 1 },
  ],
  singleLogo: {
    id: 'single1',
    enabled: true,
    name: 'PT Nusa Konstruksi Enjiniring',
    url: '/assets/aistudio/kso_nke_hd.png',
    scale: 1.25,
  },
  singleLogoAnimation: 'puzzle_assemble',
  singleLogoTransition: 'puzzle_assemble',
  singleLogoScale: 1.25,
  singleLogoShowTitle: false,
  singleLogoTitle: 'PT Nusa Konstruksi Enjiniring, Tbk',
  singleLogoTitleColor: '#FFFFFF',
  singleLogoTitleFont: 'Plus Jakarta Sans',
  singleLogoTitleSize: 28,
  singleLogoSubtitle: '',
  title: 'NUSA JAYA WISWAKHARMAN, KSO',
  subtitle: '',
  tagline: '',
  titleColor: '#FFFFFF',
  bumperTitleFont: 'Outfit',

  // 2. Video Title Screen Settings
  titleTop: 'SIMULASI KONSTRUKSI',
  titleTopSize: 22,
  titleTopColor: '#DFCEB5',
  titleMain: 'PEMBANGUNAN HUNIAN VERTIKAL NEGARA',
  titleMainSize: 48,
  titleMainColor: '#FFFFFF',
  titleBottom: 'DI IBU KOTA NUSANTARA',
  titleBottomSize: 18,
  titleBottomColor: '#98AFC3',
  titleFont: 'Plus Jakarta Sans',
  videoTitleSpacing: 22,
  titleBadgeText: '',
  titleBadgeEnabled: false,
  titleBadgeBgColor: '#DFCEB5',
  titleEmblemEnabled: true,
  titleEmblemUrl: '',
  titleLogoMode: 'single',
  titleLogoScale: 1.0,
  titleLogoGlow: true,
  titleLogos: [
    { id: 't_logo1', enabled: true, name: 'PT Nusa Konstruksi Enjiniring', url: '/assets/aistudio/kso_nke_hd.png', scale: 1 },
    { id: 't_logo2', enabled: true, name: 'PT Jaya Konstruksi', url: '/assets/aistudio/kso_jaya_hd.png', scale: 1 },
    { id: 't_logo3', enabled: true, name: 'PT Wiswakharman', url: '/assets/aistudio/kso_wiswa_hd.png', scale: 1 },
  ],
  titleTransition: 'kinetic_typography',

  // 3. Frame Video Logo Overlay Settings
  frameStyle: 'klasik',
  framePosition: 'top_right',
  frameBackgroundMode: 'slate',
  frameGlowIntensity: 0.7,
  frameBorderRadius: 10,
  frameWatermarkScale: 1.0,
  frameLogos: [
    { id: 'f_logo1', enabled: true, name: 'PT Wiswakharman / Klien', url: '/assets/aistudio/kso_wiswa_hd.png', scale: 1 },
    { id: 'f_logo2', enabled: true, name: 'PT Nusa Konstruksi Enjiniring', url: '/assets/aistudio/kso_nke_hd.png', scale: 1 },
  ],
  frameAccentColor: '#5C1018',
  frameSecondaryAccent: '#DFCEB5',
  frameTertiaryAccent: '#98AFC3',
  frameCardBgColor: '#F8F5EE',

  // Color Tone
  colorTone: 'none',

  // Theming & Backgrounds
  theme: 'kso_corporate',
  aspectRatio: '16:9',
  duration: 5.5,
  fps: 60,
  primaryColor: '#FFFFFF',
  secondaryColor: '#DFCEB5',
  accentColor: '#98AFC3',
  backgroundColor: '#181F2B',
  backgroundSecondaryColor: '#3A0E14',
  backgroundStyle: 'gradient',
  spotlightEnabled: true,
  spotlightIntensity: 0.65,
  spotlightRadius: 70,
  spotlightSoftness: 0.75,
  spotlightYOffset: 0,
  spotlightPulseSpeed: 1.0,
  futuristicEffect: 'none',
  laserScanline: false,
  cyberHexMesh: false,
  hologramLines: false,
  lightStreaks: false,
  showGrid: true,
  gridOpacity: 0.04,
  fontFamily: 'Outfit',
  fontSize: 1.0,
  letterSpacing: 3,
  icon: 'kso',
  customLogoUrl: '/assets/aistudio/LOGO_KSO_HD_vektor_edcea276.png',
  ksoLogoMode: 'hd_vector',
  transitionStyle: 'slide_left',
  showPartnerLabels: false,
  particleCount: 45,
  particleColor: '#DFCEB5',
  motionSpeed: 1.0,
  vignette: true,
  filmGrain: false,
  letterbox: false,
  anamorphicFlare: true,
  audioTheme: 'none',
  soundEnabled: false,
  soundVolume: 0,
};

export default function App() {
  const [config, setConfig] = useState<BumperConfig>(INITIAL_CONFIG);
  const [activeSection, setActiveSection] = useState<LeftNavSection>('logo');
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState<boolean>(false);
  const [lang, setLang] = useState<'id' | 'en'>('id');

  const handleUpdateConfig = (partial: Partial<BumperConfig>) => {
    setConfig((prev) => ({ ...prev, ...partial }));
  };

  const handleReset = () => {
    setConfig(INITIAL_CONFIG);
    setActiveSection('logo');
  };

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'id' ? 'en' : 'id'));
  };

  const handleSelectSection = (mode: StudioMode, section: LeftNavSection) => {
    setConfig((prev) => ({ ...prev, studioMode: mode }));
    setActiveSection(section);
  };

  const handleApplyConcept = (concept: AIConcept) => {
    setConfig((prev) => ({
      ...prev,
      title: concept.title,
      subtitle: concept.slogan,
      theme: concept.themeId,
      primaryColor: concept.primaryColor,
      secondaryColor: concept.secondaryColor,
      fontFamily: concept.fontFamily,
      audioTheme: concept.audioTheme,
      generateTrigger: Date.now(),
    }));
  };

  return (
    <div className="min-h-screen bg-[#10141D] text-neutral-100 flex flex-col font-sans select-none antialiased">
      {/* 1. TOP NAVBAR HEADER (Full Width, Matching Purple Top Bar in Wireframe) */}
      <Header
        config={config}
        onUpdateConfig={handleUpdateConfig}
        onOpenExport={() => setIsExportModalOpen(true)}
        onOpenAIModal={() => setIsAIModalOpen(true)}
        onReset={handleReset}
        lang={lang}
        onToggleLang={handleToggleLang}
      />

      {/* 2. THREE-COLUMN WORKSPACE (Matching Wireframe Columns: Left Nav, Center Player, Right Choose) */}
      <main className="flex-1 w-full max-w-[1920px] mx-auto p-3 sm:p-4 lg:p-5 flex flex-col">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-5 items-start flex-1">
          {/* LEFT COLUMN: Categories & Navigation (Wireframe Left Container: 3 Cards) */}
          <section className="lg:col-span-3 xl:col-span-3 w-full">
            <LeftNavigation
              config={config}
              onUpdateConfig={handleUpdateConfig}
              activeSection={activeSection}
              onSelectSection={handleSelectSection}
              lang={lang}
            />
          </section>

          {/* CENTER COLUMN: Video Viewport, Timeline Scrubber & Controls (Wireframe Center Container) */}
          <section className="lg:col-span-5 xl:col-span-5 w-full">
            <CenterPlayer
              config={config}
              onUpdateConfig={handleUpdateConfig}
              lang={lang}
            />
          </section>

          {/* RIGHT COLUMN: CHOOSE Options Inspector (Wireframe Right Container) */}
          <section className="lg:col-span-4 xl:col-span-4 w-full">
            <ChooseInspector
              config={config}
              onUpdateConfig={handleUpdateConfig}
              activeSection={activeSection}
              lang={lang}
            />
          </section>
        </div>
      </main>

      {/* MODALS */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        config={config}
        lang={lang}
      />

      <AIBumperModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        onApplyConcept={handleApplyConcept}
        lang={lang}
      />
    </div>
  );
}
