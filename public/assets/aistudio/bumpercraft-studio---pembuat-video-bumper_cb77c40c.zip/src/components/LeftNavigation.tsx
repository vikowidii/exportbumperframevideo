import React, { useState } from 'react';
import { BumperConfig, StudioMode, LogoCountMode } from '../types/bumper';
import {
  Film,
  Type,
  Layers,
  PlusCircle,
  Palette,
  FileText,
  Sparkles,
  Volume2,
  Box,
  CheckCircle2,
  Plus,
  ChevronDown,
} from 'lucide-react';

export type LeftNavSection =
  | 'logo'
  | 'background'
  | 'text'
  | 'effects'
  | 'audio'
  | 'frame_style';

interface LeftNavigationProps {
  config: BumperConfig;
  onUpdateConfig: (partial: Partial<BumperConfig>) => void;
  activeSection: LeftNavSection;
  onSelectSection: (mode: StudioMode, section: LeftNavSection) => void;
  lang: 'id' | 'en';
}

export const LeftNavigation: React.FC<LeftNavigationProps> = ({
  config,
  onUpdateConfig,
  activeSection,
  onSelectSection,
  lang,
}) => {
  const currentMode = config.studioMode;

  // Track which card dropdowns are open (default the active one is open)
  const [openCards, setOpenCards] = useState<Record<StudioMode, boolean>>({
    bumper_logo: config.studioMode === 'bumper_logo',
    video_title: config.studioMode === 'video_title',
    frame_video: config.studioMode === 'frame_video',
  });

  // When clicking a card header: toggle its dropdown and activate the mode
  const handleCardHeaderClick = (mode: StudioMode, defaultSection: LeftNavSection) => {
    const targetSection = mode === 'frame_video' ? 'frame_style' : defaultSection;
    onUpdateConfig({ studioMode: mode });
    onSelectSection(mode, targetSection);

    setOpenCards((prev) => ({
      ...prev,
      [mode]: !prev[mode],
    }));
  };

  const handleLogoModeChange = (mode: LogoCountMode) => {
    onUpdateConfig({ studioMode: 'bumper_logo', logoCountMode: mode });
    onSelectSection('bumper_logo', 'logo');
  };

  const isSingle = config.logoCountMode === 'single';

  return (
    <div className="flex flex-col gap-3.5 w-full bg-[#181F2B] border-2 border-[#98AFC3]/30 rounded-2xl p-3 shadow-2xl select-none text-[#F8F5EE]">
      {/* ======================================================== */}
      {/* CARD 1: BUMPER OPENING VIDEO (DROPDOWN ACCORDION)         */}
      {/* ======================================================== */}
      <div
        className={`rounded-xl border transition-all overflow-hidden ${
          currentMode === 'bumper_logo'
            ? 'border-[#DFCEB5] shadow-lg shadow-black/40 bg-[#181F2B]'
            : 'border-[#98AFC3]/30 bg-[#181F2B]/90 hover:border-[#DFCEB5]/50'
        }`}
      >
        {/* Card Header Dropdown Toggle */}
        <button
          type="button"
          onClick={() => handleCardHeaderClick('bumper_logo', 'logo')}
          className={`w-full flex items-center justify-between px-3.5 py-3 font-black text-xs sm:text-sm tracking-wider uppercase transition-colors ${
            currentMode === 'bumper_logo'
              ? 'bg-[#68131B] text-[#F8F5EE]'
              : 'bg-[#22151B] text-[#DFCEB5] hover:bg-[#2E1A23] border border-[#DFCEB5]/25'
          }`}
        >
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-[#DFCEB5] shrink-0" />
            <span>BUMPER OPENING VIDEO</span>
          </div>
          <div className="flex items-center gap-2">
            {currentMode === 'bumper_logo' && (
              <span className="w-2 h-2 rounded-full bg-[#DFCEB5] animate-pulse" />
            )}
            <ChevronDown
              className={`w-4 h-4 text-[#DFCEB5] transition-transform duration-300 ${
                openCards.bumper_logo ? 'rotate-180' : 'rotate-0'
              }`}
            />
          </div>
        </button>

        {/* DROPDOWN BODY: Revealed when Bumper Opening is clicked */}
        {openCards.bumper_logo && (
          <div className="flex flex-col transition-all">
            {/* Sub-Buttons: SINGLE LOGO vs MULTIPLE LOGO */}
            <div className="p-2 bg-[#121822] border-b border-[#98AFC3]/20">
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#0D121A] rounded-lg border border-[#98AFC3]/20">
                <button
                  type="button"
                  onClick={() => handleLogoModeChange('single')}
                  className={`py-1.5 px-2 text-[11px] font-bold tracking-wider uppercase rounded-md transition-all text-center ${
                    config.logoCountMode === 'single' && currentMode === 'bumper_logo'
                      ? 'bg-[#DFCEB5] text-[#5C1018] shadow-sm font-black'
                      : 'text-[#98AFC3] hover:text-[#F8F5EE] hover:bg-white/5'
                  }`}
                >
                  SINGLE LOGO
                </button>
                <button
                  type="button"
                  onClick={() => handleLogoModeChange('multiple')}
                  className={`py-1.5 px-2 text-[11px] font-bold tracking-wider uppercase rounded-md transition-all text-center ${
                    config.logoCountMode === 'multiple' && currentMode === 'bumper_logo'
                      ? 'bg-[#DFCEB5] text-[#5C1018] shadow-sm font-black'
                      : 'text-[#98AFC3] hover:text-[#F8F5EE] hover:bg-white/5'
                  }`}
                >
                  MULTIPLE LOGO
                </button>
              </div>
            </div>

            {/* Sub-Menu Items */}
            <div className="p-2.5 bg-[#D9C6AB] border-t border-[#DFCEB5]/40 flex flex-col gap-1.5 text-[#181F2B]">
              {[
                {
                  id: 'logo' as LeftNavSection,
                  label: isSingle ? 'ADD LOGO' : 'ADD MORE LOGO',
                  icon: isSingle ? PlusCircle : Plus,
                },
                {
                  id: 'background' as LeftNavSection,
                  label: 'BACKGROUND STYLE',
                  icon: Palette,
                },
                ...(!isSingle
                  ? [
                      {
                        id: 'text' as LeftNavSection,
                        label: 'TEXT STYLE',
                        icon: FileText,
                      },
                    ]
                  : []),
                {
                  id: 'effects' as LeftNavSection,
                  label: 'EFFECT STYLE',
                  icon: Sparkles,
                },
              ].map((item) => {
                const isSelected = currentMode === 'bumper_logo' && activeSection === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onUpdateConfig({ studioMode: 'bumper_logo' });
                      onSelectSection('bumper_logo', item.id);
                    }}
                    className={`flex items-center justify-between w-full px-3 py-2 rounded-lg text-xs font-bold tracking-wide uppercase transition-all ${
                      isSelected
                        ? 'bg-[#5C1018] text-[#F8F5EE] shadow-md shadow-black/40 font-black translate-x-1 border border-[#DFCEB5]'
                        : 'text-[#3E2916] hover:bg-black/10 hover:text-black'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className="w-3.5 h-3.5 shrink-0" />
                      <span>{item.label}</span>
                    </div>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-[#DFCEB5]" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* CARD 2: VIDEO TITLE (DROPDOWN ACCORDION)                  */}
      {/* ======================================================== */}
      <div
        className={`rounded-xl border transition-all overflow-hidden ${
          currentMode === 'video_title'
            ? 'border-[#DFCEB5] shadow-lg shadow-black/40 bg-[#181F2B]'
            : 'border-[#98AFC3]/30 bg-[#181F2B]/90 hover:border-[#DFCEB5]/50'
        }`}
      >
        {/* Card Header Dropdown Toggle */}
        <button
          type="button"
          onClick={() => handleCardHeaderClick('video_title', 'text')}
          className={`w-full flex items-center justify-between px-3.5 py-3 font-black text-xs sm:text-sm tracking-wider uppercase transition-colors ${
            currentMode === 'video_title'
              ? 'bg-[#68131B] text-[#F8F5EE]'
              : 'bg-[#22151B] text-[#DFCEB5] hover:bg-[#2E1A23] border border-[#DFCEB5]/25'
          }`}
        >
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-[#DFCEB5] shrink-0" />
            <span>VIDEO TITLE</span>
          </div>
          <div className="flex items-center gap-2">
            {currentMode === 'video_title' && (
              <span className="w-2 h-2 rounded-full bg-[#DFCEB5] animate-pulse" />
            )}
            <ChevronDown
              className={`w-4 h-4 text-[#DFCEB5] transition-transform duration-300 ${
                openCards.video_title ? 'rotate-180' : 'rotate-0'
              }`}
            />
          </div>
        </button>

        {/* DROPDOWN BODY: Revealed when Video Title is clicked */}
        {openCards.video_title && (
          <div className="p-2.5 bg-[#D9C6AB] border-t border-[#DFCEB5]/40 flex flex-col gap-1.5 text-[#181F2B] transition-all">
            {[
              { id: 'logo' as LeftNavSection, label: 'ADD LOGO VIDEO', icon: PlusCircle },
              { id: 'background' as LeftNavSection, label: 'BACKGROUND STYLE', icon: Palette },
              { id: 'text' as LeftNavSection, label: 'TEXT STYLE', icon: FileText },
              { id: 'effects' as LeftNavSection, label: 'EFFECT STYLE', icon: Sparkles },
            ].map((item) => {
              const isSelected = currentMode === 'video_title' && activeSection === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    onUpdateConfig({ studioMode: 'video_title' });
                    onSelectSection('video_title', item.id);
                  }}
                  className={`flex items-center justify-between w-full px-3 py-2 rounded-lg text-xs font-bold tracking-wide uppercase transition-all ${
                    isSelected
                      ? 'bg-[#5C1018] text-[#F8F5EE] shadow-md shadow-black/40 font-black translate-x-1 border border-[#DFCEB5]'
                      : 'text-[#3E2916] hover:bg-black/10 hover:text-black'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-[#DFCEB5]" />}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* CARD 3: FRAME/LOGO VIDEO (DROPDOWN ACCORDION)             */}
      {/* ======================================================== */}
      <div
        className={`rounded-xl border transition-all overflow-hidden ${
          currentMode === 'frame_video'
            ? 'border-[#DFCEB5] shadow-lg shadow-black/40 bg-[#181F2B]'
            : 'border-[#98AFC3]/30 bg-[#181F2B]/90 hover:border-[#DFCEB5]/50'
        }`}
      >
        {/* Card Header Dropdown Toggle */}
        <button
          type="button"
          onClick={() => handleCardHeaderClick('frame_video', 'logo')}
          className={`w-full flex items-center justify-between px-3.5 py-3 font-black text-xs sm:text-sm tracking-wider uppercase transition-colors ${
            currentMode === 'frame_video'
              ? 'bg-[#68131B] text-[#F8F5EE]'
              : 'bg-[#22151B] text-[#DFCEB5] hover:bg-[#2E1A23] border border-[#DFCEB5]/25'
          }`}
        >
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#DFCEB5] shrink-0" />
            <span>FRAME/LOGO VIDEO</span>
          </div>
          <div className="flex items-center gap-2">
            {currentMode === 'frame_video' && (
              <span className="w-2 h-2 rounded-full bg-[#DFCEB5] animate-pulse" />
            )}
            <ChevronDown
              className={`w-4 h-4 text-[#DFCEB5] transition-transform duration-300 ${
                openCards.frame_video ? 'rotate-180' : 'rotate-0'
              }`}
            />
          </div>
        </button>

        {/* DROPDOWN BODY: Revealed when Frame/Logo Video is clicked */}
        {openCards.frame_video && (
          <div className="p-2.5 bg-[#D9C6AB] border-t border-[#DFCEB5]/40 flex flex-col gap-1.5 text-[#181F2B] transition-all">
            {[
              { id: 'logo' as LeftNavSection, label: 'ADD LOGO (MORE)', icon: PlusCircle },
              { id: 'frame_style' as LeftNavSection, label: 'FRAME STYLE (VARIASI)', icon: Box },
            ].map((item) => {
              const isSelected = currentMode === 'frame_video' && activeSection === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    onUpdateConfig({ studioMode: 'frame_video' });
                    onSelectSection('frame_video', item.id);
                  }}
                  className={`flex items-center justify-between w-full px-3 py-2 rounded-lg text-xs font-bold tracking-wide uppercase transition-all ${
                    isSelected
                      ? 'bg-[#5C1018] text-[#F8F5EE] shadow-md shadow-black/40 font-black translate-x-1 border border-[#DFCEB5]'
                      : 'text-[#3E2916] hover:bg-black/10 hover:text-black'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-[#DFCEB5]" />}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
