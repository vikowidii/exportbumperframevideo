import React from 'react';
import {
  BumperConfig,
  StudioMode,
  LogoCountMode,
  AudioThemeId,
  BackgroundStyle,
  TransitionStyle,
  FrameStyle,
  FrameBackgroundMode,
  ColorTone,
  SingleLogoAnimation,
  LogoSlot,
} from '../types/bumper';
import { LeftNavSection } from './LeftNavigation';
import { audioEngine } from '../utils/audioEngine';
import { WATERMARK_VARIATIONS, generateWatermarkSvgString } from '../utils/watermarkTemplates';
import {
  Upload,
  Check,
  Sparkles,
  Palette,
  Volume2,
  Box,
  Image as ImageIcon,
  Plus,
  Trash2,
  Play,
  Layers,
  MoveLeft,
  MoveUp,
  Puzzle,
  Eye,
  Compass,
  Copy,
  Sliders,
  Wind,
} from 'lucide-react';
interface ChooseInspectorProps {
  config: BumperConfig;
  onUpdateConfig: (partial: Partial<BumperConfig>) => void;
  activeSection: LeftNavSection;
  lang: 'id' | 'en';
}

const FONT_OPTIONS = [
  { id: 'Plus Jakarta Sans', name: 'Plus Jakarta Sans (Elegan & Berwibawa)' },
  { id: 'Outfit', name: 'Outfit (Modern & Bersih)' },
  { id: 'Cinzel', name: 'Cinzel (Sinematik Megah)' },
  { id: 'Space Grotesk', name: 'Space Grotesk (Tech Futuristik)' },
  { id: 'Oswald', name: 'Oswald (Kondensasi Tegas)' },
  { id: 'Playfair Display', name: 'Playfair Display (Klasik Luxury)' },
];

const FONT_COLOR_PRESETS = [
  { name: 'Putih Bersih', hex: '#FFFFFF' },
  { name: 'Warm Sand', hex: '#DFCEB5' },
  { name: 'Burgundy Emas', hex: '#68131B' },
  { name: 'Dusty Slate', hex: '#98AFC3' },
  { name: 'Soft Cream', hex: '#F8F5EE' },
  { name: 'Base Slate', hex: '#181F2B' },
];

const COLOR_TONE_OPTIONS: { id: ColorTone; name: string; preview: string; desc: string }[] = [
  { id: 'none', name: 'Natural / Asli', preview: '#94A3B8', desc: 'Tanpa filter warna tambahan' },
  { id: 'warm_cinematic', name: 'Warm Cinematic', preview: '#DFCEB5', desc: 'Kehangatan emas sinematik' },
  { id: 'cool_tech', name: 'Cool Slate Tech', preview: '#98AFC3', desc: 'Nuansa biru korporat futuristik' },
  { id: 'noir_luxe', name: 'Noir Luxe (Burgundy/Black)', preview: '#68131B', desc: 'Monokromatik mewah kontras tinggi' },
  { id: 'emerald_signature', name: 'Emerald NKE', preview: '#10B981', desc: 'Kombinasi hijau & emas khas' },
  { id: 'sunset_amber', name: 'Sunset Amber', preview: '#F59E0B', desc: 'Pendaran senja dramatis' },
];

export const ChooseInspector: React.FC<ChooseInspectorProps> = ({
  config,
  onUpdateConfig,
  activeSection,
  lang,
}) => {
  const [copiedSvg, setCopiedSvg] = React.useState(false);
  const currentMode = config.studioMode;
  const isSingleLogo = currentMode === 'bumper_logo' && config.logoCountMode === 'single';

  // Handle single logo file upload
  const handleSingleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        onUpdateConfig({
          singleLogo: {
            id: 'single_custom',
            enabled: true,
            name: file.name,
            url: dataUrl,
            scale: config.singleLogoScale || 1.25,
          },
          customLogoUrl: dataUrl,
          generateTrigger: Date.now(),
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // Add more logo to bumperLogos (Multiple Logo mode)
  const handleAddMoreBumperLogo = () => {
    const currentList = config.bumperLogos || [];
    const newSlot: LogoSlot = {
      id: `logo_${Date.now()}`,
      enabled: true,
      name: `Logo Mitra ${currentList.length + 1}`,
      url: '/assets/aistudio/kso_wiswa_hd.png',
      scale: 1.0,
    };
    onUpdateConfig({ bumperLogos: [...currentList, newSlot], generateTrigger: Date.now() });
  };

  // Upload file for a specific slot in bumperLogos
  const handleSlotLogoUpload = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const nextLogos = [...(config.bumperLogos || [])];
        if (nextLogos[index]) {
          nextLogos[index] = {
            ...nextLogos[index],
            url: dataUrl,
            name: file.name,
            enabled: true,
          };
          onUpdateConfig({ bumperLogos: nextLogos, generateTrigger: Date.now() });
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // Remove slot from bumperLogos
  const handleRemoveBumperSlot = (index: number) => {
    const nextLogos = (config.bumperLogos || []).filter((_, i) => i !== index);
    onUpdateConfig({ bumperLogos: nextLogos, generateTrigger: Date.now() });
  };

  // Add more logo to frameLogos (Frame Video mode)
  const handleAddMoreFrameLogo = () => {
    const currentList = config.frameLogos || [];
    const newSlot: LogoSlot = {
      id: `f_logo_${Date.now()}`,
      enabled: true,
      name: `Logo Frame ${currentList.length + 1}`,
      url: '/assets/aistudio/kso_nke_hd.png',
      scale: 1.0,
    };
    onUpdateConfig({ frameLogos: [...currentList, newSlot], generateTrigger: Date.now() });
  };

  // Upload file for a specific slot in frameLogos
  const handleFrameSlotUpload = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const nextLogos = [...(config.frameLogos || [])];
        if (nextLogos[index]) {
          nextLogos[index] = {
            ...nextLogos[index],
            url: dataUrl,
            name: file.name,
            enabled: true,
          };
          onUpdateConfig({ frameLogos: nextLogos, generateTrigger: Date.now() });
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // Remove slot from frameLogos
  const handleRemoveFrameSlot = (index: number) => {
    const nextLogos = (config.frameLogos || []).filter((_, i) => i !== index);
    onUpdateConfig({ frameLogos: nextLogos, generateTrigger: Date.now() });
  };

  // Video Title custom logo upload
  const handleVideoTitleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        onUpdateConfig({
          titleEmblemUrl: dataUrl,
          titleEmblemEnabled: true,
          generateTrigger: Date.now(),
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // Add more logo to titleLogos (Multiple Logo mode for Video Title)
  const handleAddMoreTitleLogo = () => {
    const currentList = config.titleLogos || [];
    const newSlot: LogoSlot = {
      id: `t_logo_${Date.now()}`,
      enabled: true,
      name: `Logo Mitra ${currentList.length + 1}`,
      url: '/assets/aistudio/kso_wiswa_hd.png',
      scale: 1.0,
    };
    onUpdateConfig({ titleLogos: [...currentList, newSlot], generateTrigger: Date.now() });
  };

  // Upload file for a specific slot in titleLogos
  const handleTitleSlotUpload = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const nextLogos = [...(config.titleLogos || [])];
        if (nextLogos[index]) {
          nextLogos[index] = {
            ...nextLogos[index],
            url: dataUrl,
            name: file.name,
            enabled: true,
          };
          onUpdateConfig({ titleLogos: nextLogos, generateTrigger: Date.now() });
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // Remove slot from titleLogos
  const handleRemoveTitleSlot = (index: number) => {
    const nextLogos = (config.titleLogos || []).filter((_, i) => i !== index);
    onUpdateConfig({ titleLogos: nextLogos, generateTrigger: Date.now() });
  };

  // Test sound effect playback
  const handleTestAudio = () => {
    audioEngine.play(config.audioTheme, config.soundVolume, 0, config.customAudioUrl);
  };

  // Copy full SVG code for selected watermark
  const handleCopySvg = () => {
    const tone = {
      accent1: config.frameAccentColor || '#5C1018',
      accent2: config.frameSecondaryAccent || '#DFCEB5',
      accent3: config.frameTertiaryAccent || '#98AFC3',
      bgCard: config.frameCardBgColor || '#F8F5EE',
    };
    const svgCode = generateWatermarkSvgString(config.frameStyle || 'klasik', tone);
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(svgCode);
    }
    setCopiedSvg(true);
    setTimeout(() => setCopiedSvg(false), 2200);
  };

  // Section title label formatter
  const getSectionTitle = () => {
    switch (activeSection) {
      case 'logo':
        return currentMode === 'video_title'
          ? 'ADD LOGO VIDEO TITLE'
          : currentMode === 'frame_video'
          ? 'MANAGE LOGO FRAME (ADD MORE)'
          : isSingleLogo
          ? 'SINGLE LOGO'
          : 'ADD MORE LOGO (MULTIPLE)';
      case 'background':
        return 'BACKGROUND & COLOR STYLE';
      case 'text':
        return currentMode === 'video_title' ? 'VIDEO TITLE TYPOGRAPHY' : 'TEXT & FONT STYLE';
      case 'effects':
        return 'TRANSISI & EFEK VISUAL';
      case 'frame_style':
        return 'FRAME / WATERMARK VARIATIONS';
      case 'audio':
        return 'AUDIO & SOUNDTRACK';
      default:
        return 'CHOOSE OPTIONS';
    }
  };

  return (
    <div className="flex flex-col gap-3.5 w-full bg-[#181F2B] border-2 border-[#98AFC3]/30 rounded-2xl p-3 shadow-2xl select-none text-[#F8F5EE]">
      {/* Top Banner Header: Warm Sand & Deep Burgundy */}
      <div className="bg-[#5C1018] border border-[#DFCEB5]/40 rounded-xl px-4 py-2.5 flex items-center justify-between shadow-md">
        <div className="flex flex-col">
          <span className="text-base sm:text-lg font-black tracking-wider uppercase text-[#DFCEB5] font-mono">
            CHOOSE
          </span>
          <span className="text-[10px] font-bold text-[#F8F5EE]/90 tracking-wide uppercase">
            {getSectionTitle()}
          </span>
        </div>
        <span className="text-xs px-2.5 py-0.5 rounded bg-[#DFCEB5] text-[#5C1018] font-mono font-bold">
          {currentMode.toUpperCase()}
        </span>
      </div>

      {/* Main Options Box (Styled with Warm Sand & Charcoal Slate) */}
      <div className="bg-[#D9C6AB] border border-[#DFCEB5]/40 rounded-xl p-3 sm:p-4 text-[#181F2B] flex flex-col gap-4 max-h-[720px] overflow-y-auto custom-scrollbar">
        {/* ======================================================== */}
        {/* OPTION SET: ADD LOGO / ADD MORE LOGO                     */}
        {/* ======================================================== */}
        {activeSection === 'logo' && (
          <div className="flex flex-col gap-4">
            {/* 1. SINGLE LOGO: Pure logo focus (NO TEXT STYLE!) */}
            {isSingleLogo && (
              <>
                <div className="flex flex-col gap-2">
                  <span className="text-xs font-black tracking-wider uppercase text-[#3E2916]">
                    PILIH LOGO TUNGGAL (SINGLE LOGO)
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      {
                        name: 'PT Nusa Konstruksi Enjiniring (NKE)',
                        url: '/assets/aistudio/kso_nke_hd.png',
                      },
                      {
                        name: 'PT Jaya Konstruksi',
                        url: '/assets/aistudio/kso_jaya_hd.png',
                      },
                      {
                        name: 'PT Wiswakharman',
                        url: '/assets/aistudio/kso_wiswa_hd.png',
                      },
                      {
                        name: 'KSO Full Konsorsium',
                        url: '/assets/aistudio/kso_full_hd.png',
                      },
                    ].map((item, idx) => {
                      const isSelected = config.singleLogo?.url === item.url;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            onUpdateConfig({
                              singleLogo: {
                                id: `single_${idx}`,
                                enabled: true,
                                name: item.name,
                                url: item.url,
                                scale: config.singleLogoScale || 1.25,
                              },
                              customLogoUrl: item.url,
                              generateTrigger: Date.now(),
                            });
                          }}
                          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-center transition-all ${
                            isSelected
                              ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-2 ring-[#DFCEB5] shadow-md'
                              : 'bg-[#EDE2D3] border-[#DFCEB5] text-[#181F2B] hover:bg-[#E2D4C1]'
                          }`}
                        >
                          <div className="w-14 h-10 flex items-center justify-center p-1 bg-white rounded border border-black/10 mb-1.5 shadow-sm">
                            <img src={item.url} alt={item.name} className="max-w-full max-h-full object-contain" />
                          </div>
                          <span className="text-[11px] font-bold line-clamp-1">{item.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Upload Custom Logo Button */}
                <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <span className="text-[11px] font-bold uppercase text-[#3E2916]">
                    UPLOAD LOGO KUSTOM
                  </span>
                  <label className="flex items-center justify-center gap-2 px-3 py-2 bg-white hover:bg-neutral-50 border border-[#98AFC3] rounded-lg cursor-pointer text-xs font-bold text-[#181F2B] transition-colors shadow-sm">
                    <Upload className="w-3.5 h-3.5 text-[#5C1018]" />
                    <span>PILIH FILE PNG / SVG</span>
                    <input type="file" accept="image/png,image/jpeg,image/svg+xml" onChange={handleSingleLogoUpload} className="hidden" />
                  </label>
                  {config.singleLogo?.url && (
                    <span className="text-[10px] text-[#5B4734] truncate">
                      File aktif: {config.singleLogo.name}
                    </span>
                  )}
                </div>

                {/* Logo Scale Slider */}
                <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <div className="flex items-center justify-between text-xs font-bold text-[#3E2916]">
                    <span>UKURAN SKALA LOGO</span>
                    <span className="font-mono text-[#5C1018]">{((config.singleLogoScale || 1.25) * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.5}
                    max={2.5}
                    step={0.05}
                    value={config.singleLogoScale || 1.25}
                    onChange={(e) => onUpdateConfig({ singleLogoScale: parseFloat(e.target.value) })}
                    className="w-full accent-[#5C1018] h-2 bg-[#D5C2AA] rounded cursor-pointer"
                  />
                </div>
              </>
            )}

            {/* 2. MULTIPLE LOGO: Add More Logo capability */}
            {!isSingleLogo && currentMode === 'bumper_logo' && (
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black tracking-wider uppercase text-[#3E2916]">
                    SLOT LOGO MITRA KONSORSIUM
                  </span>
                  <button
                    type="button"
                    onClick={handleAddMoreBumperLogo}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#5C1018] hover:bg-[#460C12] text-[#DFCEB5] text-xs font-bold transition-all shadow-md active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ ADD MORE LOGO</span>
                  </button>
                </div>

                {/* List of Multiple Logo slots */}
                {(config.bumperLogos || []).map((slot, index) => (
                  <div key={slot.id} className="p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5] flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#181F2B] uppercase">
                        SLOT {index + 1}: {slot.name}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            const nextLogos = [...(config.bumperLogos || [])];
                            nextLogos[index] = { ...slot, enabled: !slot.enabled };
                            onUpdateConfig({ bumperLogos: nextLogos });
                          }}
                          className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                            slot.enabled ? 'bg-[#5C1018] text-[#DFCEB5]' : 'bg-[#C2B097] text-[#5B4734]'
                          }`}
                        >
                          {slot.enabled ? 'Aktif' : 'Nonaktif'}
                        </button>
                        {config.bumperLogos && config.bumperLogos.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveBumperSlot(index)}
                            className="p-1 text-red-600 hover:text-red-800"
                            title="Hapus slot"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="w-12 h-10 flex items-center justify-center p-1 bg-white rounded border border-black/10 shrink-0">
                        {slot.url ? (
                          <img src={slot.url} alt={slot.name} className="max-w-full max-h-full object-contain" />
                        ) : (
                          <ImageIcon className="w-4 h-4 text-neutral-400" />
                        )}
                      </div>
                      <label className="flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5 bg-white hover:bg-neutral-50 border border-[#98AFC3] rounded cursor-pointer text-xs font-bold text-[#181F2B] transition-colors">
                        <Upload className="w-3 h-3 text-[#5C1018]" />
                        <span>Upload Logo</span>
                        <input type="file" accept="image/*" onChange={(e) => handleSlotLogoUpload(index, e)} className="hidden" />
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 3. FRAME VIDEO: Full Add Logo with More button */}
            {currentMode === 'frame_video' && (
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black tracking-wider uppercase text-[#3E2916]">
                    LOGO WATERMARK SUDUT (FRAME VIDEO)
                  </span>
                  <button
                    type="button"
                    onClick={handleAddMoreFrameLogo}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#5C1018] hover:bg-[#460C12] text-[#DFCEB5] text-xs font-bold transition-all shadow-md active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ ADD MORE LOGO</span>
                  </button>
                </div>

                {(config.frameLogos || []).map((slot, index) => (
                  <div key={slot.id} className="p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5] flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#181F2B]">LOGO {index + 1}: {slot.name}</span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            const nextLogos = [...(config.frameLogos || [])];
                            nextLogos[index] = { ...slot, enabled: !slot.enabled };
                            onUpdateConfig({ frameLogos: nextLogos });
                          }}
                          className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                            slot.enabled ? 'bg-[#5C1018] text-[#DFCEB5]' : 'bg-[#C2B097] text-[#5B4734]'
                          }`}
                        >
                          {slot.enabled ? 'Aktif' : 'Nonaktif'}
                        </button>
                        {config.frameLogos && config.frameLogos.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveFrameSlot(index)}
                            className="p-1 text-red-600 hover:text-red-800"
                            title="Hapus logo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="w-12 h-10 flex items-center justify-center p-1 bg-white rounded border border-black/10 shrink-0">
                        {slot.url ? <img src={slot.url} alt={slot.name} className="max-w-full max-h-full object-contain" /> : <ImageIcon className="w-4 h-4 text-neutral-400" />}
                      </div>
                      <label className="flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5 bg-white hover:bg-neutral-50 border border-[#98AFC3] rounded cursor-pointer text-xs font-bold text-[#181F2B] transition-colors">
                        <Upload className="w-3 h-3 text-[#5C1018]" />
                        <span>Upload Logo</span>
                        <input type="file" accept="image/*" onChange={(e) => handleFrameSlotUpload(index, e)} className="hidden" />
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 4. VIDEO TITLE: EMBLEM / LOGO MANAGEMENT */}
            {currentMode === 'video_title' && (
              <div className="flex flex-col gap-3.5">
                {/* Master Toggle */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5] shadow-sm">
                  <div className="flex flex-col">
                    <span className="text-xs font-black text-[#181F2B] uppercase">Tampilkan Logo di Video Title</span>
                    <span className="text-[11px] text-[#7A6451]">Aktifkan atau sembunyikan logo di atas judul video</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateConfig({ titleEmblemEnabled: !config.titleEmblemEnabled, generateTrigger: Date.now() })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      config.titleEmblemEnabled !== false ? 'bg-[#5C1018]' : 'bg-[#C2B097]'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        config.titleEmblemEnabled !== false ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {config.titleEmblemEnabled !== false && (
                  <>
                    {/* Sub Mode Selector: Single Logo vs Multiple Logo */}
                    <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#C9B69B] rounded-lg border border-[#DFCEB5]">
                      <button
                        type="button"
                        onClick={() => onUpdateConfig({ titleLogoMode: 'single', generateTrigger: Date.now() })}
                        className={`py-1.5 px-2 text-xs font-bold rounded-md transition-all text-center ${
                          config.titleLogoMode !== 'multiple'
                            ? 'bg-[#5C1018] text-[#F8F5EE] shadow-sm font-black'
                            : 'text-[#3E2916] hover:bg-black/5'
                        }`}
                      >
                        1 LOGO / EMBLEM UTAMA
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateConfig({ titleLogoMode: 'multiple', generateTrigger: Date.now() })}
                        className={`py-1.5 px-2 text-xs font-bold rounded-md transition-all text-center ${
                          config.titleLogoMode === 'multiple'
                            ? 'bg-[#5C1018] text-[#F8F5EE] shadow-sm font-black'
                            : 'text-[#3E2916] hover:bg-black/5'
                        }`}
                      >
                        MULTIPLE LOGO MITRA
                      </button>
                    </div>

                    {/* SINGLE LOGO MODE */}
                    {config.titleLogoMode !== 'multiple' ? (
                      <div className="flex flex-col gap-3">
                        {/* Presets Grid */}
                        <div className="flex flex-col gap-1.5">
                          <span className="text-[11px] font-black uppercase text-[#3E2916]">
                            PILIH LOGO RESMI ATAU EMBLEM:
                          </span>
                          <div className="grid grid-cols-2 gap-2">
                            {[
                              {
                                name: 'Pohon Hayat IKN',
                                desc: 'Emblem Emas Resmi IKN',
                                url: '',
                                isVector: true,
                              },
                              {
                                name: 'PT Nusa Konstruksi Enjiniring',
                                desc: 'Logo Resmi NKE, Tbk',
                                url: '/assets/aistudio/kso_nke_hd.png',
                              },
                              {
                                name: 'PT Jaya Konstruksi',
                                desc: 'Logo Jaya Konstruksi',
                                url: '/assets/aistudio/kso_jaya_hd.png',
                              },
                              {
                                name: 'PT Wiswakharman',
                                desc: 'Logo Wiswakharman',
                                url: '/assets/aistudio/kso_wiswa_hd.png',
                              },
                              {
                                name: 'KSO Konsorsium',
                                desc: 'Nusa Jaya Wiswakharman',
                                url: '/assets/aistudio/LOGO_KSO_HD_vektor_edcea276.png',
                              },
                              {
                                name: 'Simbol Proyek',
                                desc: 'Simbol Hunian Vertikal',
                                url: '/assets/aistudio/image_460651e4.png',
                              },
                            ].map((preset, idx) => {
                              const isSelected = (!preset.url && !config.titleEmblemUrl) || config.titleEmblemUrl === preset.url;
                              return (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() => {
                                    onUpdateConfig({
                                      titleEmblemUrl: preset.url,
                                      titleEmblemEnabled: true,
                                      generateTrigger: Date.now(),
                                    });
                                  }}
                                  className={`p-2.5 rounded-xl border text-left transition-all flex flex-col gap-1.5 ${
                                    isSelected
                                      ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-2 ring-[#DFCEB5] shadow-md'
                                      : 'bg-[#EDE2D3] border-[#DFCEB5] text-[#181F2B] hover:bg-[#E2D4C1]'
                                  }`}
                                >
                                  <div className="flex items-center justify-between w-full">
                                    <div className="w-9 h-7 rounded bg-white flex items-center justify-center p-0.5 border border-black/10 overflow-hidden">
                                      {preset.url ? (
                                        <img src={preset.url} alt={preset.name} className="max-w-full max-h-full object-contain" />
                                      ) : (
                                        <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-600 to-amber-300 flex items-center justify-center text-[10px] text-white font-bold">
                                          IKN
                                        </div>
                                      )}
                                    </div>
                                    {isSelected && <Check className="w-4 h-4 text-[#DFCEB5]" />}
                                  </div>
                                  <div>
                                    <span className="text-xs font-bold leading-tight block truncate">{preset.name}</span>
                                    <span className={`text-[10px] block truncate ${isSelected ? 'text-[#DFCEB5]' : 'text-[#7A6451]'}`}>
                                      {preset.desc}
                                    </span>
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Upload Custom Logo Button */}
                        <div className="p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5] flex flex-col gap-2">
                          <span className="text-[11px] font-black uppercase text-[#3E2916]">
                            ATAU UPLOAD LOGO KUSTOM ANDA:
                          </span>
                          <div className="flex items-center gap-2">
                            <label className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-[#5C1018] hover:bg-[#4E0E15] text-[#DFCEB5] rounded-lg cursor-pointer text-xs font-bold transition-colors shadow-sm">
                              <Upload className="w-4 h-4" />
                              <span>Pilih File Logo (PNG/SVG)</span>
                              <input type="file" accept="image/*" onChange={handleVideoTitleLogoUpload} className="hidden" />
                            </label>

                            {Boolean(config.titleEmblemUrl) && (
                              <button
                                type="button"
                                onClick={() => onUpdateConfig({ titleEmblemUrl: '', generateTrigger: Date.now() })}
                                className="px-3 py-2 bg-white hover:bg-neutral-100 border border-[#DFCEB5] text-[#5C1018] text-xs font-bold rounded-lg transition-colors"
                              >
                                Reset ke Pohon Hayat
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Logo Scale Slider */}
                        <div className="p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5] flex flex-col gap-2">
                          <div className="flex items-center justify-between text-xs font-bold">
                            <span className="text-[#181F2B] flex items-center gap-1.5">
                              <Sliders className="w-3.5 h-3.5 text-[#5C1018]" />
                              <span>Ukuran Logo Video Title</span>
                            </span>
                            <span className="px-2 py-0.5 rounded bg-[#5C1018] text-[#DFCEB5] font-mono text-[11px]">
                              {Math.round((config.titleLogoScale || 1.0) * 100)}%
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0.5"
                            max="2.0"
                            step="0.05"
                            value={config.titleLogoScale || 1.0}
                            onChange={(e) => onUpdateConfig({ titleLogoScale: parseFloat(e.target.value), generateTrigger: Date.now() })}
                            className="w-full accent-[#5C1018] h-1.5 bg-[#DFCEB5] rounded-lg cursor-pointer"
                          />
                        </div>

                        {/* Halo Glow Toggle */}
                        <div className="flex items-center justify-between p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                          <div className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-[#5C1018]" />
                            <div className="flex flex-col">
                              <span className="text-xs font-bold text-[#181F2B]">Efek Cahaya Halo Keemasan</span>
                              <span className="text-[10px] text-[#7A6451]">Pendaran aura bernafas di belakang logo</span>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => onUpdateConfig({ titleLogoGlow: config.titleLogoGlow === false ? true : false, generateTrigger: Date.now() })}
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                              config.titleLogoGlow !== false ? 'bg-[#5C1018]' : 'bg-[#C2B097]'
                            }`}
                          >
                            <span
                              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                config.titleLogoGlow !== false ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* MULTIPLE LOGO MITRA MODE */
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-black uppercase text-[#3E2916]">
                            BARIS LOGO MITRA / KONSORSIUM ({config.titleLogos?.filter((s) => s.enabled).length || 0} AKTIF)
                          </span>
                          <button
                            type="button"
                            onClick={handleAddMoreTitleLogo}
                            className="flex items-center gap-1 px-2.5 py-1 bg-[#5C1018] hover:bg-[#4E0E15] text-[#DFCEB5] rounded-lg text-xs font-bold transition-colors shadow-sm"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Tambah Logo</span>
                          </button>
                        </div>

                        <div className="flex flex-col gap-2">
                          {(config.titleLogos || []).map((slot, index) => (
                            <div
                              key={slot.id || index}
                              className={`p-2.5 rounded-xl border flex flex-col gap-2 transition-all ${
                                slot.enabled ? 'bg-[#EDE2D3] border-[#DFCEB5]' : 'bg-[#E5D7C4]/60 border-[#DFCEB5]/50 opacity-60'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={slot.enabled}
                                    onChange={(e) => {
                                      const next = [...(config.titleLogos || [])];
                                      next[index] = { ...next[index], enabled: e.target.checked };
                                      onUpdateConfig({ titleLogos: next, generateTrigger: Date.now() });
                                    }}
                                    className="accent-[#5C1018] w-4 h-4 rounded cursor-pointer"
                                  />
                                  <span className="text-xs font-bold text-[#181F2B]">
                                    {slot.name || `Mitra ${index + 1}`}
                                  </span>
                                </label>

                                {(config.titleLogos || []).length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveTitleSlot(index)}
                                    className="p-1 hover:bg-black/10 text-red-700 rounded transition-colors"
                                    title="Hapus slot"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                <div className="w-12 h-10 flex items-center justify-center p-1 bg-white rounded border border-black/10 shrink-0">
                                  {slot.url ? (
                                    <img src={slot.url} alt={slot.name} className="max-w-full max-h-full object-contain" />
                                  ) : (
                                    <ImageIcon className="w-4 h-4 text-neutral-400" />
                                  )}
                                </div>
                                <label className="flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5 bg-white hover:bg-neutral-50 border border-[#98AFC3] rounded cursor-pointer text-xs font-bold text-[#181F2B] transition-colors">
                                  <Upload className="w-3 h-3 text-[#5C1018]" />
                                  <span>Ganti Logo</span>
                                  <input type="file" accept="image/*" onChange={(e) => handleTitleSlotUpload(index, e)} className="hidden" />
                                </label>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Multiple Logos Scale Slider */}
                        <div className="p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5] flex flex-col gap-2">
                          <div className="flex items-center justify-between text-xs font-bold">
                            <span className="text-[#181F2B] flex items-center gap-1.5">
                              <Sliders className="w-3.5 h-3.5 text-[#5C1018]" />
                              <span>Ukuran Baris Logo Mitra</span>
                            </span>
                            <span className="px-2 py-0.5 rounded bg-[#5C1018] text-[#DFCEB5] font-mono text-[11px]">
                              {Math.round((config.titleLogoScale || 1.0) * 100)}%
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0.5"
                            max="1.8"
                            step="0.05"
                            value={config.titleLogoScale || 1.0}
                            onChange={(e) => onUpdateConfig({ titleLogoScale: parseFloat(e.target.value), generateTrigger: Date.now() })}
                            className="w-full accent-[#5C1018] h-1.5 bg-[#DFCEB5] rounded-lg cursor-pointer"
                          />
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* OPTION SET: EFFECT STYLE (DIVIDED: TRANSISI & EFEK)      */}
        {/* ======================================================== */}
        {activeSection === 'effects' && (
          <div className="flex flex-col gap-4">
            {/* 1. BAGIAN TRANSISI (TRANSITION ANIMATION) */}
            <div className="flex flex-col gap-2">
              <span className="text-xs font-black tracking-wider uppercase text-[#3E2916] flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#5C1018]" />
                <span>1. TRANSISI ANIMASI LOGO</span>
              </span>

              {/* If Single Logo: User requested A. PUZZLE, B. FADED, C. COME FROM ANYWHERE */}
              {isSingleLogo ? (
                <div className="grid grid-cols-1 gap-2">
                  {[
                    {
                      id: 'puzzle_assemble',
                      label: 'A. PUZZLE POTONGAN KECIL SESUAI WARNA',
                      desc: 'Potongan puzzle kecil-kecil sesuai warna biru, oranye, dan hijau saling mengunci rapat',
                      icon: Puzzle,
                    },
                    {
                      id: 'faded',
                      label: 'B. FADED',
                      desc: 'Transisi blur optik lembut & perbesaran mikro sinematik',
                      icon: Eye,
                    },
                    {
                      id: 'come_from_anywhere',
                      label: 'C. COME FROM EVERYWHERE (WIND STICKER)',
                      desc: 'Efek hembusan angin membuka stiker logo berkibar lalu menempel sempurna',
                      icon: Wind,
                    },
                  ].map((tr) => {
                    const isSelected = config.singleLogoAnimation === tr.id;
                    const Icon = tr.icon;
                    return (
                      <button
                        key={tr.id}
                        type="button"
                        onClick={() => {
                          onUpdateConfig({
                            singleLogoAnimation: tr.id as SingleLogoAnimation,
                            singleLogoTransition: tr.id as SingleLogoAnimation,
                            generateTrigger: Date.now(),
                          });
                        }}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-2 ring-[#DFCEB5] shadow-md'
                            : 'bg-[#EDE2D3] border-[#DFCEB5] text-[#181F2B] hover:bg-[#E2D4C1]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4" />
                            <span className="text-xs font-bold block">{tr.label}</span>
                          </div>
                          {isSelected && <Check className="w-4 h-4 text-[#DFCEB5]" />}
                        </div>
                        <span className={`text-[11px] mt-1 block leading-relaxed ${isSelected ? 'text-[#DFCEB5]' : 'text-[#7A6451]'}`}>
                          {tr.desc}
                        </span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                /* If Multiple Logo: User requested A. SATU-SATU MUNCUL LALU KEKIRI, B. SATU-SATU MUNCUL LALU KEATAS */
                <div className="grid grid-cols-1 gap-2">
                  {[
                    {
                      id: 'slide_left',
                      label: 'A. LOGO SATU-SATU MUNCUL, LALU KEKIRI',
                      desc: 'Logo muncul berurutan di tengah lalu bergeser halus ke kiri membuka judul',
                      icon: MoveLeft,
                    },
                    {
                      id: 'slide_up',
                      label: 'B. LOGO SATU-SATU MUNCUL, LALU KEATAS',
                      desc: 'Logo muncul berurutan di tengah lalu bergeser halus ke atas membuka judul',
                      icon: MoveUp,
                    },
                  ].map((tr) => {
                    const isSelected = config.transitionStyle === tr.id;
                    const Icon = tr.icon;
                    return (
                      <button
                        key={tr.id}
                        type="button"
                        onClick={() => {
                          onUpdateConfig({
                            transitionStyle: tr.id as TransitionStyle,
                            generateTrigger: Date.now(),
                          });
                        }}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-2 ring-[#DFCEB5] shadow-md'
                            : 'bg-[#EDE2D3] border-[#DFCEB5] text-[#181F2B] hover:bg-[#E2D4C1]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4" />
                            <span className="text-xs font-bold block">{tr.label}</span>
                          </div>
                          {isSelected && <Check className="w-4 h-4 text-[#DFCEB5]" />}
                        </div>
                        <span className={`text-[11px] mt-1 block leading-relaxed ${isSelected ? 'text-[#DFCEB5]' : 'text-[#7A6451]'}`}>
                          {tr.desc}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* 2. BAGIAN EFEK VISUAL (SEPARATED VISUAL EFFECTS) */}
            <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
              <span className="text-xs font-black uppercase text-[#3E2916] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#5C1018]" />
                <span>2. EFEK VISUAL & LIGHTING (OPTIONAL)</span>
              </span>

              <div className="grid grid-cols-2 gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => onUpdateConfig({ anamorphicFlare: !config.anamorphicFlare, generateTrigger: Date.now() })}
                  className={`p-2.5 rounded-lg border text-xs font-bold transition-all text-left flex items-center justify-between ${
                    config.anamorphicFlare ? 'bg-[#5C1018] text-[#DFCEB5] border-[#5C1018]' : 'bg-white text-[#181F2B] border-[#DFCEB5]'
                  }`}
                >
                  <span>Anamorphic Flare</span>
                  {config.anamorphicFlare && <Check className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => onUpdateConfig({ laserScanline: !config.laserScanline, generateTrigger: Date.now() })}
                  className={`p-2.5 rounded-lg border text-xs font-bold transition-all text-left flex items-center justify-between ${
                    config.laserScanline ? 'bg-[#5C1018] text-[#DFCEB5] border-[#5C1018]' : 'bg-white text-[#181F2B] border-[#DFCEB5]'
                  }`}
                >
                  <span>Laser Scanline</span>
                  {config.laserScanline && <Check className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => onUpdateConfig({ cyberHexMesh: !config.cyberHexMesh, generateTrigger: Date.now() })}
                  className={`p-2.5 rounded-lg border text-xs font-bold transition-all text-left flex items-center justify-between ${
                    config.cyberHexMesh ? 'bg-[#5C1018] text-[#DFCEB5] border-[#5C1018]' : 'bg-white text-[#181F2B] border-[#DFCEB5]'
                  }`}
                >
                  <span>Cyber Hex Mesh</span>
                  {config.cyberHexMesh && <Check className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => onUpdateConfig({ vignette: !config.vignette, generateTrigger: Date.now() })}
                  className={`p-2.5 rounded-lg border text-xs font-bold transition-all text-left flex items-center justify-between ${
                    config.vignette ? 'bg-[#5C1018] text-[#DFCEB5] border-[#5C1018]' : 'bg-white text-[#181F2B] border-[#DFCEB5]'
                  }`}
                >
                  <span>Vignette Shadow</span>
                  {config.vignette && <Check className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* OPTION SET: FRAME STYLE (14 OFFICIAL MODELS + TONE CONTROLS) */}
        {/* ======================================================== */}
        {activeSection === 'frame_style' && (
          <div className="flex flex-col gap-4">
            {/* 1. PENGATURAN TONE & LATAR (WARNA & TEMA) */}
            <div className="flex flex-col gap-2.5 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black tracking-wider uppercase text-[#3E2916] flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-[#5C1018]" />
                  <span>TONE PENGATURAN WARNA & LATAR</span>
                </span>
                <span className="text-[10px] font-bold text-[#7A6451] uppercase">NKE × UNP</span>
              </div>

              {/* Mode Latar Preview */}
              <div>
                <label className="text-[10px] font-bold uppercase text-[#5B4734] mb-1.5 block">
                  PILIH LATAR KANVAS PREVIEW
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'slate', name: 'Base Slate #181F2B', desc: 'Latar standar palet', color: '#181F2B' },
                    { id: 'putih', name: 'Soft Cream #F8F5EE', desc: 'Latar terang palet', color: '#F8F5EE' },
                    { id: 'video', name: 'Contoh Video', desc: 'Gradasi sinematik burgundy', gradient: true },
                    { id: 'alpha', name: 'Transparan', desc: 'Pola alpha PNG video', alpha: true },
                  ].map((bg) => {
                    const isSelected = (config.frameBackgroundMode || 'slate') === bg.id;
                    return (
                      <button
                        key={bg.id}
                        type="button"
                        onClick={() => {
                          onUpdateConfig({
                            studioMode: 'frame_video',
                            frameBackgroundMode: bg.id as FrameBackgroundMode,
                            generateTrigger: Date.now(),
                          });
                        }}
                        className={`p-2 rounded-lg border text-left transition-all ${
                          isSelected
                            ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-1 ring-[#DFCEB5] shadow-sm'
                            : 'bg-white border-[#DFCEB5] text-[#181F2B] hover:bg-[#F8F5EE]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-0.5">
                          <div className="flex items-center gap-1.5">
                            {bg.alpha ? (
                              <span className="w-3 h-3 rounded-full border border-black/20 bg-[repeating-conic-gradient(#bbb_0%_25%,#fff_0%_50%)] bg-[length:6px_6px]" />
                            ) : bg.gradient ? (
                              <span className="w-3 h-3 rounded-full border border-black/20 bg-gradient-to-r from-[#181F2B] via-[#4E0E15] to-[#1A0609]" />
                            ) : (
                              <span
                                className="w-3 h-3 rounded-full border border-black/20"
                                style={{ backgroundColor: bg.color }}
                              />
                            )}
                            <span className="text-xs font-bold">{bg.name}</span>
                          </div>
                          {isSelected && <Check className="w-3.5 h-3.5 text-[#DFCEB5]" />}
                        </div>
                        <span className={`text-[10px] block ${isSelected ? 'text-[#DFCEB5]' : 'text-[#7A6451]'}`}>
                          {bg.desc}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Warna Aksen Watermark Pickers */}
              <div className="pt-2 border-t border-black/10 flex flex-col gap-2">
                <span className="text-[10px] font-bold uppercase text-[#5B4734]">
                  PALET AKSEN WATERMARK (TONE PENYESUAIAN)
                </span>

                <div className="grid grid-cols-2 gap-2">
                  {/* Aksen 1 */}
                  <div className="p-2 rounded-lg bg-white/70 border border-[#DFCEB5]">
                    <div className="flex items-center justify-between text-[10px] font-bold text-[#3E2916]">
                      <span>AKSEN 1 (BURGUNDY UTAMA)</span>
                      <span className="font-mono text-[#5C1018]">{config.frameAccentColor || '#5C1018'}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="color"
                        value={config.frameAccentColor || '#5C1018'}
                        onChange={(e) =>
                          onUpdateConfig({ frameAccentColor: e.target.value, generateTrigger: Date.now() })
                        }
                        className="w-8 h-7 rounded cursor-pointer border border-[#98AFC3]"
                      />
                      <div className="flex items-center gap-1">
                        {['#5C1018', '#68131B', '#3E0D12', '#98AFC3'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            title={c}
                            onClick={() => onUpdateConfig({ frameAccentColor: c, generateTrigger: Date.now() })}
                            className={`w-5 h-5 rounded-full border ${
                              (config.frameAccentColor || '#5C1018') === c
                                ? 'ring-2 ring-[#5C1018] border-white scale-110'
                                : 'border-black/20'
                            }`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Aksen 2 */}
                  <div className="p-2 rounded-lg bg-white/70 border border-[#DFCEB5]">
                    <div className="flex items-center justify-between text-[10px] font-bold text-[#3E2916]">
                      <span>AKSEN 2 (WARM SAND / EMAS)</span>
                      <span className="font-mono text-[#5C1018]">{config.frameSecondaryAccent || '#DFCEB5'}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="color"
                        value={config.frameSecondaryAccent || '#DFCEB5'}
                        onChange={(e) =>
                          onUpdateConfig({ frameSecondaryAccent: e.target.value, generateTrigger: Date.now() })
                        }
                        className="w-8 h-7 rounded cursor-pointer border border-[#98AFC3]"
                      />
                      <div className="flex items-center gap-1">
                        {['#DFCEB5', '#D9C6AB', '#EDE2D3', '#F8F5EE'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            title={c}
                            onClick={() => onUpdateConfig({ frameSecondaryAccent: c, generateTrigger: Date.now() })}
                            className={`w-5 h-5 rounded-full border ${
                              (config.frameSecondaryAccent || '#DFCEB5') === c
                                ? 'ring-2 ring-[#5C1018] border-white scale-110'
                                : 'border-black/20'
                            }`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {/* Aksen 3 */}
                  <div className="p-2 rounded-lg bg-white/70 border border-[#DFCEB5]">
                    <div className="flex items-center justify-between text-[10px] font-bold text-[#3E2916]">
                      <span>AKSEN 3 (DUSTY SLATE)</span>
                      <span className="font-mono text-[#5C1018]">{config.frameTertiaryAccent || '#98AFC3'}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="color"
                        value={config.frameTertiaryAccent || '#98AFC3'}
                        onChange={(e) =>
                          onUpdateConfig({ frameTertiaryAccent: e.target.value, generateTrigger: Date.now() })
                        }
                        className="w-8 h-7 rounded cursor-pointer border border-[#98AFC3]"
                      />
                      <div className="flex items-center gap-1">
                        {['#98AFC3', '#7D95A9', '#181F2B', '#5C1018'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            title={c}
                            onClick={() => onUpdateConfig({ frameTertiaryAccent: c, generateTrigger: Date.now() })}
                            className={`w-5 h-5 rounded-full border ${
                              (config.frameTertiaryAccent || '#98AFC3') === c
                                ? 'ring-2 ring-[#5C1018] border-white scale-110'
                                : 'border-black/20'
                            }`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Warna Latar Kartu */}
                  <div className="p-2 rounded-lg bg-white/70 border border-[#DFCEB5]">
                    <div className="flex items-center justify-between text-[10px] font-bold text-[#3E2916]">
                      <span>LATAR KARTU WATERMARK</span>
                      <span className="font-mono text-[#5C1018]">{config.frameCardBgColor || '#F8F5EE'}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="color"
                        value={config.frameCardBgColor || '#F8F5EE'}
                        onChange={(e) =>
                          onUpdateConfig({ frameCardBgColor: e.target.value, generateTrigger: Date.now() })
                        }
                        className="w-8 h-7 rounded cursor-pointer border border-[#98AFC3]"
                      />
                      <div className="flex items-center gap-1">
                        {['#F8F5EE', '#FFFFFF', '#EDE2D3', '#DFCEB5'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            title={c}
                            onClick={() => onUpdateConfig({ frameCardBgColor: c, generateTrigger: Date.now() })}
                            className={`w-5 h-5 rounded-full border ${
                              (config.frameCardBgColor || '#F8F5EE') === c
                                ? 'ring-2 ring-[#5C1018] border-black scale-110'
                                : 'border-black/20'
                            }`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. PENGATURAN UKURAN & BAYANGAN (SCALE & GLOW) */}
            <div className="flex flex-col gap-3 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black tracking-wider uppercase text-[#3E2916] flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-[#5C1018]" />
                  <span>UKURAN & EFEK BAYANGAN</span>
                </span>
                <button
                  type="button"
                  onClick={handleCopySvg}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#5C1018] text-[#DFCEB5] hover:bg-[#460C12] text-[10px] font-black uppercase tracking-wider transition-all shadow-sm"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copiedSvg ? 'TERSALIN!' : 'SALIN KODE SVG'}</span>
                </button>
              </div>

              {/* Slider Ukuran Watermark (70% - 130%) */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px] font-bold text-[#3E2916]">
                  <span>UKURAN WATERMARK (18.75% KANVAS)</span>
                  <span className="font-mono text-[#5C1018] font-bold">
                    {Math.round((config.frameWatermarkScale || 1.0) * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0.7}
                  max={1.3}
                  step={0.01}
                  value={config.frameWatermarkScale || 1.0}
                  onChange={(e) =>
                    onUpdateConfig({
                      frameWatermarkScale: parseFloat(e.target.value),
                      generateTrigger: Date.now(),
                    })
                  }
                  className="w-full accent-[#5C1018] h-2 bg-[#D5C2AA] rounded cursor-pointer"
                />
                <div className="flex justify-between text-[9px] text-[#7A6451] font-mono">
                  <span>70%</span>
                  <span>100% (STANDAR)</span>
                  <span>130%</span>
                </div>
              </div>

              {/* Slider Glow / Bayangan */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px] font-bold text-[#3E2916]">
                  <span>INTENSITAS BAYANGAN & GLOW</span>
                  <span className="font-mono text-[#5C1018] font-bold">
                    {Math.round((config.frameGlowIntensity || 0.7) * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1.0}
                  step={0.05}
                  value={config.frameGlowIntensity ?? 0.7}
                  onChange={(e) =>
                    onUpdateConfig({
                      frameGlowIntensity: parseFloat(e.target.value),
                      generateTrigger: Date.now(),
                    })
                  }
                  className="w-full accent-[#5C1018] h-2 bg-[#D5C2AA] rounded cursor-pointer"
                />
              </div>
            </div>

            {/* 3. 14 MODEL WATERMARK RESMI DARI TEMPLATE (HAPUS YANG BIKINAN SENDIRI) */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black tracking-wider uppercase text-[#3E2916] flex items-center gap-1.5">
                  <Box className="w-4 h-4 text-[#5C1018]" />
                  <span>14 MODEL FRAME WATERMARK RESMI</span>
                </span>
                <span className="text-[10px] font-bold text-[#5C1018] bg-white/70 px-2 py-0.5 rounded border border-[#DFCEB5]">
                  14 PILIHAN LENGKAP
                </span>
              </div>
              <p className="text-[11px] text-[#5B4734] leading-relaxed">
                Pilih model resmi NKE × UNP untuk pratinjau di sudut kanan atas kanvas. Semua model diekstrak presisi dari template resmi.
              </p>

              <div className="grid grid-cols-1 gap-2 mt-1">
                {WATERMARK_VARIATIONS.map((fs, idx) => {
                  const isSelected = config.frameStyle === fs.id;
                  const numStr = String(idx + 1).padStart(2, '0');
                  return (
                    <button
                      key={fs.id}
                      type="button"
                      onClick={() => {
                        onUpdateConfig({
                          studioMode: 'frame_video',
                          frameStyle: fs.id as FrameStyle,
                          generateTrigger: Date.now(),
                        });
                      }}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-2 ring-[#DFCEB5] shadow-lg scale-[1.01]'
                          : 'bg-[#EDE2D3] border-[#DFCEB5] text-[#181F2B] hover:bg-[#E2D4C1]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[10px] font-black px-1.5 py-0.5 rounded font-mono ${
                              isSelected ? 'bg-[#DFCEB5] text-[#5C1018]' : 'bg-black/10 text-[#3E2916]'
                            }`}
                          >
                            {numStr}
                          </span>
                          <span className="text-xs font-extrabold tracking-wide uppercase">{fs.name}</span>
                        </div>
                        {isSelected && (
                          <div className="flex items-center gap-1 bg-[#DFCEB5] text-[#5C1018] px-2 py-0.5 rounded text-[10px] font-black uppercase">
                            <Check className="w-3.5 h-3.5" />
                            <span>AKTIF</span>
                          </div>
                        )}
                      </div>
                      <span
                        className={`text-[11px] block leading-relaxed ${
                          isSelected ? 'text-[#DFCEB5]' : 'text-[#5B4734]'
                        }`}
                      >
                        {fs.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* OPTION SET: BACKGROUND STYLE                             */}
        {/* ======================================================== */}
        {activeSection === 'background' && (
          <div className="flex flex-col gap-4">
            {/* 1. Tipe Latar Belakang */}
            <div className="flex flex-col gap-2">
              <span className="text-xs font-black tracking-wider uppercase text-[#3E2916]">
                TIPE LATAR BELAKANG
              </span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'gradient', name: 'Gradasi Sinematik', desc: 'Perpaduan dua warna' },
                  { id: 'solid', name: 'Warna Solid Pekat', desc: 'Satu warna penuh' },
                  { id: 'particles', name: 'Partikel Cahaya', desc: 'Pendar debu sinematik' },
                  { id: 'technical_grid', name: 'Arsitektural Grid', desc: 'Garis CAD teknis' },
                ].map((bg) => {
                  const isSelected =
                    config.backgroundStyle === bg.id ||
                    (bg.id === 'technical_grid' && config.backgroundStyle === 'technical_grid');
                  return (
                    <button
                      key={bg.id}
                      type="button"
                      onClick={() => {
                        if (bg.id === 'technical_grid') {
                          onUpdateConfig({
                            backgroundStyle: 'technical_grid',
                            showGrid: true,
                            generateTrigger: Date.now(),
                          });
                        } else if (bg.id === 'particles') {
                          onUpdateConfig({
                            backgroundStyle: 'particles',
                            particleCount: 90,
                            generateTrigger: Date.now(),
                          });
                        } else {
                          onUpdateConfig({
                            backgroundStyle: bg.id as BackgroundStyle,
                            generateTrigger: Date.now(),
                          });
                        }
                      }}
                      className={`p-2.5 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-2 ring-[#DFCEB5] shadow-md'
                          : 'bg-[#EDE2D3] border-[#DFCEB5] text-[#181F2B] hover:bg-[#E2D4C1]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold block">{bg.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#DFCEB5]" />}
                      </div>
                      <span className={`text-[10px] mt-0.5 block ${isSelected ? 'text-[#DFCEB5]' : 'text-[#7A6451]'}`}>
                        {bg.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Background Color Pickers with Quick Swatches */}
            <div className="flex flex-col gap-3 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
              <div className="grid grid-cols-2 gap-3">
                {/* Warna Latar 1 */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black uppercase text-[#3E2916]">WARNA LATAR 1</label>
                    <span className="font-mono text-[10px] text-[#5C1018] font-bold">
                      {config.backgroundColor || '#181F2B'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={config.backgroundColor || '#181F2B'}
                      onChange={(e) =>
                        onUpdateConfig({ backgroundColor: e.target.value, generateTrigger: Date.now() })
                      }
                      className="w-10 h-8 rounded cursor-pointer bg-white border border-[#98AFC3] p-0.5"
                    />
                    <div className="flex items-center gap-1 flex-wrap">
                      {['#181F2B', '#5C1018', '#0B0E14', '#3A0E14', '#F8F5EE'].map((c) => (
                        <button
                          key={c}
                          type="button"
                          title={c}
                          onClick={() => onUpdateConfig({ backgroundColor: c, generateTrigger: Date.now() })}
                          className={`w-5 h-5 rounded-full border ${
                            (config.backgroundColor || '#181F2B') === c
                              ? 'ring-2 ring-[#5C1018] scale-110 border-white'
                              : 'border-black/20'
                          }`}
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {/* Warna Latar 2 */}
                <div className={`flex flex-col gap-1.5 ${config.backgroundStyle === 'solid' ? 'opacity-40' : ''}`}>
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black uppercase text-[#3E2916]">
                      WARNA LATAR 2 {config.backgroundStyle === 'solid' && '(Gradasi)'}
                    </label>
                    <span className="font-mono text-[10px] text-[#5C1018] font-bold">
                      {config.backgroundSecondaryColor || '#3A0E14'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      disabled={config.backgroundStyle === 'solid'}
                      value={config.backgroundSecondaryColor || '#3A0E14'}
                      onChange={(e) =>
                        onUpdateConfig({ backgroundSecondaryColor: e.target.value, generateTrigger: Date.now() })
                      }
                      className="w-10 h-8 rounded cursor-pointer bg-white border border-[#98AFC3] p-0.5 disabled:cursor-not-allowed"
                    />
                    <div className="flex items-center gap-1 flex-wrap">
                      {['#3A0E14', '#181F2B', '#5C1018', '#070D19', '#DFCEB5'].map((c) => (
                        <button
                          key={c}
                          type="button"
                          disabled={config.backgroundStyle === 'solid'}
                          title={c}
                          onClick={() => onUpdateConfig({ backgroundSecondaryColor: c, generateTrigger: Date.now() })}
                          className={`w-5 h-5 rounded-full border ${
                            (config.backgroundSecondaryColor || '#3A0E14') === c
                              ? 'ring-2 ring-[#5C1018] scale-110 border-white'
                              : 'border-black/20'
                          }`}
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 3. Sorot Lampu Spotlight */}
            <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-[#181F2B] uppercase">SOROT LAMPU SPOTLIGHT</span>
                  <span className="text-[10px] text-[#7A6451]">Pendaran lingkaran cahaya di tengah latar</span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onUpdateConfig({
                      spotlightEnabled: !config.spotlightEnabled,
                      generateTrigger: Date.now(),
                    })
                  }
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    config.spotlightEnabled ? 'bg-[#5C1018]' : 'bg-[#C2B097]'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      config.spotlightEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              {config.spotlightEnabled && (
                <div className="flex flex-col gap-2.5 mt-2 pt-2 border-t border-black/10">
                  {/* Intensitas Sorot */}
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center justify-between text-[11px] font-bold text-[#3E2916]">
                      <span>INTENSITAS CAHAYA SOROT</span>
                      <span className="font-mono text-[#5C1018]">
                        {((config.spotlightIntensity ?? 0.65) * 100).toFixed(0)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.1}
                      max={1.0}
                      step={0.05}
                      value={config.spotlightIntensity ?? 0.65}
                      onChange={(e) =>
                        onUpdateConfig({
                          spotlightIntensity: parseFloat(e.target.value),
                          generateTrigger: Date.now(),
                        })
                      }
                      className="w-full accent-[#5C1018] h-2 bg-[#D5C2AA] rounded cursor-pointer"
                    />
                  </div>

                  {/* Radius Sorot */}
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center justify-between text-[11px] font-bold text-[#3E2916]">
                      <span>JANGKAUAN / RADIUS SOROT</span>
                      <span className="font-mono text-[#5C1018]">
                        {(config.spotlightRadius ?? 70)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={30}
                      max={130}
                      step={5}
                      value={config.spotlightRadius ?? 70}
                      onChange={(e) =>
                        onUpdateConfig({
                          spotlightRadius: parseInt(e.target.value),
                          generateTrigger: Date.now(),
                        })
                      }
                      className="w-full accent-[#5C1018] h-2 bg-[#D5C2AA] rounded cursor-pointer"
                    />
                  </div>

                  {/* Pilihan Warna Sorot */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] font-bold uppercase text-[#3E2916]">WARNA PENDARAN</span>
                    <div className="flex items-center gap-1.5">
                      {[
                        { name: 'Warm Sand', hex: '#DFCEB5' },
                        { name: 'Putih Murni', hex: '#FFFFFF' },
                        { name: 'Cyan Tech', hex: '#38BDF8' },
                        { name: 'Sunset Amber', hex: '#F59E0B' },
                        { name: 'Burgundy', hex: '#5C1018' },
                      ].map((sc) => (
                        <button
                          key={sc.hex}
                          type="button"
                          title={sc.name}
                          onClick={() =>
                            onUpdateConfig({ spotlightColor: sc.hex, generateTrigger: Date.now() })
                          }
                          className={`w-5 h-5 rounded-full border ${
                            (config.spotlightColor || config.secondaryColor || '#DFCEB5') === sc.hex
                              ? 'ring-2 ring-[#5C1018] scale-110 border-white'
                              : 'border-black/20'
                          }`}
                          style={{ backgroundColor: sc.hex }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 4. Color Tone Grading */}
            <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-[#181F2B]">TONE WARNA (COLOR GRADING)</span>
                <span className="text-[10px] font-mono text-[#5C1018] font-bold uppercase">
                  {config.colorTone || 'none'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {COLOR_TONE_OPTIONS.map((tone) => {
                  const isSelected = (config.colorTone || 'none') === tone.id;
                  return (
                    <button
                      key={tone.id}
                      type="button"
                      onClick={() => onUpdateConfig({ colorTone: tone.id, generateTrigger: Date.now() })}
                      className={`p-2 rounded-lg border text-left text-xs font-bold transition-all ${
                        isSelected
                          ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-1 ring-[#DFCEB5] shadow-sm'
                          : 'bg-white border-[#DFCEB5] text-[#181F2B] hover:bg-[#F8F5EE]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 truncate">
                          <span
                            className="w-2.5 h-2.5 rounded-full border border-black/10 shrink-0"
                            style={{ backgroundColor: tone.preview }}
                          />
                          <span className="truncate">{tone.name}</span>
                        </div>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#DFCEB5] shrink-0" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* OPTION SET: TEXT STYLE (ONLY IN MULTI LOGO & VIDEO TITLE)*/}
        {/* ======================================================== */}
        {activeSection === 'text' && (
          <div className="flex flex-col gap-4">
            {currentMode === 'video_title' ? (
              <>
                <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <label className="text-xs font-bold uppercase text-[#3E2916]">JUDUL ATAS (TOP TITLE)</label>
                  <input
                    type="text"
                    value={config.titleTop || ''}
                    onChange={(e) => onUpdateConfig({ titleTop: e.target.value, generateTrigger: Date.now() })}
                    placeholder="SIMULASI KONSTRUKSI"
                    className="w-full px-2.5 py-1.5 rounded bg-white border border-[#98AFC3] text-xs text-[#181F2B]"
                  />
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div>
                      <label className="text-[10px] font-bold uppercase text-[#5B4734]">UKURAN</label>
                      <input
                        type="number"
                        value={config.titleTopSize || 22}
                        onChange={(e) => onUpdateConfig({ titleTopSize: parseInt(e.target.value) || 22, generateTrigger: Date.now() })}
                        className="w-full px-2 py-1 rounded bg-white border border-[#98AFC3] text-xs text-[#181F2B]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase text-[#5B4734]">WARNA</label>
                      <input
                        type="color"
                        value={config.titleTopColor || '#DFCEB5'}
                        onChange={(e) => onUpdateConfig({ titleTopColor: e.target.value, generateTrigger: Date.now() })}
                        className="w-full h-7 rounded cursor-pointer bg-white border border-[#98AFC3]"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <label className="text-xs font-bold uppercase text-[#3E2916]">JUDUL UTAMA (MAIN TITLE)</label>
                  <textarea
                    rows={2}
                    value={config.titleMain || ''}
                    onChange={(e) => onUpdateConfig({ titleMain: e.target.value, generateTrigger: Date.now() })}
                    placeholder="PEMBANGUNAN HUNIAN VERTIKAL NEGARA"
                    className="w-full px-2.5 py-1.5 rounded bg-white border border-[#98AFC3] text-xs text-[#181F2B]"
                  />
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div>
                      <label className="text-[10px] font-bold uppercase text-[#5B4734]">UKURAN</label>
                      <input
                        type="number"
                        value={config.titleMainSize || 48}
                        onChange={(e) => onUpdateConfig({ titleMainSize: parseInt(e.target.value) || 48, generateTrigger: Date.now() })}
                        className="w-full px-2 py-1 rounded bg-white border border-[#98AFC3] text-xs text-[#181F2B]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase text-[#5B4734]">WARNA</label>
                      <input
                        type="color"
                        value={config.titleMainColor || '#FFFFFF'}
                        onChange={(e) => onUpdateConfig({ titleMainColor: e.target.value, generateTrigger: Date.now() })}
                        className="w-full h-7 rounded cursor-pointer bg-white border border-[#98AFC3]"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <label className="text-xs font-bold uppercase text-[#3E2916]">JUDUL BAWAH (BOTTOM TITLE)</label>
                  <input
                    type="text"
                    value={config.titleBottom || ''}
                    onChange={(e) => onUpdateConfig({ titleBottom: e.target.value, generateTrigger: Date.now() })}
                    placeholder="DI IBU KOTA NUSANTARA"
                    className="w-full px-2.5 py-1.5 rounded bg-white border border-[#98AFC3] text-xs text-[#181F2B]"
                  />
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div>
                      <label className="text-[10px] font-bold uppercase text-[#5B4734]">UKURAN</label>
                      <input
                        type="number"
                        value={config.titleBottomSize || 18}
                        onChange={(e) => onUpdateConfig({ titleBottomSize: parseInt(e.target.value) || 18, generateTrigger: Date.now() })}
                        className="w-full px-2 py-1 rounded bg-white border border-[#98AFC3] text-xs text-[#181F2B]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase text-[#5B4734]">WARNA</label>
                      <input
                        type="color"
                        value={config.titleBottomColor || '#98AFC3'}
                        onChange={(e) => onUpdateConfig({ titleBottomColor: e.target.value, generateTrigger: Date.now() })}
                        className="w-full h-7 rounded cursor-pointer bg-white border border-[#98AFC3]"
                      />
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <label className="text-xs font-bold uppercase text-[#3E2916]">JUDUL UTAMA KONSORSIUM BUMPER</label>
                  <input
                    type="text"
                    value={config.title}
                    onChange={(e) => onUpdateConfig({ title: e.target.value, generateTrigger: Date.now() })}
                    placeholder="NUSA JAYA WISWAKHARMAN, KSO"
                    className="w-full px-2.5 py-1.5 rounded bg-white border border-[#98AFC3] text-xs text-[#181F2B]"
                  />
                </div>

                <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <label className="text-xs font-bold uppercase text-[#3E2916]">PILIHAN FONT TYPOGRAPHY</label>
                  <div className="grid grid-cols-1 gap-1.5">
                    {FONT_OPTIONS.map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => onUpdateConfig({ fontFamily: f.id, generateTrigger: Date.now() })}
                        className={`p-2 rounded-lg border text-left text-xs font-bold transition-all ${
                          config.fontFamily === f.id
                            ? 'bg-[#5C1018] border-[#DFCEB5] text-[#F8F5EE] ring-1 ring-[#DFCEB5]'
                            : 'bg-white border-[#DFCEB5] text-[#181F2B] hover:bg-[#F8F5EE]'
                        }`}
                        style={{ fontFamily: f.id }}
                      >
                        {f.name}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#EDE2D3] border border-[#DFCEB5]">
                  <span className="text-xs font-bold uppercase text-[#181F2B]">PRESET WARNA TEKS</span>
                  <div className="grid grid-cols-3 gap-2">
                    {FONT_COLOR_PRESETS.map((color) => (
                      <button
                        key={color.name}
                        type="button"
                        onClick={() => onUpdateConfig({ primaryColor: color.hex, titleColor: color.hex, generateTrigger: Date.now() })}
                        className={`p-1.5 rounded border flex items-center gap-1.5 text-[10px] font-bold ${
                          config.primaryColor === color.hex ? 'border-[#5C1018] bg-white ring-2 ring-[#5C1018]' : 'border-[#DFCEB5] bg-[#F8F5EE]'
                        }`}
                      >
                        <span className="w-3 h-3 rounded-full border border-black/20" style={{ backgroundColor: color.hex }} />
                        <span className="truncate">{color.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
