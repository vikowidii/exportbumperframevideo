import React from 'react';
import { Download, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { BumperConfig } from '../types/bumper';

interface HeaderProps {
  config: BumperConfig;
  onUpdateConfig: (partial: Partial<BumperConfig>) => void;
  onOpenExport: () => void;
  onOpenAIModal: () => void;
  onReset: () => void;
  lang: 'id' | 'en';
  onToggleLang: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  config,
  onUpdateConfig,
  onOpenExport,
  onOpenAIModal,
  onReset,
  lang,
  onToggleLang,
}) => {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-4 px-4 sm:px-6 py-2.5 bg-[#5C1018] border-b border-[#DFCEB5]/30 shadow-md">
      {/* Left: Circular Brand LOGO Badge with user's official construction digital SVG logo */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="relative flex items-center justify-center w-12 h-12 rounded-full overflow-hidden border-2 border-[#DFCEB5] shadow-lg shadow-black/40 bg-[#141C28]">
          <img
            src="/assets/logo-construction-digital.svg"
            alt="Construction Digital Logo"
            className="w-full h-full object-contain"
          />
        </div>
      </div>

      {/* Right: Sound, Reset, Language & Prominent EXPORT PNG/MP4 Button */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <button
          onClick={() => onUpdateConfig({ soundEnabled: !config.soundEnabled })}
          className="p-2 rounded-lg border border-[#DFCEB5]/25 bg-[#460C12] text-[#DFCEB5] hover:text-white hover:bg-[#3D0A10] transition-colors"
          title={config.soundEnabled ? 'Matikan Suara' : 'Aktifkan Suara'}
        >
          {config.soundEnabled ? (
            <Volume2 className="w-4 h-4 text-[#DFCEB5]" />
          ) : (
            <VolumeX className="w-4 h-4 text-[#98AFC3]" />
          )}
        </button>

        <button
          onClick={onReset}
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-[#DFCEB5]/25 bg-[#460C12] text-[#DFCEB5] hover:text-white text-xs transition-colors"
          title={lang === 'id' ? 'Kembalikan ke awal' : 'Reset to default'}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden xl:inline">Reset</span>
        </button>

        <button
          onClick={onToggleLang}
          className="px-2 py-1.5 rounded-lg border border-[#DFCEB5]/25 bg-[#460C12] text-[#DFCEB5] hover:text-white text-xs font-mono transition-colors"
        >
          {lang === 'id' ? 'ID 🇮🇩' : 'EN 🇬🇧'}
        </button>

        {/* Prominent EXPORT PNG/MP4 Button matching wireframe with refined palette */}
        <button
          onClick={onOpenExport}
          className="flex items-center gap-2 px-4 sm:px-5 py-2 text-xs sm:text-sm font-black tracking-wide text-[#5C1018] bg-[#DFCEB5] hover:bg-[#F8F5EE] border border-white/60 rounded-xl shadow-lg shadow-black/40 transition-all hover:scale-[1.02] active:scale-[0.98] uppercase font-mono"
        >
          <Download className="w-4 h-4 text-[#5C1018] stroke-[2.5]" />
          <span>EXPORT PNG/MP4</span>
        </button>
      </div>
    </header>
  );
};
