import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Repeat,
  Camera,
  Maximize2,
  Volume2,
  VolumeX,
  Smartphone,
  Tv,
  Square,
  Sparkles,
} from 'lucide-react';
import { BumperConfig, AspectRatio } from '../types/bumper';
import { renderBumperFrame } from '../utils/canvasRenderer';
import { audioEngine } from '../utils/audioEngine';
import { downloadPosterFrame } from '../utils/videoExporter';

interface CenterPlayerProps {
  config: BumperConfig;
  onUpdateConfig: (partial: Partial<BumperConfig>) => void;
  lang: 'id' | 'en';
}

export const CenterPlayer: React.FC<CenterPlayerProps> = ({
  config,
  onUpdateConfig,
  lang,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isScrubbing, setIsScrubbing] = useState<boolean>(false);

  // Smooth animation tracking
  const timeRef = useRef<number>(0);
  const lastTimestampRef = useRef<number>(0);
  const animFrameRef = useRef<number | null>(null);

  // Aspect ratio display dimensions
  const getCanvasDimensions = useCallback((ratio: AspectRatio) => {
    switch (ratio) {
      case '9:16':
        return { width: 720, height: 1280, aspectClass: 'aspect-[9/16] max-h-[520px]' };
      case '1:1':
        return { width: 1080, height: 1080, aspectClass: 'aspect-square max-h-[480px]' };
      case '16:9':
      default:
        return { width: 1920, height: 1080, aspectClass: 'aspect-video max-w-full' };
    }
  }, []);

  const dims = getCanvasDimensions(config.aspectRatio);

  // Render current frame to canvas
  const drawFrame = useCallback(
    (t: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      renderBumperFrame(ctx, canvas.width, canvas.height, config, t);
    },
    [config]
  );

  // Trigger sound effect on playback start
  const playSoundAt = useCallback(
    (timeOffset: number) => {
      if (config.soundEnabled && config.audioTheme !== 'none') {
        audioEngine.play(config.audioTheme, config.soundVolume, timeOffset, config.customAudioUrl);
      }
    },
    [config.soundEnabled, config.audioTheme, config.soundVolume, config.customAudioUrl]
  );

  // Animation Loop
  useEffect(() => {
    const loop = (timestamp: number) => {
      if (!lastTimestampRef.current) {
        lastTimestampRef.current = timestamp;
      }
      const delta = (timestamp - lastTimestampRef.current) / 1000;
      lastTimestampRef.current = timestamp;

      if (isPlaying && !isScrubbing) {
        let nextTime = timeRef.current + delta;
        const dur = Math.max(1, config.duration);

        if (nextTime >= dur) {
          if (isLooping) {
            nextTime = 0;
            timeRef.current = 0;
            playSoundAt(0);
          } else {
            nextTime = dur;
            setIsPlaying(false);
            audioEngine.stop();
          }
        }

        timeRef.current = nextTime;
        setCurrentTime(nextTime);
        drawFrame(nextTime);
      } else {
        drawFrame(timeRef.current);
      }

      animFrameRef.current = requestAnimationFrame(loop);
    };

    lastTimestampRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
      audioEngine.stop();
    };
  }, [isPlaying, isScrubbing, isLooping, config.duration, drawFrame, playSoundAt]);

  // Replay when Triggered
  useEffect(() => {
    if (config.generateTrigger) {
      timeRef.current = 0;
      setCurrentTime(0);
      drawFrame(0);
      playSoundAt(0);
      setIsPlaying(true);
    }
  }, [config.generateTrigger, drawFrame, playSoundAt]);

  // Handle Play / Pause Toggle
  const togglePlay = () => {
    if (!isPlaying) {
      if (timeRef.current >= config.duration) {
        timeRef.current = 0;
        setCurrentTime(0);
      }
      playSoundAt(timeRef.current);
      setIsPlaying(true);
    } else {
      setIsPlaying(false);
      audioEngine.stop();
    }
  };

  // Handle Restart
  const handleRestart = () => {
    timeRef.current = 0;
    setCurrentTime(0);
    drawFrame(0);
    playSoundAt(0);
    setIsPlaying(true);
  };

  // Handle Slider Scrubbing
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    timeRef.current = val;
    setCurrentTime(val);
    drawFrame(val);
  };

  // Handle Snapshot PNG Download
  const handleCaptureSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const safeTitle = config.title.toLowerCase().replace(/[^a-z0-9]/g, '_');
    downloadPosterFrame(canvas, `poster_${safeTitle}_${config.theme}.png`);
  };

  // Fullscreen canvas
  const handleFullscreen = () => {
    if (containerRef.current) {
      if (!document.fullscreenElement) {
        containerRef.current.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    }
  };

  return (
    <div className="flex flex-col gap-3.5 w-full">
      {/* ======================================================== */}
      {/* 1. TOP BOX: MAIN VIDEO SCREEN VIEWPORT (Wireframe top box) */}
      {/* ======================================================== */}
      <div className="flex flex-col bg-[#181F2B] border-2 border-[#98AFC3]/30 rounded-2xl p-2 sm:p-3 shadow-2xl relative overflow-hidden text-[#F8F5EE]">
        {/* Subtle top meta header inside player */}
        <div className="flex items-center justify-between pb-2 px-1 text-xs text-[#DFCEB5]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#DFCEB5] animate-ping inline-block" />
            <span className="font-mono font-bold uppercase text-[11px] text-[#F8F5EE]">
              {config.studioMode === 'video_title'
                ? 'Preview: Video Title Screen'
                : config.studioMode === 'frame_video'
                ? `Preview: Frame Video Logo (Gaya ${config.frameStyle?.toUpperCase() || 'KLASIK'})`
                : `Preview: Bumper Logo (${config.logoCountMode === 'single' ? 'Single Logo' : 'Multi-Logo'})`}
            </span>
          </div>

          <div className="flex items-center gap-2 font-mono text-[11px] text-[#98AFC3]">
            <span>{dims.width}×{dims.height}</span>
            <span>·</span>
            <span>{config.fps} FPS</span>
            <button
              onClick={handleFullscreen}
              className="p-1 hover:text-white transition-colors"
              title="Fullscreen"
            >
              <Maximize2 className="w-3.5 h-3.5 text-[#DFCEB5]" />
            </button>
          </div>
        </div>

        {/* The Canvas Stage */}
        <div
          ref={containerRef}
          className="relative flex items-center justify-center bg-black/95 rounded-xl overflow-hidden shadow-inner min-h-[300px] sm:min-h-[380px] lg:min-h-[440px] border border-[#98AFC3]/20"
        >
          <canvas
            ref={canvasRef}
            width={dims.width}
            height={dims.height}
            className={`rounded-lg object-contain ${dims.aspectClass}`}
          />

          {/* Floating Play Overlay Button When Paused */}
          {!isPlaying && (
            <button
              onClick={togglePlay}
              className="absolute inset-0 m-auto w-14 h-14 flex items-center justify-center rounded-full bg-[#5C1018]/80 hover:bg-[#5C1018] text-[#DFCEB5] border-2 border-[#DFCEB5] backdrop-blur-md shadow-2xl transition-all scale-100 hover:scale-105"
              aria-label="Play video preview"
            >
              <Play className="w-6 h-6 ml-0.5 fill-current" />
            </button>
          )}
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2. MIDDLE BOX: TIMELINE SCRUBBER (Wireframe middle strip) */}
      {/* ======================================================== */}
      <div className="flex items-center gap-3 px-4 py-2.5 bg-[#181F2B] border-2 border-[#98AFC3]/30 rounded-xl shadow-lg">
        <span className="text-[11px] font-mono font-bold text-[#DFCEB5] shrink-0">
          TIMELINE
        </span>

        {/* Range Scrubber Slider */}
        <div className="relative flex-1 flex items-center group">
          <input
            type="range"
            min={0}
            max={config.duration}
            step={0.01}
            value={currentTime}
            onChange={handleSliderChange}
            onMouseDown={() => setIsScrubbing(true)}
            onMouseUp={() => setIsScrubbing(false)}
            onTouchStart={() => setIsScrubbing(true)}
            onTouchEnd={() => setIsScrubbing(false)}
            className="w-full h-2 bg-[#121620] rounded-lg appearance-none cursor-pointer accent-[#DFCEB5] focus:outline-none"
          />
        </div>

        {/* Timecode */}
        <div className="font-mono text-xs font-bold text-[#DFCEB5] tabular-nums shrink-0">
          <span className="text-[#F8F5EE]">{currentTime.toFixed(2)}s</span>
          <span className="text-[#98AFC3] mx-1">/</span>
          <span>{config.duration.toFixed(2)}s</span>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 3. BOTTOM BOX: VIDEO CONTROLS (Wireframe bottom strip)   */}
      {/* ======================================================== */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-[#181F2B] border-2 border-[#98AFC3]/30 rounded-xl shadow-lg">
        {/* Playback Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={togglePlay}
            className="flex items-center justify-center w-9 h-9 rounded-lg bg-[#DFCEB5] hover:bg-[#F8F5EE] text-[#5C1018] font-black shadow-md shadow-black/40 transition-colors"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 ml-0.5 fill-current" />
            )}
          </button>

          <button
            onClick={handleRestart}
            className="flex items-center justify-center w-9 h-9 rounded-lg bg-[#141A24] hover:bg-[#202938] text-[#DFCEB5] border border-[#98AFC3]/30 transition-colors"
            title="Putar dari awal (Restart)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsLooping(!isLooping)}
            className={`flex items-center justify-center w-9 h-9 rounded-lg border transition-colors ${
              isLooping
                ? 'bg-[#5C1018] text-[#DFCEB5] font-bold border-[#DFCEB5] shadow-sm'
                : 'bg-[#141A24] text-[#98AFC3] border-[#98AFC3]/30 hover:text-white'
            }`}
            title={isLooping ? 'Loop aktif' : 'Loop mati'}
          >
            <Repeat className="w-4 h-4" />
          </button>

          <button
            onClick={() => onUpdateConfig({ soundEnabled: !config.soundEnabled })}
            className={`flex items-center justify-center w-9 h-9 rounded-lg border transition-colors ${
              config.soundEnabled
                ? 'bg-[#141A24] text-[#DFCEB5] border-[#DFCEB5]/50'
                : 'bg-[#141A24] text-[#98AFC3]/50 border-[#98AFC3]/20'
            }`}
            title={config.soundEnabled ? 'Suara aktif' : 'Suara dimatikan'}
          >
            {config.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>

        {/* Aspect Ratio Toggles */}
        <div className="flex items-center gap-1 p-1 bg-[#141A24] rounded-lg border border-[#98AFC3]/30">
          <button
            onClick={() => onUpdateConfig({ aspectRatio: '16:9' })}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-bold transition-all ${
              config.aspectRatio === '16:9'
                ? 'bg-[#DFCEB5] text-[#5C1018] shadow-sm'
                : 'text-[#98AFC3] hover:text-[#F8F5EE]'
            }`}
          >
            <Tv className="w-3 h-3" />
            <span>16:9</span>
          </button>

          <button
            onClick={() => onUpdateConfig({ aspectRatio: '9:16' })}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-bold transition-all ${
              config.aspectRatio === '9:16'
                ? 'bg-[#DFCEB5] text-[#5C1018] shadow-sm'
                : 'text-[#98AFC3] hover:text-[#F8F5EE]'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            <span>9:16</span>
          </button>

          <button
            onClick={() => onUpdateConfig({ aspectRatio: '1:1' })}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-bold transition-all ${
              config.aspectRatio === '1:1'
                ? 'bg-[#DFCEB5] text-[#5C1018] shadow-sm'
                : 'text-[#98AFC3] hover:text-[#F8F5EE]'
            }`}
          >
            <Square className="w-3 h-3" />
            <span>1:1</span>
          </button>
        </div>

        {/* Snapshot PNG Download Button */}
        <button
          onClick={handleCaptureSnapshot}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#5C1018] hover:bg-[#460C12] text-[#DFCEB5] rounded-lg border border-[#DFCEB5]/50 text-xs font-bold transition-colors shadow-sm"
          title="Unduh Poster Snapshot PNG"
        >
          <Camera className="w-3.5 h-3.5 text-[#DFCEB5]" />
          <span>UNDUH PNG</span>
        </button>
      </div>
    </div>
  );
};
