@echo off
title BumperCraft Studio - Server Lokal
echo ========================================================
echo   MENJALANKAN BUMPERCRAFT STUDIO DI KOMPUTER LOKAL
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js belum terinstall di komputer Anda!
    echo Silakan download dan install Node.js dari: https://nodejs.org
    echo Setelah install, buka kembali file ini.
    pause
    exit /b
)

if not exist "node_modules" (
    echo [INFO] Mengunduh dependensi (pertama kali saja)...
    call npm install
)

if not exist ".env" (
    if exist ".env.example" (
        copy .env.example .env >nul
        echo [INFO] File .env otomatis dibuat dari .env.example
    )
)

echo.
echo [OK] Menjalankan server lokal di port 3000...
echo Buka browser di: http://localhost:3000
echo.
start http://localhost:3000
call npm run dev
pause
