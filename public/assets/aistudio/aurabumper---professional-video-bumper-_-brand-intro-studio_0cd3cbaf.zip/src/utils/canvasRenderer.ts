import { BumperConfig } from '../types/bumper';

// Particle memory cache for deterministic particle animation
interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  seed: number;
}

const particlePool: Record<string, Particle[]> = {};

function getParticles(theme: string, count: number): Particle[] {
  const key = `${theme}_${count}`;
  if (!particlePool[key] || particlePool[key].length !== count) {
    const list: Particle[] = [];
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const radius = 0.1 + Math.random() * 0.9;
      list.push({
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        z: Math.random(),
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: 1 + Math.random() * 3.5,
        color: '#FFFFFF',
        seed: Math.random(),
      });
    }
    particlePool[key] = list;
  }
  return particlePool[key];
}

// Logo image cache
const imageCache = new Map<string, HTMLImageElement>();

export function getCachedImage(url?: string): HTMLImageElement | null {
  if (!url) return null;
  if (imageCache.has(url)) {
    const img = imageCache.get(url)!;
    return img.complete ? img : null;
  }
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.src = url;
  imageCache.set(url, img);
  return null;
}

// Pre-load the official sliced HD assets immediately
if (typeof window !== 'undefined') {
  getCachedImage('/assets/aistudio/kso_nke_hd.png');
  getCachedImage('/assets/aistudio/kso_jaya_hd.png');
  getCachedImage('/assets/aistudio/kso_wiswa_hd.png');
  getCachedImage('/assets/aistudio/kso_full_hd.png');
  getCachedImage('/assets/aistudio/LOGO_KSO_HD_vektor_edcea276.png');
  getCachedImage('/assets/aistudio/LOGO_WM_NKE_R3_c1d75e16.png');
  getCachedImage('/assets/aistudio/image_737631e5.png');
}

// Smooth easing helpers
function easeOutCubic(x: number): number {
  const t = Math.max(0, Math.min(1, x));
  return 1 - Math.pow(1 - t, 3);
}

function easeOutExpo(x: number): number {
  const t = Math.max(0, Math.min(1, x));
  return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
}

function easeOutBack(x: number): number {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  const t = Math.max(0, Math.min(1, x)) - 1;
  return 1 + c3 * Math.pow(t, 3) + c1 * Math.pow(t, 2);
}

function clamp(val: number, min: number = 0, max: number = 1): number {
  return Math.max(min, Math.min(max, val));
}

/**
 * Main Bumper Canvas Entry Point
 * Dispatches to:
 * 1. Bumper Logo (Single or Multiple Logo)
 * 2. Video Title Screen (Inspired by IKN Reference)
 * 3. Frame Video Logo Overlay (Inspired by Diagonal Watermark Reference)
 */
export function renderBumperFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  config: BumperConfig,
  time: number
) {
  const speed = config.motionSpeed || 1;

  ctx.save();

  if (config.studioMode === 'frame_video') {
    // Mode 3: Frame Video Logo Overlay
    renderFrameVideoMode(ctx, width, height, config, time);
  } else if (config.studioMode === 'video_title') {
    // Mode 2: Video Title Screen
    renderMasterBackground(ctx, width, height, config, time);
    renderVideoTitleMode(ctx, width, height, config, time, speed);
  } else {
    // Mode 1: Bumper Logo (Single or Multiple)
    renderMasterBackground(ctx, width, height, config, time);
    renderMasterPresentation(ctx, width, height, config, time, speed);
  }

  // Color Tone Grading (Applied across all modes)
  if (config.colorTone && config.colorTone !== 'none') {
    applyColorTone(ctx, width, height, config.colorTone);
  }

  // Post FX: Film Grain
  if (config.filmGrain && config.studioMode !== 'frame_video') {
    applyFilmGrain(ctx, width, height, time);
  }

  // Post FX: Vignette
  if (config.vignette && config.studioMode !== 'frame_video') {
    applyVignette(ctx, width, height);
  }

  // Post FX: Letterbox Cinematic Bars
  if (config.letterbox && config.aspectRatio === '16:9' && config.studioMode !== 'frame_video') {
    const barHeight = height * 0.1;
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, barHeight);
    ctx.fillRect(0, height - barHeight, width, barHeight);
  }

  ctx.restore();
}

/**
 * Master Background Renderer
 * Handles solid colors, multi-stop gradients, fully adjustable volumetric spotlight circles,
 * CAD grid, futuristic effects (laser scanner, cyber hex, hologram, light streaks), and photo backdrops.
 */
function renderMasterBackground(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const scale = Math.min(w, h) / 1000;

  const bgPrimary = cfg.backgroundColor || '#08101E';
  const bgSecondary = cfg.backgroundSecondaryColor || '#0E1D36';
  const accent = cfg.accentColor || '#38BDF8';
  const secColor = cfg.secondaryColor || '#DF9B35';

  // 1. BASE BACKGROUND LAYER
  if (cfg.backgroundStyle === 'solid') {
    ctx.fillStyle = bgPrimary;
    ctx.fillRect(0, 0, w, h);
  } else if (cfg.backgroundStyle === 'custom_image' && cfg.customBackgroundUrl) {
    const bgImg = getCachedImage(cfg.customBackgroundUrl);
    if (bgImg) {
      const imgAspect = bgImg.naturalWidth / bgImg.naturalHeight;
      const canvasAspect = w / h;
      let dw = w, dh = h, dx = 0, dy = 0;
      if (imgAspect > canvasAspect) {
        dw = h * imgAspect;
        dx = (w - dw) / 2;
      } else {
        dh = w / imgAspect;
        dy = (h - dh) / 2;
      }
      ctx.drawImage(bgImg, dx, dy, dw, dh);
      ctx.fillStyle = 'rgba(4, 8, 16, 0.72)';
      ctx.fillRect(0, 0, w, h);
    } else {
      ctx.fillStyle = bgPrimary;
      ctx.fillRect(0, 0, w, h);
    }
  } else {
    const bgGrad = ctx.createLinearGradient(0, 0, w * 0.8, h);
    bgGrad.addColorStop(0, bgPrimary);
    bgGrad.addColorStop(0.5, bgSecondary);
    bgGrad.addColorStop(1, bgPrimary);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);
  }

  // 2. BULATAN CAHAYA (Spotlight Circle) - ADJUSTABLE & ACTIVE IN RADIAL_GLOW
  const isRadialGlowStyle = cfg.backgroundStyle === 'radial_glow';
  const isSpotlightEnabled = cfg.spotlightEnabled !== false || isRadialGlowStyle;
  const spotIntensity = cfg.spotlightIntensity !== undefined
    ? cfg.spotlightIntensity
    : (isRadialGlowStyle ? 0.9 : 0.65);

  if (isSpotlightEnabled && spotIntensity > 0 && cfg.backgroundStyle !== 'solid') {
    const pulseSpeed = cfg.spotlightPulseSpeed !== undefined ? cfg.spotlightPulseSpeed : 1.0;
    const pulse = 1.0 + Math.sin(t * 1.8 * pulseSpeed) * 0.08 * (pulseSpeed > 0 ? 1 : 0);

    const radiusMultiplier = (cfg.spotlightRadius !== undefined ? cfg.spotlightRadius : (isRadialGlowStyle ? 90 : 70)) / 100;
    const spotRadius = Math.min(w, h) * 0.58 * radiusMultiplier * pulse;

    const yOffsetPercent = (cfg.spotlightYOffset || 0) / 100;
    const spotY = cy + (h * 0.3) * yOffsetPercent;

    const baseColor = cfg.spotlightColor || secColor;
    const softness = cfg.spotlightSoftness !== undefined ? cfg.spotlightSoftness : 0.75;
    const midStop = Math.max(0.1, Math.min(0.9, softness * 0.65));

    const spotGrad = ctx.createRadialGradient(cx, spotY, 0, cx, spotY, spotRadius);
    spotGrad.addColorStop(0, hexToRgba(baseColor, spotIntensity * (isRadialGlowStyle ? 0.65 : 0.42)));
    spotGrad.addColorStop(midStop, hexToRgba(accent, spotIntensity * (isRadialGlowStyle ? 0.28 : 0.16)));
    spotGrad.addColorStop(1, 'rgba(0,0,0,0)');

    ctx.save();
    ctx.fillStyle = spotGrad;
    ctx.fillRect(0, 0, w, h);

    if (softness < 0.35 || isRadialGlowStyle) {
      ctx.strokeStyle = hexToRgba(baseColor, spotIntensity * 0.3);
      ctx.lineWidth = 1.5 * scale;
      ctx.beginPath();
      ctx.arc(cx, spotY, spotRadius * 0.7, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  // 3. EFEK FUTURISTIK & MODERN
  // A. Digital Laser Scanline
  const isLaserActive = cfg.laserScanline || cfg.futuristicEffect === 'laser_scan';
  if (isLaserActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    const laserY = (Math.sin(t * 1.6) * 0.5 + 0.5) * h;
    const lGrad = ctx.createLinearGradient(0, laserY - 8 * scale, 0, laserY + 8 * scale);
    lGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
    lGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.65)');
    lGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = lGrad;
    ctx.fillRect(0, laserY - 8 * scale, w, 16 * scale);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 1.5 * scale;
    ctx.beginPath();
    ctx.moveTo(0, laserY);
    ctx.lineTo(w, laserY);
    ctx.stroke();
    ctx.restore();
  }

  // B. Cyber Hexagonal Mesh (Always active if cyber_hex style or toggle selected)
  const isHexActive = cfg.cyberHexMesh || cfg.futuristicEffect === 'cyber_hex' || cfg.backgroundStyle === 'cyber_hex';
  if (isHexActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    ctx.strokeStyle = hexToRgba(accent, cfg.backgroundStyle === 'cyber_hex' ? 0.18 : 0.08);
    ctx.lineWidth = 1 * scale;
    const hexR = 36 * scale;
    const hDist = hexR * Math.sqrt(3);
    const vDist = hexR * 1.5;

    for (let hy = -vDist; hy < h + vDist; hy += vDist) {
      const rowIdx = Math.floor(hy / vDist);
      const xOff = (rowIdx % 2 === 0) ? 0 : hDist / 2;
      for (let hx = -hDist + xOff; hx < w + hDist; hx += hDist) {
        ctx.beginPath();
        for (let a = 0; a < 6; a++) {
          const angle = (Math.PI / 3) * a + Math.PI / 6;
          const px = hx + hexR * Math.cos(angle);
          const py = hy + hexR * Math.sin(angle);
          if (a === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();

        // Subtle glowing dot at intersection in cyber_hex mode
        if (cfg.backgroundStyle === 'cyber_hex' && ((Math.floor(hx) + Math.floor(hy)) % 7 === 0)) {
          ctx.fillStyle = hexToRgba(accent, 0.35);
          ctx.beginPath();
          ctx.arc(hx, hy, 1.8 * scale, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    ctx.restore();
  }

  // C. Hologram Scanlines (Active if hologram_lines style or toggle)
  const isHoloActive = cfg.hologramLines || cfg.futuristicEffect === 'hologram_lines' || cfg.backgroundStyle === 'hologram_lines';
  if (isHoloActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    ctx.fillStyle = hexToRgba(accent, cfg.backgroundStyle === 'hologram_lines' ? 0.06 : 0.025);
    const scanStep = 4 * scale;
    for (let sy = 0; sy < h; sy += scanStep) {
      ctx.fillRect(0, sy, w, 1 * scale);
    }
    // Animated slow vertical sweep beam
    const holoSweepY = ((t * 0.15) % 1.0) * h;
    const holoGrad = ctx.createLinearGradient(0, holoSweepY - 30 * scale, 0, holoSweepY + 30 * scale);
    holoGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
    holoGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.18)');
    holoGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = holoGrad;
    ctx.fillRect(0, holoSweepY - 30 * scale, w, 60 * scale);
    ctx.restore();
  }

  // D. Speed Light Streaks
  const isStreaksActive = cfg.lightStreaks || cfg.futuristicEffect === 'light_streaks';
  if (isStreaksActive && cfg.backgroundStyle !== 'solid') {
    ctx.save();
    for (let i = 0; i < 8; i++) {
      const sProgress = ((t * (0.3 + i * 0.08) + i * 0.22) % 1.0);
      const sx = sProgress * (w * 1.6) - w * 0.3;
      const sy = h * (0.2 + (i * 0.09));
      const sLen = 140 * scale * (0.8 + (i % 3) * 0.4);

      const sGrad = ctx.createLinearGradient(sx - sLen, sy, sx, sy);
      sGrad.addColorStop(0, 'rgba(0,0,0,0)');
      sGrad.addColorStop(0.7, hexToRgba(accent, 0.25));
      sGrad.addColorStop(1, hexToRgba('#FFFFFF', 0.8));

      ctx.fillStyle = sGrad;
      ctx.fillRect(sx - sLen, sy - 1 * scale, sLen, 2 * scale);
    }
    ctx.restore();
  }

  // 4. PRECISION CAD TECHNICAL GRID (Active if technical_grid or showGrid)
  const isCadGridStyle = cfg.backgroundStyle === 'technical_grid';
  const showGrid = (cfg.showGrid || isCadGridStyle) && cfg.backgroundStyle !== 'solid';
  if (showGrid) {
    const gridOp = isCadGridStyle ? 0.09 : (cfg.gridOpacity !== undefined ? cfg.gridOpacity : 0.035);
    ctx.save();
    ctx.strokeStyle = `rgba(255, 255, 255, ${gridOp})`;
    ctx.lineWidth = 1 * scale;
    const step = 50 * scale;

    for (let x = 0; x < w; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // High-tech CAD crosshairs at intersections
    if (isCadGridStyle) {
      ctx.strokeStyle = hexToRgba(accent, 0.4);
      ctx.lineWidth = 1.2 * scale;
      const crossStep = step * 2;
      for (let cxp = crossStep; cxp < w; cxp += crossStep) {
        for (let cyp = crossStep; cyp < h; cyp += crossStep) {
          ctx.beginPath();
          ctx.moveTo(cxp - 5 * scale, cyp);
          ctx.lineTo(cxp + 5 * scale, cyp);
          ctx.moveTo(cxp, cyp - 5 * scale);
          ctx.lineTo(cxp, cyp + 5 * scale);
          ctx.stroke();
        }
      }

      // Technical blueprint coordinate tags in corners
      ctx.font = `700 ${9 * scale}px "JetBrains Mono", monospace`;
      ctx.fillStyle = hexToRgba(accent, 0.55);
      ctx.fillText('CAD REF // DATUM WGS84: 0°58\'12"S 116°50\'44"E', 30 * scale, 30 * scale);
      ctx.fillText('SCALE 1:1000 // ARCHITECTURAL SYSTEM', 30 * scale, h - 30 * scale);
      ctx.textAlign = 'right';
      ctx.fillText('NUSA JAYA WISWAKHARMAN [KSO]', w - 30 * scale, h - 30 * scale);
      ctx.textAlign = 'left';
    }

    ctx.strokeStyle = hexToRgba(secColor, 0.35);
    ctx.beginPath();
    ctx.moveTo(cx - 24 * scale, cy);
    ctx.lineTo(cx + 24 * scale, cy);
    ctx.moveTo(cx, cy - 24 * scale);
    ctx.lineTo(cx, cy + 24 * scale);
    ctx.stroke();
    ctx.restore();
  }

  // Floating Dust Particles
  const particleCount = cfg.particleCount !== undefined ? cfg.particleCount : 45;
  if (particleCount > 0 && cfg.backgroundStyle !== 'solid') {
    const pColor = cfg.particleColor || secColor;
    const particles = getParticles(cfg.theme || 'default', Math.min(particleCount, 250));
    particles.forEach((pt) => {
      const py = ((pt.y + 0.5 - t * 0.05 * (0.6 + pt.seed * 0.4)) % 1 + 1) % 1;
      const px = ((pt.x + 0.5 + Math.sin(t * 0.45 + pt.seed * 8) * 0.04) % 1 + 1) % 1;
      const alpha = (0.2 + Math.sin(t * 2.0 + pt.seed * 15) * 0.2) * (1 - Math.abs(py - 0.5) * 1.6);
      if (alpha > 0) {
        ctx.fillStyle = hexToRgba(pColor, alpha * 0.8);
        ctx.beginPath();
        ctx.arc(px * w, py * h, pt.size * scale * (0.6 + pt.seed * 0.5), 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }
}

/**
 * Single Logo Animated Assembly:
 * 1. Logo starts MUCH LARGER and HERO-CENTERED
 * 2. Piece-by-piece reveal according to shape:
 *    - Phase 1: Green Triangle pops in / scales with bounce
 *    - Phase 2: Blue Triangle locks in
 *    - Phase 3: Yellow/Amber Triangle locks in
 * 3. Emblem is complete, holds center with energetic pulsing halo & flare
 * 4. Smoothly glides to the left
 * 5. Logo text ("NUSA KONSTRUKSI ENJINIRING") emerges on the right with beam wipe
 */
/**
 * Single Logo Animated Assembly & Transitions:
 * Supports:
 * 1. Segitiga Bergantian (NKE Sliced Geometric)
 * 2. Smooth Zoom & Flare Sweep
 * 3. 3D Isometric Flip & Glow
 * 4. Elastic Snap & Pulse Ring
 * 5. Digital Matrix Scan Reveal
 */
function renderSingleLogoSlicedAssemble(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  tAdj: number,
  scale: number,
  secColor: string
) {
  const logoScale = (cfg.singleLogoScale || 1.25) * (cfg.singleLogo?.scale || 1.0);
  const baseH = 80 * scale * logoScale;
  const greenW = 1.33 * baseH;
  const rectW = 1.33 * baseH;
  const emblemW = greenW + rectW;
  const animType = cfg.singleLogoTransition || cfg.singleLogoAnimation || 'nke_triangles_assemble';

  const customLogoUrl = cfg.singleLogo?.url || cfg.customLogoUrl;
  const customImg = customLogoUrl ? getCachedImage(customLogoUrl) : null;
  const isCustomLogo = Boolean(customImg && !customLogoUrl?.includes('LOGO_WM_NKE') && !customLogoUrl?.includes('kso_nke'));

  // Center Ambient Halo
  const haloPulse = 1.0 + Math.sin(tAdj * 2.2) * 0.08;
  const haloGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, 90 * scale * logoScale * haloPulse);
  haloGrad.addColorStop(0, 'rgba(56, 189, 248, 0.40)');
  haloGrad.addColorStop(0.4, 'rgba(223, 155, 53, 0.15)');
  haloGrad.addColorStop(1, 'rgba(0,0,0,0)');

  // Title & Text presence
  const hasCustomTitle = Boolean((cfg.title || '').trim());
  const shouldSlide = true; // Always allow the cinematic left glide to present the brand text

  // Glide to the left (1.9s - 2.8s)
  const pSlide = clamp((tAdj - 1.9) / 0.85);
  const easeSlide = easeOutCubic(pSlide);
  const slideDistance = Math.min(w * 0.25, 230 * scale);
  const curX = shouldSlide ? -slideDistance * easeSlide : 0;

  // Text emerges on the right after gliding left (2.4s - 3.4s)
  const pText = clamp((tAdj - 2.4) / 0.85);
  const easeText = easeOutCubic(pText);
  const alphaText = clamp(pText * 1.4);

  ctx.save();
  ctx.translate(curX, 0);

  // Background Ambient Halo
  ctx.fillStyle = haloGrad;
  ctx.beginPath();
  ctx.arc(0, 0, 90 * scale * logoScale * haloPulse, 0, Math.PI * 2);
  ctx.fill();

  const startX = -emblemW / 2;
  const topY = -baseH / 2;
  const botY = baseH / 2;

  // ---------------------------------------------------------
  // ANIMATION BRANCHES
  // ---------------------------------------------------------
  if (animType === 'smooth_zoom_flare' || (isCustomLogo && animType !== 'nke_triangles_assemble')) {
    // 2. Smooth Zoom & Flare
    const pZoom = clamp(tAdj / 0.85);
    const easeZoom = easeOutCubic(pZoom);
    const sLogo = 0.80 + 0.20 * easeZoom;
    const aLogo = clamp(pZoom * 1.6);

    ctx.save();
    ctx.scale(sLogo, sLogo);
    ctx.globalAlpha = aLogo;

    if (customImg) {
      const a = customImg.naturalWidth / customImg.naturalHeight;
      const dw = baseH * a;
      ctx.drawImage(customImg, -dw / 2, -baseH / 2, dw, baseH);
    } else {
      drawNkeEmblemDirect(ctx, startX, topY, botY, greenW, rectW, scale);
    }

    // Flare Sweep
    if (tAdj > 0.8 && tAdj < 1.9) {
      const pF = clamp((tAdj - 0.8) / 0.9);
      const fX = (pF * 2 - 1) * (emblemW * 1.2);
      ctx.save();
      ctx.translate(fX, 0);
      const fGrad = ctx.createLinearGradient(-emblemW * 0.4, 0, emblemW * 0.4, 0);
      fGrad.addColorStop(0, 'rgba(255,255,255,0)');
      fGrad.addColorStop(0.5, `rgba(255,255,255,${Math.sin(pF * Math.PI) * 0.9})`);
      fGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fGrad;
      ctx.fillRect(-emblemW * 0.4, -2 * scale, emblemW * 0.8, 4 * scale);
      ctx.restore();
    }
    ctx.restore();
  } else if (animType === 'flip_3d_reveal') {
    // 3. 3D Isometric Flip & Glow
    const pFlip = clamp(tAdj / 0.95);
    const easeFlip = easeOutCubic(pFlip);
    const flipAngle = (1 - easeFlip) * Math.PI * 0.5;
    const sFlip = 0.75 + 0.25 * easeFlip;

    ctx.save();
    ctx.scale(Math.cos(flipAngle) * sFlip, sFlip);
    ctx.globalAlpha = clamp(pFlip * 1.8);

    if (customImg) {
      const a = customImg.naturalWidth / customImg.naturalHeight;
      const dw = baseH * a;
      ctx.drawImage(customImg, -dw / 2, -baseH / 2, dw, baseH);
    } else {
      drawNkeEmblemDirect(ctx, startX, topY, botY, greenW, rectW, scale);
    }
    ctx.restore();
  } else if (animType === 'elastic_snap_pulse') {
    // 4. Elastic Snap & Pulse Ring
    const pSnap = clamp(tAdj / 0.80);
    const easeSnap = easeOutBack(pSnap);
    const sSnap = 0.5 + 0.5 * easeSnap;

    ctx.save();
    ctx.scale(sSnap, sSnap);
    ctx.globalAlpha = clamp(pSnap * 1.6);

    if (customImg) {
      const a = customImg.naturalWidth / customImg.naturalHeight;
      const dw = baseH * a;
      ctx.drawImage(customImg, -dw / 2, -baseH / 2, dw, baseH);
    } else {
      drawNkeEmblemDirect(ctx, startX, topY, botY, greenW, rectW, scale);
    }
    ctx.restore();

    // Shockwave Rings
    if (tAdj > 0.5 && tAdj < 1.7) {
      const pR = clamp((tAdj - 0.5) / 1.0);
      const ringR = (baseH * 0.6) + pR * 140 * scale;
      const ringAlpha = (1 - pR) * 0.8;
      ctx.save();
      ctx.strokeStyle = `rgba(56, 189, 248, ${ringAlpha})`;
      ctx.lineWidth = (3 - pR * 2) * scale;
      ctx.beginPath();
      ctx.arc(0, 0, ringR, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  } else if (animType === 'matrix_scan_reveal') {
    // 5. Digital Matrix Scan Reveal
    const pScan = clamp(tAdj / 1.0);
    const easeScan = easeOutCubic(pScan);

    ctx.save();
    // Clip top to bottom
    const clipH = baseH * easeScan;
    ctx.beginPath();
    ctx.rect(-emblemW, -baseH / 2, emblemW * 2, clipH);
    ctx.clip();

    if (customImg) {
      const a = customImg.naturalWidth / customImg.naturalHeight;
      const dw = baseH * a;
      ctx.drawImage(customImg, -dw / 2, -baseH / 2, dw, baseH);
    } else {
      drawNkeEmblemDirect(ctx, startX, topY, botY, greenW, rectW, scale);
    }

    // Laser Line at the cutting edge
    const edgeY = -baseH / 2 + clipH;
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.95)';
    ctx.lineWidth = 2 * scale;
    ctx.beginPath();
    ctx.moveTo(-emblemW * 0.8, edgeY);
    ctx.lineTo(emblemW * 0.8, edgeY);
    ctx.stroke();

    ctx.restore();
  } else {
    // 1. DEFAULT: NKE Sliced Triangles (nke_triangles_assemble)
    const pGreen = clamp(tAdj / 0.55);
    const pBlue = clamp((tAdj - 0.38) / 0.55);
    const pYellow = clamp((tAdj - 0.75) / 0.55);

    // Green Triangle
    if (pGreen > 0) {
      const sGreen = 0.6 + 0.4 * easeOutBack(pGreen);
      const aGreen = clamp(pGreen * 1.8);
      ctx.save();
      ctx.translate(startX + greenW / 2, botY);
      ctx.scale(sGreen, sGreen);
      ctx.translate(-(startX + greenW / 2), -botY);
      ctx.globalAlpha = aGreen;

      ctx.fillStyle = '#12A727';
      ctx.beginPath();
      ctx.moveTo(startX, botY);
      ctx.lineTo(startX + greenW, topY);
      ctx.lineTo(startX + greenW, botY);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = 'rgba(255,255,255,0.7)';
      ctx.lineWidth = 1.2 * scale;
      ctx.stroke();
      ctx.restore();
    }

    // Blue Triangle
    if (pBlue > 0) {
      const sBlue = 0.6 + 0.4 * easeOutBack(pBlue);
      const aBlue = clamp(pBlue * 1.8);
      const emblemEnd = startX + greenW + rectW;
      ctx.save();
      ctx.translate(startX + greenW + rectW / 2, 0);
      ctx.scale(sBlue, sBlue);
      ctx.translate(-(startX + greenW + rectW / 2), 0);
      ctx.globalAlpha = aBlue;

      ctx.fillStyle = '#144DFF';
      ctx.beginPath();
      ctx.moveTo(startX + greenW, topY);
      ctx.lineTo(startX + greenW, botY);
      ctx.lineTo(emblemEnd, botY);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = 'rgba(255,255,255,0.7)';
      ctx.lineWidth = 1.2 * scale;
      ctx.stroke();
      ctx.restore();
    }

    // Yellow/Amber Triangle
    if (pYellow > 0) {
      const sYellow = 0.6 + 0.4 * easeOutBack(pYellow);
      const aYellow = clamp(pYellow * 1.8);
      const emblemEnd = startX + greenW + rectW;
      ctx.save();
      ctx.translate(startX + greenW + rectW / 2, 0);
      ctx.scale(sYellow, sYellow);
      ctx.translate(-(startX + greenW + rectW / 2), 0);
      ctx.globalAlpha = aYellow;

      ctx.fillStyle = '#FFB51C';
      ctx.beginPath();
      ctx.moveTo(startX + greenW, topY);
      ctx.lineTo(emblemEnd, topY);
      ctx.lineTo(emblemEnd, botY);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = 'rgba(255,255,255,0.7)';
      ctx.lineWidth = 1.2 * scale;
      ctx.stroke();
      ctx.restore();
    }

    // Anamorphic flare sweep across the formed emblem
    if (tAdj > 1.2 && tAdj < 2.1) {
      const pFlare = clamp((tAdj - 1.2) / 0.85);
      const flareX = (pFlare * 2 - 1) * (emblemW * 1.1);
      const flareA = Math.sin(pFlare * Math.PI) * 0.9;
      ctx.save();
      ctx.translate(flareX, 0);
      const fGrad = ctx.createLinearGradient(-emblemW * 0.5, 0, emblemW * 0.5, 0);
      fGrad.addColorStop(0, 'rgba(255,255,255,0)');
      fGrad.addColorStop(0.5, `rgba(255,255,255,${flareA})`);
      fGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fGrad;
      ctx.fillRect(-emblemW * 0.5, -3 * scale, emblemW, 6 * scale);
      ctx.restore();
    }
  }

  // ---------------------------------------------------------
  // LOGO TEXT / TITLE ON RIGHT SIDE
  // ---------------------------------------------------------
  if (alphaText > 0) {
    const textStartX = startX + emblemW + 28 * scale;
    const textSlide = (1 - easeText) * 26 * scale;

    ctx.save();
    ctx.globalAlpha = alphaText;

    // Glowing Divider
    const divH = baseH * 0.72 * easeText;
    const divGrad = ctx.createLinearGradient(0, -divH, 0, divH);
    divGrad.addColorStop(0, 'rgba(255,255,255,0)');
    divGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.95)');
    divGrad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.strokeStyle = divGrad;
    ctx.lineWidth = 2.0 * scale;
    ctx.beginPath();
    ctx.moveTo(textStartX - 14 * scale, -divH);
    ctx.lineTo(textStartX - 14 * scale, divH);
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';

    const customTitle = (cfg.title || '').trim();
    const fontFam = cfg.bumperTitleFont || cfg.fontFamily || 'Plus Jakarta Sans';
    const titleCol = cfg.titleColor || '#FFFFFF';

    if (customTitle) {
      // User entered a custom title
      const fs = Math.min(32 * scale, (baseH * 0.45));
      ctx.font = `800 ${fs}px "${fontFam}", sans-serif`;
      ctx.fillStyle = 'rgba(0,0,0,0.8)';
      ctx.fillText(customTitle, textStartX + textSlide, 2 * scale);
      ctx.fillStyle = titleCol;
      ctx.fillText(customTitle, textStartX + textSlide, 0);
    } else {
      // Default NKE Brand Typography
      ctx.font = `900 ${baseH * 0.28}px "${fontFam}", sans-serif`;
      ctx.fillStyle = '#FFFFFF';
      drawLetterSpacedTextLeft(ctx, 'N  U  S  A', textStartX + textSlide, -baseH * 0.28, 3.8 * scale);

      ctx.font = `800 ${baseH * 0.22}px "${fontFam}", sans-serif`;
      ctx.fillStyle = '#38BDF8';
      drawLetterSpacedTextLeft(ctx, 'KONSTRUKSI', textStartX + textSlide, 0.03 * baseH, 1.8 * scale);

      ctx.font = `800 ${baseH * 0.22}px "${fontFam}", sans-serif`;
      ctx.fillStyle = '#DF9B35';
      drawLetterSpacedTextLeft(ctx, 'ENJINIRING', textStartX + textSlide, 0.33 * baseH, 2.0 * scale);
    }

    ctx.restore();
  }

  ctx.restore();
}

/**
 * Direct drawing of complete NKE emblem vector
 */
function drawNkeEmblemDirect(
  ctx: CanvasRenderingContext2D,
  startX: number,
  topY: number,
  botY: number,
  greenW: number,
  rectW: number,
  scale: number
) {
  const emblemEnd = startX + greenW + rectW;

  // Green
  ctx.fillStyle = '#12A727';
  ctx.beginPath();
  ctx.moveTo(startX, botY);
  ctx.lineTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.closePath();
  ctx.fill();

  // Blue
  ctx.fillStyle = '#144DFF';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  // Yellow
  ctx.fillStyle = '#FFB51C';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(emblemEnd, topY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = 'rgba(255,255,255,0.7)';
  ctx.lineWidth = 1.2 * scale;
  ctx.stroke();
}

/**
 * Color Tone (Color Grading) Engine
 */
function applyColorTone(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  tone?: string
) {
  if (!tone || tone === 'none') return;

  ctx.save();
  if (tone === 'warm_cinematic') {
    ctx.globalCompositeOperation = 'soft-light';
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, 'rgba(245, 158, 11, 0.35)');
    grad.addColorStop(1, 'rgba(180, 83, 9, 0.45)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'cool_tech') {
    ctx.globalCompositeOperation = 'soft-light';
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, 'rgba(14, 165, 233, 0.35)');
    grad.addColorStop(1, 'rgba(3, 105, 161, 0.45)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'cyber_neon') {
    ctx.globalCompositeOperation = 'screen';
    const grad = ctx.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, 'rgba(6, 182, 212, 0.22)');
    grad.addColorStop(1, 'rgba(217, 70, 239, 0.22)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'emerald_signature') {
    ctx.globalCompositeOperation = 'soft-light';
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, 'rgba(16, 185, 129, 0.35)');
    grad.addColorStop(1, 'rgba(234, 179, 8, 0.30)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'sunset_amber') {
    ctx.globalCompositeOperation = 'color-dodge';
    const grad = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.7);
    grad.addColorStop(0, 'rgba(249, 115, 22, 0.25)');
    grad.addColorStop(1, 'rgba(124, 45, 18, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else if (tone === 'noir_luxe') {
    ctx.globalCompositeOperation = 'saturation';
    ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
    ctx.fillRect(0, 0, w, h);
    ctx.globalCompositeOperation = 'soft-light';
    ctx.fillStyle = 'rgba(217, 119, 6, 0.25)';
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

/**
 * ==============================================================================
 * MODE 1: MASTER BUMPER LOGO PRESENTATION
 * Supports:
 * a. Multiple Logo (Up to 2 logos with sequential reveal, dividers, and slide left)
 * b. Single Logo (Hero centered, triangle pieces assemble, slide left, text reveal)
 * ==============================================================================
 */
function renderMasterPresentation(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number,
  speed: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const dur = Math.max(1, cfg.duration);
  const scale = Math.min(w, h) / 1000;
  const tAdj = t * speed;

  const cameraZoom = 1.0 + 0.025 * clamp(t / dur);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(cameraZoom, cameraZoom);

  const primaryTitleColor = cfg.titleColor || cfg.primaryColor || '#FFFFFF';
  const secColor = cfg.secondaryColor || '#DF9B35';
  const isSingleLogo = cfg.logoCountMode === 'single';

  // ===========================================================================
  // SUB-MODE A: SINGLE LOGO (Hero Center, Segmented Triangles, Slide Left, Logo Text Reveal)
  // ===========================================================================
  if (isSingleLogo) {
    renderSingleLogoSlicedAssemble(ctx, w, h, cfg, tAdj, scale, secColor);
    ctx.restore();
    return;
  }

  // ===========================================================================
  // SUB-MODE B: MULTIPLE LOGO (Supports Dynamic Active Logos - No ghost slots!)
  // ===========================================================================
  const targetH = 54 * scale;
  const rawLogos = (cfg.bumperLogos && cfg.bumperLogos.length > 0)
    ? cfg.bumperLogos
    : [
        { id: '1', enabled: true, name: 'Nusa Konstruksi', url: '/assets/aistudio/kso_nke_hd.png' },
        { id: '2', enabled: true, name: 'Jaya Konstruksi', url: '/assets/aistudio/kso_jaya_hd.png' },
      ];

  // Strictly filter only active enabled logos with an image or name
  const activeSlots = rawLogos.filter((s) => s.enabled && (s.url || s.name));

  const logoItems = activeSlots.map((slot) => {
    const img = slot.url ? getCachedImage(slot.url) : null;
    let aspect = 1.5;
    if (img && img.naturalHeight > 0) {
      aspect = img.naturalWidth / img.naturalHeight;
    } else if (slot.url?.includes('kso_nke') || slot.name?.toLowerCase().includes('nke')) {
      aspect = 1800 / 362;
    } else if (slot.url?.includes('jaya')) {
      aspect = 1.0;
    } else if (slot.url?.includes('wiswa')) {
      aspect = 1.0;
    }
    const lw = targetH * aspect;
    return { slot, img, aspect, w: lw };
  });

  const gap = 32 * scale;
  const totalLogosW = logoItems.reduce((acc, it) => acc + it.w, 0) + Math.max(0, logoItems.length - 1) * gap;
  const startX = -totalLogosW / 2;

  // Calculate coordinates for active logos and dividers
  let currentLeft = startX;
  const positionedLogos: { x: number; w: number; slot: any; img: any; idx: number }[] = [];
  const dividers: { x: number; p: number }[] = [];

  logoItems.forEach((it, idx) => {
    const xCenter = currentLeft + it.w / 2;
    positionedLogos.push({ x: xCenter, w: it.w, slot: it.slot, img: it.img, idx });
    currentLeft += it.w;
    if (idx < logoItems.length - 1) {
      const pDiv = clamp((tAdj - (0.5 + idx * 0.35)) / 0.25);
      dividers.push({ x: currentLeft + gap / 2, p: pDiv });
      currentLeft += gap;
    }
  });

  const displayTitle = (cfg.title || '').trim();
  const isSlideLeft = (cfg.transitionStyle || 'slide_left') === 'slide_left' && cfg.aspectRatio !== '9:16';
  const shouldSlide = displayTitle.length > 0 && isSlideLeft;

  const pSlide = clamp((tAdj - 2.15) / 0.85);
  const easeSlide = easeOutCubic(pSlide);

  let clusterX = 0;
  let clusterY = 0;

  if (shouldSlide) {
    const targetLeftX = -Math.min(w * 0.22, (totalLogosW / 2 + 100 * scale));
    clusterX = targetLeftX * easeSlide;
  } else if ((cfg.transitionStyle || 'slide_left') === 'slide_up' && displayTitle.length > 0) {
    const targetUpY = -70 * scale;
    clusterY = targetUpY * easeSlide;
  }

  // Anamorphic Lens Flare
  if (cfg.anamorphicFlare !== false && tAdj > 1.6 && tAdj < 2.7) {
    const flareP = clamp((tAdj - 1.6) / 1.1);
    const flareX = (flareP * 2.2 - 1.1) * (w * 0.45);
    const flareAlpha = Math.sin(flareP * Math.PI) * 0.85;

    ctx.save();
    ctx.translate(clusterX + flareX, clusterY);
    const beamGrad = ctx.createLinearGradient(-w * 0.4, 0, w * 0.4, 0);
    beamGrad.addColorStop(0, 'rgba(255,255,255,0)');
    beamGrad.addColorStop(0.35, hexToRgba(secColor, flareAlpha * 0.35));
    beamGrad.addColorStop(0.5, `rgba(255,255,255,${flareAlpha * 0.95})`);
    beamGrad.addColorStop(0.65, hexToRgba(secColor, flareAlpha * 0.35));
    beamGrad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = beamGrad;
    ctx.fillRect(-w * 0.4, -3 * scale, w * 0.8, 6 * scale);
    ctx.restore();
  }

  ctx.save();
  ctx.translate(clusterX, clusterY);

  // Render each active logo sequentially
  positionedLogos.forEach((pl) => {
    const pLogo = clamp((tAdj - (0.10 + pl.idx * 0.35)) / 0.60);
    const scaleLogo = 0.85 + 0.15 * easeOutBack(pLogo);
    const alphaLogo = clamp(pLogo * 1.5);

    if (alphaLogo > 0) {
      ctx.save();
      ctx.translate(pl.x, 0);
      ctx.scale(scaleLogo, scaleLogo);
      ctx.globalAlpha = alphaLogo;

      if (pl.img) {
        const aspect = pl.img.naturalWidth / pl.img.naturalHeight;
        const dw = targetH * aspect;
        ctx.drawImage(pl.img, -dw / 2, -targetH / 2, dw, targetH);
      } else if (pl.slot.url?.includes('kso_nke') || pl.slot.name?.toLowerCase().includes('nke')) {
        drawLogo1NKE(ctx, 0, 0, targetH, pl.w);
      } else if (pl.slot.url?.includes('jaya')) {
        drawLogo2Jaya(ctx, 0, 0, targetH, pl.w);
      } else {
        ctx.fillStyle = '#FFFFFF';
        ctx.font = `700 ${14 * scale}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(pl.slot.name, 0, 0);
      }
      ctx.restore();
    }
  });

  // Render dividers strictly between active logos
  dividers.forEach((d) => {
    if (d.p > 0) {
      const divH = targetH * 0.5 * easeOutCubic(d.p);
      ctx.save();
      ctx.strokeStyle = hexToRgba(secColor, 0.85);
      ctx.lineWidth = 1.5 * scale;
      ctx.globalAlpha = clamp(d.p * 1.5);
      ctx.beginPath();
      ctx.moveTo(d.x, -divH);
      ctx.lineTo(d.x, divH);
      ctx.stroke();
      ctx.restore();
    }
  });

  ctx.restore();

  // ===========================================================================
  // OPTIONAL TITLE FOR MULTIPLE LOGO
  // ===========================================================================
  const pText = clamp((tAdj - 2.1) / 0.85);
  const easeText = easeOutCubic(pText);
  const alphaText = clamp(pText * 1.3);

  if (displayTitle && alphaText > 0 && activeSlots.length > 0) {
    ctx.save();
    ctx.globalAlpha = alphaText;

    const titleFont = cfg.bumperTitleFont || cfg.fontFamily || 'Outfit';

    if (isSlideLeft) {
      const logoRightEdge = clusterX + totalLogosW / 2;
      const midDividerX = logoRightEdge + 25 * scale;

      const beamHeight = 58 * scale * easeText;
      ctx.save();
      const divBeamGrad = ctx.createLinearGradient(0, -beamHeight, 0, beamHeight);
      divBeamGrad.addColorStop(0, 'rgba(255,255,255,0)');
      divBeamGrad.addColorStop(0.5, hexToRgba(secColor, 0.9));
      divBeamGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = divBeamGrad;
      ctx.lineWidth = 2 * scale;
      ctx.beginPath();
      ctx.moveTo(midDividerX, -beamHeight);
      ctx.lineTo(midDividerX, beamHeight);
      ctx.stroke();
      ctx.restore();

      const textSlideOffset = (1 - easeText) * 32 * scale;
      const textStartX = midDividerX + 24 * scale + textSlideOffset;

      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';

      const fontSize1 = 26 * scale * (cfg.fontSize || 1.0);
      ctx.font = `800 ${fontSize1}px "${titleFont}", sans-serif`;

      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText(displayTitle, textStartX, 2 * scale);

      ctx.fillStyle = primaryTitleColor;
      ctx.fillText(displayTitle, textStartX, 0);
    } else {
      const titleY = 46 * scale;
      const fontSize = 34 * scale * (cfg.fontSize || 1.0);
      ctx.font = `800 ${fontSize}px "${titleFont}", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText(displayTitle, 0, titleY + 3 * scale);

      ctx.fillStyle = primaryTitleColor;
      ctx.fillText(displayTitle, 0, titleY);
    }
    ctx.restore();
  }

  ctx.restore();
}

/**
 * ==============================================================================
 * MODE 2: VIDEO TITLE SCREEN
 * Directly matched from the reference user image (image_737631e5.png):
 * - Radiant Golden Tree of Life (Pohon Hayat IKN) emblem with ambient breathing halo
 * - Category Overline ("SIMULASI KONSTRUKSI")
 * - Main Bold Title ("PEMBANGUNAN")
 * - Secondary Subtitle ("HUNIAN VERTIKAL NEGARA")
 * - Pill Tag Badge ("TIPE 65")
 * - Location Footer ("DI IBU KOTA NUSANTARA")
 * - Precision bottom horizon line with partner icons
 * ==============================================================================
 */
function renderVideoTitleMode(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number,
  speed: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const scale = Math.min(w, h) / 1000;
  const tAdj = t * speed;

  const accentColor = cfg.accentColor || '#38BDF8';
  const goldColor = cfg.secondaryColor || '#DF9B35';

  const titleFont = cfg.titleFont || cfg.fontFamily || 'Plus Jakarta Sans';
  const topColor = cfg.titleTopColor || accentColor;
  const mainColor = cfg.titleMainColor || '#FFFFFF';
  const bottomColor = cfg.titleBottomColor || accentColor;

  const hasEmblem = cfg.titleEmblemEnabled !== false;
  const textTop = (cfg.titleTop || '').trim();
  const textMain = (cfg.titleMain || '').trim();
  const hasBadge = cfg.titleBadgeEnabled !== false && Boolean(cfg.titleBadgeText?.trim());
  const textBottom = (cfg.titleBottom || '').trim();

  // Transition Timing: Staggered reveal
  const pEmblem = clamp(tAdj / 0.8);
  const pCat = clamp((tAdj - 0.4) / 0.6);
  const pMain = clamp((tAdj - 0.7) / 0.8);
  const pBadge = clamp((tAdj - 1.2) / 0.6);
  const pFooter = clamp((tAdj - 1.5) / 0.6);

  // Dynamic stack elements calculation to prevent unnatural vertical gaps
  interface StackElement {
    type: 'emblem' | 'top' | 'main' | 'badge' | 'bottom';
    height: number;
  }
  const stack: StackElement[] = [];
  if (hasEmblem) stack.push({ type: 'emblem', height: 75 * scale });
  if (textTop) stack.push({ type: 'top', height: (cfg.titleTopSize || 20) * scale });
  if (textMain) stack.push({ type: 'main', height: (cfg.titleMainSize || 48) * scale * 1.05 });
  if (hasBadge) stack.push({ type: 'badge', height: 38 * scale });
  if (textBottom) stack.push({ type: 'bottom', height: (cfg.titleBottomSize || 18) * scale });

  const spacing = (cfg.videoTitleSpacing !== undefined ? cfg.videoTitleSpacing : 22) * scale;
  const totalStackH = stack.reduce((sum, item) => sum + item.height, 0) + Math.max(0, stack.length - 1) * spacing;

  let currentY = -totalStackH / 2;

  ctx.save();
  ctx.translate(cx, cy);

  stack.forEach((item) => {
    const itemCenterY = currentY + item.height / 2;

    if (item.type === 'emblem' && pEmblem > 0) {
      const emblemScale = 0.8 + 0.2 * easeOutBack(pEmblem);
      const emblemAlpha = clamp(pEmblem * 1.5);
      ctx.save();
      ctx.translate(0, itemCenterY);
      ctx.scale(emblemScale, emblemScale);
      ctx.globalAlpha = emblemAlpha;

      const haloPulse = 1.0 + Math.sin(t * 2.0) * 0.1;
      const haloGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, 70 * scale * haloPulse);
      haloGrad.addColorStop(0, 'rgba(223, 155, 53, 0.45)');
      haloGrad.addColorStop(0.5, 'rgba(223, 155, 53, 0.12)');
      haloGrad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = haloGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 70 * scale * haloPulse, 0, Math.PI * 2);
      ctx.fill();

      const customEmblem = cfg.titleEmblemUrl ? getCachedImage(cfg.titleEmblemUrl) : null;
      if (customEmblem) {
        const eAspect = customEmblem.naturalWidth / customEmblem.naturalHeight;
        const eH = 70 * scale;
        const eW = eH * eAspect;
        ctx.drawImage(customEmblem, -eW / 2, -eH / 2, eW, eH);
      } else {
        drawTreeOfLifeEmblem(ctx, 0, 0, 62 * scale, goldColor);
      }
      ctx.restore();
    } else if (item.type === 'top' && pCat > 0) {
      const catAlpha = clamp(pCat * 1.4);
      const catSlide = (1 - easeOutCubic(pCat)) * 14 * scale;
      const topFontSize = (cfg.titleTopSize || 20) * scale;
      ctx.save();
      ctx.globalAlpha = catAlpha;
      ctx.font = `700 ${topFontSize}px "${titleFont}", sans-serif`;
      ctx.fillStyle = topColor;
      drawLetterSpacedText(ctx, textTop.toUpperCase(), 0, itemCenterY + catSlide, 6 * scale);
      ctx.restore();
    } else if (item.type === 'main' && pMain > 0) {
      const mainAlpha = clamp(pMain * 1.5);
      const mainScale = 0.92 + 0.08 * easeOutBack(pMain);
      const mainFontSize = (cfg.titleMainSize || 48) * scale;

      ctx.save();
      ctx.globalAlpha = mainAlpha;
      ctx.translate(0, itemCenterY);
      ctx.scale(mainScale, mainScale);

      ctx.font = `900 ${mainFontSize}px "${titleFont}", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
      ctx.fillText(textMain.toUpperCase(), 0, 3 * scale);

      ctx.fillStyle = mainColor;
      ctx.fillText(textMain.toUpperCase(), 0, 0);

      // Specular shine pass across letters
      if (tAdj > 1.2) {
        const shineP = ((tAdj - 1.2) * 0.6) % 2.5;
        if (shineP < 1.0) {
          ctx.save();
          ctx.globalCompositeOperation = 'source-atop';
          const sX = (shineP * 2 - 1) * (w * 0.35);
          const sGrad = ctx.createLinearGradient(sX - 60 * scale, 0, sX + 60 * scale, 0);
          sGrad.addColorStop(0, 'rgba(255,255,255,0)');
          sGrad.addColorStop(0.5, 'rgba(255,255,255,0.85)');
          sGrad.addColorStop(1, 'rgba(255,255,255,0)');
          ctx.fillStyle = sGrad;
          ctx.fillRect(-w * 0.4, -50 * scale, w * 0.8, 100 * scale);
          ctx.restore();
        }
      }
      ctx.restore();
    } else if (item.type === 'badge' && pBadge > 0) {
      const badgeAlpha = clamp(pBadge * 1.5);
      const badgeScale = 0.8 + 0.2 * easeOutBack(pBadge);
      const textBadge = cfg.titleBadgeText;

      ctx.save();
      ctx.translate(0, itemCenterY);
      ctx.scale(badgeScale, badgeScale);
      ctx.globalAlpha = badgeAlpha;

      ctx.font = `900 ${18 * scale}px "${titleFont}", sans-serif`;
      const bW = ctx.measureText(textBadge).width + 42 * scale;
      const bH = 34 * scale;
      const bR = 8 * scale;

      // Drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      drawRoundedRect(ctx, -bW / 2, -bH / 2 + 3 * scale, bW, bH, bR);
      ctx.fill();

      // Badge Background
      const badgeBgGrad = ctx.createLinearGradient(0, -bH / 2, 0, bH / 2);
      badgeBgGrad.addColorStop(0, '#EAB308');
      badgeBgGrad.addColorStop(1, '#DF9B35');
      ctx.fillStyle = cfg.titleBadgeBgColor || badgeBgGrad;
      drawRoundedRect(ctx, -bW / 2, -bH / 2, bW, bH, bR);
      ctx.fill();

      ctx.fillStyle = cfg.titleBadgeTextColor || '#08101E';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(textBadge, 0, 1 * scale);
      ctx.restore();
    } else if (item.type === 'bottom' && pFooter > 0) {
      const footerAlpha = clamp(pFooter * 1.4);
      const footerSlide = (1 - easeOutCubic(pFooter)) * 12 * scale;
      const bottomFontSize = (cfg.titleBottomSize || 18) * scale;

      ctx.save();
      ctx.globalAlpha = footerAlpha;
      ctx.font = `700 ${bottomFontSize}px "${titleFont}", sans-serif`;
      ctx.fillStyle = bottomColor;
      drawLetterSpacedText(ctx, textBottom.toUpperCase(), 0, itemCenterY + footerSlide, 6 * scale);
      ctx.restore();
    }

    currentY += item.height + spacing;
  });

  // 6. BOTTOM HORIZON DIVIDER
  const baselineY = h * 0.44;
  ctx.save();
  const lineGrad = ctx.createLinearGradient(-w * 0.4, 0, w * 0.4, 0);
  lineGrad.addColorStop(0, 'rgba(255,255,255,0)');
  lineGrad.addColorStop(0.3, hexToRgba(goldColor, 0.3));
  lineGrad.addColorStop(0.5, 'rgba(255,255,255,0.95)');
  lineGrad.addColorStop(0.7, hexToRgba(goldColor, 0.3));
  lineGrad.addColorStop(1, 'rgba(255,255,255,0)');

  ctx.strokeStyle = lineGrad;
  ctx.lineWidth = 1.5 * scale;
  ctx.beginPath();
  ctx.moveTo(-w * 0.42, baselineY);
  ctx.lineTo(w * 0.42, baselineY);
  ctx.stroke();

  // Central dot marker
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(0, baselineY, 3 * scale, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.restore();
}

/**
 * ==============================================================================
 * MODE 3: FRAME VIDEO LOGO OVERLAY
 * Directly matched from the reference user image (LOGO_WM_NKE_R3_c1d75e16.png):
 * - Top-Right corner modern diagonal architectural badge
 * - Dual dynamic racing accent stripes: Electric Cyan & Amber Gold
 * - Crisp white or frosted interior surface
 * - Displays up to 3 partner / contractor logos cleanly inside
 * - Multiple style options: Diagonal badge, Glassmorphism bar, Cyber HUD,
 *   Broadcast lower third, Minimal watermark, Cinema letterbox.
 * ==============================================================================
 */
function renderFrameVideoMode(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number
) {
  const scale = Math.min(w, h) / 1000;
  const bgMode = cfg.frameBackgroundMode || 'transparent';

  // 1. RENDER BACKGROUND
  if (bgMode === 'transparent') {
    // Subtle checkerboard pattern to visualize transparency in editor viewport
    const checkSize = 24 * scale;
    ctx.fillStyle = '#08101E';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#0E1D36';
    for (let y = 0; y < h; y += checkSize) {
      for (let x = 0; x < w; x += checkSize) {
        if ((Math.floor(x / checkSize) + Math.floor(y / checkSize)) % 2 === 0) {
          ctx.fillRect(x, y, checkSize, checkSize);
        }
      }
    }
  } else if (bgMode === 'solid') {
    ctx.fillStyle = cfg.backgroundColor || '#08101E';
    ctx.fillRect(0, 0, w, h);
  } else if (bgMode === 'simulated_video') {
    // Ambient simulated video background
    const vGrad = ctx.createRadialGradient(w * 0.5, h * 0.4, 0, w * 0.5, h * 0.4, w * 0.8);
    vGrad.addColorStop(0, '#1E293B');
    vGrad.addColorStop(0.6, '#0F172A');
    vGrad.addColorStop(1, '#020617');
    ctx.fillStyle = vGrad;
    ctx.fillRect(0, 0, w, h);

    // Subtle moving camera lines
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
    ctx.lineWidth = 1 * scale;
    const waveY = (Math.sin(t * 0.8) * 0.1 + 0.5) * h;
    ctx.beginPath();
    ctx.moveTo(0, waveY);
    ctx.lineTo(w, waveY);
    ctx.stroke();
  } else {
    // Gradient mode
    const gGrad = ctx.createLinearGradient(0, 0, w, h);
    gGrad.addColorStop(0, cfg.backgroundColor || '#08101E');
    gGrad.addColorStop(1, cfg.backgroundSecondaryColor || '#121E36');
    ctx.fillStyle = gGrad;
    ctx.fillRect(0, 0, w, h);
  }

  // 2. RENDER THE CHOSEN FRAME STYLE (POJOK KANAN ATAS, DYNAMIC ACTIVE LOGOS)
  const rawFrameLogos = (cfg.frameLogos && cfg.frameLogos.length > 0)
    ? cfg.frameLogos
    : [
        { id: '1', enabled: true, name: 'Logo UNP', url: '/assets/aistudio/kso_wiswa_hd.png' },
        { id: '2', enabled: true, name: 'Nusa Konstruksi', url: '/assets/aistudio/kso_nke_hd.png' },
      ];
  const activeLogos = rawFrameLogos.filter((l) => l.enabled && (l.url || l.name));
  const logoCount = Math.max(1, activeLogos.length);

  const frameStyle = cfg.frameStyle || 'corner_badge_diagonal';

  if (frameStyle === 'corner_badge_diagonal') {
    // =========================================================================
    // STYLE 1: CORNER BADGE DIAGONAL (Exact match to LOGO_WM_NKE_R3_c1d75e16.png!)
    // Dynamic width based on active logo count with bevel & dual racing stripes
    // =========================================================================
    const badgeH = 72 * scale;
    const slotW = 130 * scale;
    const slantW = 42 * scale;
    const badgeW = slantW + 36 * scale + logoCount * slotW + 20 * scale;

    const startX = w - badgeW;
    const topY = 0;
    const botY = badgeH;

    ctx.save();

    // Drop Shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.65)';
    ctx.shadowBlur = 20 * scale;
    ctx.shadowOffsetY = 6 * scale;

    // Background Card Shape
    ctx.beginPath();
    ctx.moveTo(w, topY);
    ctx.lineTo(startX + slantW, topY);
    ctx.lineTo(startX, botY - 12 * scale);
    ctx.quadraticCurveTo(startX, botY, startX + 12 * scale, botY);
    ctx.lineTo(w, botY);
    ctx.closePath();

    const cardGrad = ctx.createLinearGradient(0, topY, 0, botY);
    cardGrad.addColorStop(0, '#FFFFFF');
    cardGrad.addColorStop(0.85, '#F8FAFC');
    cardGrad.addColorStop(1, '#EDF2F7');
    ctx.fillStyle = cardGrad;
    ctx.fill();

    ctx.shadowColor = 'transparent';

    // Accent Stripe 1: Electric Cyan (Outer angled stripe)
    ctx.fillStyle = cfg.frameAccentColor || '#0284C7';
    ctx.beginPath();
    ctx.moveTo(startX + slantW, topY);
    ctx.lineTo(startX + slantW + 14 * scale, topY);
    ctx.lineTo(startX + 14 * scale, botY);
    ctx.lineTo(startX, botY);
    ctx.closePath();
    ctx.fill();

    // Accent Stripe 2: Warm Amber Gold (Inner angled stripe)
    ctx.fillStyle = cfg.frameSecondaryAccent || '#F59E0B';
    ctx.beginPath();
    ctx.moveTo(startX + slantW + 16 * scale, topY);
    ctx.lineTo(startX + slantW + 24 * scale, topY);
    ctx.lineTo(startX + 24 * scale, botY);
    ctx.lineTo(startX + 16 * scale, botY);
    ctx.closePath();
    ctx.fill();

    // Logo Slots inside the card
    const contentStartX = startX + slantW + 28 * scale;
    activeLogos.forEach((logo, idx) => {
      const lx = contentStartX + idx * slotW + slotW / 2;
      const ly = badgeH / 2;
      const lImg = logo.url ? getCachedImage(logo.url) : null;

      if (lImg) {
        const aspect = lImg.naturalWidth / lImg.naturalHeight;
        const maxH = badgeH * 0.70;
        const maxW = slotW * 0.84;
        let dw = maxH * aspect;
        let dh = maxH;
        if (dw > maxW) {
          dw = maxW;
          dh = dw / aspect;
        }
        ctx.drawImage(lImg, lx - dw / 2, ly - dh / 2, dw, dh);
      } else {
        ctx.fillStyle = '#08101E';
        ctx.font = `800 ${11 * scale}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(logo.name, lx, ly);
      }

      // Hairline divider between logos
      if (idx < activeLogos.length - 1) {
        const divX = contentStartX + (idx + 1) * slotW;
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.45)';
        ctx.lineWidth = 1 * scale;
        ctx.beginPath();
        ctx.moveTo(divX, badgeH * 0.22);
        ctx.lineTo(divX, badgeH * 0.78);
        ctx.stroke();
      }
    });

    ctx.restore();
  } else if (frameStyle === 'glassmorphism_bar') {
    // =========================================================================
    // STYLE 2: GLASSMORPHISM FLOATING BAR (POJOK KANAN ATAS)
    // =========================================================================
    const slotW = 125 * scale;
    const barW = Math.max(220 * scale, logoCount * slotW + 36 * scale);
    const barH = 68 * scale;
    const barX = w - barW - 24 * scale;
    const barY = 20 * scale;
    const r = 16 * scale;

    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.55)';
    ctx.shadowBlur = 24 * scale;
    ctx.shadowOffsetY = 8 * scale;

    // Glass Background
    const glassGrad = ctx.createLinearGradient(barX, barY, barX, barY + barH);
    glassGrad.addColorStop(0, 'rgba(255, 255, 255, 0.24)');
    glassGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.10)');
    glassGrad.addColorStop(1, 'rgba(15, 23, 42, 0.45)');
    ctx.fillStyle = glassGrad;
    drawRoundedRect(ctx, barX, barY, barW, barH, r);
    ctx.fill();

    // Glowing Neon Border
    ctx.shadowColor = 'transparent';
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.75)';
    ctx.lineWidth = 1.5 * scale;
    ctx.stroke();

    // Glass Reflection Lip
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.lineWidth = 1 * scale;
    ctx.beginPath();
    ctx.moveTo(barX + r, barY + 2 * scale);
    ctx.lineTo(barX + barW - r, barY + 2 * scale);
    ctx.stroke();

    // Logos inside glass
    const contentStartX = barX + 18 * scale;
    activeLogos.forEach((logo, idx) => {
      const lx = contentStartX + idx * slotW + slotW / 2;
      const ly = barY + barH / 2;
      const lImg = logo.url ? getCachedImage(logo.url) : null;
      if (lImg) {
        const aspect = lImg.naturalWidth / lImg.naturalHeight;
        const maxH = barH * 0.65;
        const maxW = slotW * 0.85;
        let dw = maxH * aspect;
        let dh = maxH;
        if (dw > maxW) {
          dw = maxW;
          dh = dw / aspect;
        }
        ctx.drawImage(lImg, lx - dw / 2, ly - dh / 2, dw, dh);
      } else {
        ctx.fillStyle = '#FFFFFF';
        ctx.font = `700 ${11 * scale}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(logo.name, lx, ly);
      }

      if (idx < activeLogos.length - 1) {
        const divX = contentStartX + (idx + 1) * slotW;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 1 * scale;
        ctx.beginPath();
        ctx.moveTo(divX, barY + barH * 0.25);
        ctx.lineTo(divX, barY + barH * 0.75);
        ctx.stroke();
      }
    });
    ctx.restore();
  } else if (frameStyle === 'cyber_hud_corners') {
    // =========================================================================
    // STYLE 3: CYBER HUD TOP-RIGHT BRACKET (POJOK KANAN ATAS)
    // =========================================================================
    const slotW = 120 * scale;
    const hudW = Math.max(260 * scale, logoCount * slotW + 48 * scale);
    const hudH = 74 * scale;
    const hudX = w - hudW - 20 * scale;
    const hudY = 20 * scale;

    ctx.save();
    // Neon bracket outline
    ctx.strokeStyle = hexToRgba(cfg.accentColor || '#38BDF8', 0.85);
    ctx.lineWidth = 2 * scale;

    ctx.beginPath();
    ctx.moveTo(hudX, hudY);
    ctx.lineTo(w - 20 * scale, hudY);
    ctx.lineTo(w - 20 * scale, hudY + hudH);
    ctx.lineTo(hudX + 25 * scale, hudY + hudH);
    ctx.lineTo(hudX, hudY + hudH - 25 * scale);
    ctx.closePath();

    ctx.fillStyle = 'rgba(8, 16, 30, 0.90)';
    ctx.fill();
    ctx.stroke();

    // Accent line
    ctx.fillStyle = '#DF9B35';
    ctx.fillRect(hudX, hudY, 6 * scale, hudH - 25 * scale);

    // Blinking REC dot
    const isBlink = Math.sin(t * 3.5) > 0;
    ctx.fillStyle = isBlink ? '#EF4444' : '#7F1D1D';
    ctx.beginPath();
    ctx.arc(hudX + 22 * scale, hudY + 14 * scale, 3.5 * scale, 0, Math.PI * 2);
    ctx.fill();

    // Coordinate tag
    ctx.font = `700 ${9 * scale}px "JetBrains Mono", monospace`;
    ctx.fillStyle = '#38BDF8';
    ctx.fillText('REC  //  IKN-NUSANTARA 4K  [HD]', hudX + 32 * scale, hudY + 16 * scale);

    // Logos
    const logoAreaX = hudX + 24 * scale;
    activeLogos.forEach((logo, idx) => {
      const lx = logoAreaX + idx * slotW + slotW / 2;
      const ly = hudY + 44 * scale;
      const lImg = logo.url ? getCachedImage(logo.url) : null;
      if (lImg) {
        const aspect = lImg.naturalWidth / lImg.naturalHeight;
        const maxH = 28 * scale;
        const maxW = slotW * 0.85;
        let dw = maxH * aspect;
        let dh = maxH;
        if (dw > maxW) {
          dw = maxW;
          dh = dw / aspect;
        }
        ctx.drawImage(lImg, lx - dw / 2, ly - dh / 2, dw, dh);
      } else {
        ctx.fillStyle = '#38BDF8';
        ctx.font = `700 ${10 * scale}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(logo.name, lx, ly);
      }
    });

    ctx.restore();
  } else {
    // =========================================================================
    // STYLE 4: MINIMAL WATERMARK BADGE (POJOK KANAN ATAS)
    // =========================================================================
    const slotW = 115 * scale;
    const cardW = Math.max(200 * scale, logoCount * slotW + 32 * scale);
    const cardH = 62 * scale;
    const cardX = w - cardW - 24 * scale;
    const cardY = 20 * scale;

    ctx.save();
    ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
    drawRoundedRect(ctx, cardX, cardY, cardW, cardH, 12 * scale);
    ctx.fill();

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
    ctx.lineWidth = 1 * scale;
    ctx.stroke();

    const contentStartX = cardX + 16 * scale;
    activeLogos.forEach((logo, idx) => {
      const lx = contentStartX + idx * slotW + slotW / 2;
      const ly = cardY + cardH / 2;
      const lImg = logo.url ? getCachedImage(logo.url) : null;
      if (lImg) {
        const aspect = lImg.naturalWidth / lImg.naturalHeight;
        const maxH = cardH * 0.65;
        const maxW = slotW * 0.85;
        let dw = maxH * aspect;
        let dh = maxH;
        if (dw > maxW) {
          dw = maxW;
          dh = dw / aspect;
        }
        ctx.drawImage(lImg, lx - dw / 2, ly - dh / 2, dw, dh);
      } else {
        ctx.fillStyle = '#FFFFFF';
        ctx.font = `700 ${10 * scale}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(logo.name, lx, ly);
      }
    });
    ctx.restore();
  }
}

/**
 * Procedural Vector Drawing:
 * Indonesian Golden Tree of Life (Pohon Hayat Nusantara)
 */
function drawTreeOfLifeEmblem(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  goldColor: string
) {
  ctx.save();
  ctx.translate(x, y);

  const R = size * 0.22;
  const numRays = 15;

  // Central Solar Sun Core
  const sunGrad = ctx.createRadialGradient(0, -size * 0.15, 0, 0, -size * 0.15, R);
  sunGrad.addColorStop(0, '#FFFBEB');
  sunGrad.addColorStop(0.5, '#F59E0B');
  sunGrad.addColorStop(1, '#B45309');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(0, -size * 0.15, R * 0.65, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#FDE68A';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Radiating Golden Crown Fan Rays
  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 2.2;
  ctx.lineCap = 'round';

  for (let i = 0; i < numRays; i++) {
    const angle = -Math.PI / 2 + ((i - (numRays - 1) / 2) / (numRays - 1)) * (Math.PI * 0.82);
    const innerR = R * 0.8;
    const outerR = size * 0.52 - Math.abs(i - (numRays - 1) / 2) * 1.8;

    const x1 = Math.cos(angle) * innerR;
    const y1 = -size * 0.15 + Math.sin(angle) * innerR;
    const x2 = Math.cos(angle) * outerR;
    const y2 = -size * 0.15 + Math.sin(angle) * outerR;

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }

  // Intertwined Organic Tree Trunk & Roots Below
  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 2.4;
  ctx.beginPath();

  // Left symmetric branches
  ctx.moveTo(0, -size * 0.05);
  ctx.bezierCurveTo(-size * 0.2, size * 0.1, -size * 0.05, size * 0.25, -size * 0.22, size * 0.45);

  ctx.moveTo(0, 0);
  ctx.bezierCurveTo(-size * 0.12, size * 0.15, -size * 0.15, size * 0.3, 0, size * 0.48);

  // Right symmetric branches
  ctx.moveTo(0, -size * 0.05);
  ctx.bezierCurveTo(size * 0.2, size * 0.1, size * 0.05, size * 0.25, size * 0.22, size * 0.45);

  ctx.moveTo(0, 0);
  ctx.bezierCurveTo(size * 0.12, size * 0.15, size * 0.15, size * 0.3, 0, size * 0.48);

  ctx.stroke();

  ctx.restore();
}

/**
 * Sliced Ultra-HD Logo Renderers
 */
function drawLogo1NKE(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgNKE = getCachedImage('/assets/aistudio/kso_nke_hd.png');
  if (imgNKE) {
    ctx.drawImage(imgNKE, x - w / 2, y - h / 2, w, h);
    return;
  }

  // Fallback Procedural
  ctx.save();
  ctx.translate(x, y);
  const startX = -w / 2;
  const topY = -h / 2;
  const botY = h / 2;

  const greenW = 1.33 * h;
  ctx.fillStyle = '#12A727';
  ctx.beginPath();
  ctx.moveTo(startX, botY);
  ctx.lineTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.closePath();
  ctx.fill();

  const rectW = 1.33 * h;
  const emblemEnd = startX + greenW + rectW;
  ctx.fillStyle = '#144DFF';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#FFB51C';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(emblemEnd, topY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  const textX = emblemEnd + 0.22 * h;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#FFFFFF';
  ctx.font = `800 ${h * 0.28}px "Plus Jakarta Sans", sans-serif`;
  drawLetterSpacedTextLeft(ctx, 'N  U  S  A', textX, -h * 0.26, 3.0);
  ctx.font = `700 ${h * 0.22}px "Plus Jakarta Sans", sans-serif`;
  drawLetterSpacedTextLeft(ctx, 'KONSTRUKSI', textX, 0.02 * h, 1.4);
  drawLetterSpacedTextLeft(ctx, 'ENJINIRING', textX, 0.30 * h, 1.6);
  ctx.restore();
}

function drawLogo2Jaya(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgJaya = getCachedImage('/assets/aistudio/kso_jaya_hd.png');
  if (imgJaya) {
    ctx.drawImage(imgJaya, x - w / 2, y - h / 2, w, h);
    return;
  }

  ctx.save();
  ctx.translate(x, y);
  const R = h / 2;
  const strokeW = Math.max(2.6, h * 0.065);

  ctx.strokeStyle = '#FFAE19';
  ctx.lineWidth = strokeW;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.arc(0, 0, R - strokeW / 2, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(0.08 * R, 0.65 * R);
  ctx.lineTo(0.08 * R, -0.72 * R);
  ctx.lineTo(0.22 * R, -0.62 * R);
  ctx.lineTo(0.22 * R, -0.15 * R);
  ctx.lineTo(0.38 * R, 0);
  ctx.lineTo(0.38 * R, 0.40 * R);
  ctx.lineTo(0.55 * R, 0.65 * R);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-0.55 * R, 0.65 * R);
  ctx.lineTo(-0.38 * R, 0.40 * R);
  ctx.lineTo(-0.38 * R, -0.15 * R);
  ctx.lineTo(-0.20 * R, -0.28 * R);
  ctx.lineTo(-0.20 * R, 0.35 * R);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-0.55 * R, 0.65 * R);
  ctx.lineTo(0.55 * R, 0.65 * R);
  ctx.stroke();
  ctx.restore();
}

function drawLogo3Wiswa(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgWiswa = getCachedImage('/assets/aistudio/kso_wiswa_hd.png');
  if (imgWiswa) {
    ctx.drawImage(imgWiswa, x - w / 2, y - h / 2, w, h);
    return;
  }

  ctx.save();
  ctx.translate(x, y);
  const H = h;
  const strokeW = Math.max(2.4, H * 0.06);

  ctx.strokeStyle = '#C92B27';
  ctx.lineWidth = strokeW;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.beginPath();
  ctx.moveTo(0, -H * 0.46);
  ctx.lineTo(H * 0.44, 0);
  ctx.lineTo(0, H * 0.46);
  ctx.lineTo(-H * 0.44, 0);
  ctx.closePath();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(0, -H * 0.46);
  ctx.lineTo(0, H * 0.46);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-H * 0.44, 0);
  ctx.lineTo(H * 0.44, 0);
  ctx.stroke();
  ctx.restore();
}

/**
 * Text Typography Helpers
 */
function drawLetterSpacedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  spacing: number
) {
  const chars = text.split('');
  const widths = chars.map((c) => ctx.measureText(c).width);
  const totalWidth = widths.reduce((a, b) => a + b, 0) + (chars.length - 1) * spacing;
  let curX = x - totalWidth / 2;

  chars.forEach((char, idx) => {
    ctx.fillText(char, curX + widths[idx] / 2, y);
    curX += widths[idx] + spacing;
  });
}

function drawLetterSpacedTextLeft(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  spacing: number
) {
  let curX = x;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    ctx.fillText(ch, curX, y);
    curX += ctx.measureText(ch).width + spacing;
  }
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function applyFilmGrain(ctx: CanvasRenderingContext2D, w: number, h: number, time: number) {
  const grainCanvas = document.createElement('canvas');
  grainCanvas.width = 120;
  grainCanvas.height = 120;
  const gctx = grainCanvas.getContext('2d');
  if (!gctx) return;

  const imgData = gctx.createImageData(120, 120);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const val = Math.floor(Math.random() * 255);
    data[i] = val;
    data[i + 1] = val;
    data[i + 2] = val;
    data[i + 3] = 16;
  }
  gctx.putImageData(imgData, 0, 0);

  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const pattern = ctx.createPattern(grainCanvas, 'repeat');
  if (pattern) {
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

function applyVignette(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.save();
  const radius = Math.max(w, h) * 0.75;
  const vig = ctx.createRadialGradient(w / 2, h / 2, radius * 0.35, w / 2, h / 2, radius);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(0,0,0,0.65)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

function hexToRgba(hex: string, alpha: number = 1): string {
  if (!hex || !hex.startsWith('#')) return `rgba(255,255,255,${alpha})`;
  let c = hex.substring(1);
  if (c.length === 3) c = c.split('').map((x) => x + x).join('');
  const num = parseInt(c, 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}
