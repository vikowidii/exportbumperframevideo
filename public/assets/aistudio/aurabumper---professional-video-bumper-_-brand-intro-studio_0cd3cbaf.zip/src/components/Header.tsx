import React from 'react';
import { Film, Download, Sparkles, RotateCcw, Volume2, VolumeX, Type, Layers } from 'lucide-react';
import { BumperConfig, StudioMode } from '../types/bumper';

interface HeaderProps {
  config: BumperConfig;
  onUpdateConfig: (partial: Partial<BumperConfig>) => void;
  onOpenExport: () => void;
  onOpenAIModal: () => void;
  onReset: () => void;
  lang: 'id' | 'en';
  onToggleLang: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  config,
  onUpdateConfig,
  onOpenExport,
  onOpenAIModal,
  onReset,
  lang,
  onToggleLang,
}) => {
  const currentMode = config.studioMode || 'bumper_logo';

  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-4 px-4 sm:px-6 py-3 bg-neutral-950/95 backdrop-blur-md border-b border-neutral-800/80">
      {/* Zone 1: Premium Brand Wordmark & Logo */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-amber-500 p-[1.5px] shadow-lg shadow-cyan-500/20 group">
          <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center overflow-hidden relative">
            {/* Custom Glowing Futuristic FX Emblem */}
            <svg
              className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform duration-300"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <defs>
                <linearGradient id="fxGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#38BDF8" />
                  <stop offset="50%" stopColor="#818CF8" />
                  <stop offset="100%" stopColor="#F59E0B" />
                </linearGradient>
              </defs>
              <polygon points="5 3 19 12 5 21 5 3" fill="url(#fxGrad)" stroke="none" opacity="0.85" />
              <circle cx="12" cy="12" r="9" stroke="url(#fxGrad)" strokeWidth="1.8" />
              <path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="#38BDF8" strokeWidth="1.2" opacity="0.6" />
            </svg>
            <span className="absolute inset-0 bg-cyan-400/10 blur-sm pointer-events-none" />
          </div>
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="text-sm sm:text-base font-extrabold tracking-tight text-white">
              Editor Video Effect
            </span>
            <span className="hidden sm:inline-block px-1.5 py-0.5 text-[9px] font-bold font-mono text-cyan-300 bg-cyan-950/80 border border-cyan-800/60 rounded">
              PRO STUDIO
            </span>
          </div>
          <span className="text-[10px] text-neutral-400 tracking-wider font-medium">
            MOTION GRAPHICS & VIDEO BRANDING
          </span>
        </div>
      </div>

      {/* Zone 2: Fast 3-Mode Studio Switcher */}
      <div className="hidden md:flex items-center p-1 bg-neutral-900/90 border border-neutral-800/90 rounded-xl shadow-inner gap-1">
        <button
          type="button"
          onClick={() => onUpdateConfig({ studioMode: 'bumper_logo' })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            currentMode === 'bumper_logo'
              ? 'bg-neutral-800 text-cyan-400 shadow-sm border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Film className="w-3.5 h-3.5" />
          <span>1. Bumper Logo</span>
        </button>

        <button
          type="button"
          onClick={() => onUpdateConfig({ studioMode: 'video_title' })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            currentMode === 'video_title'
              ? 'bg-neutral-800 text-amber-400 shadow-sm border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>2. Video Title</span>
        </button>

        <button
          type="button"
          onClick={() => onUpdateConfig({ studioMode: 'frame_video' })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            currentMode === 'frame_video'
              ? 'bg-neutral-800 text-emerald-400 shadow-sm border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>3. Frame Video Logo</span>
        </button>
      </div>

      {/* Zone 3: Audio, Language, Reset & Export */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={() => onUpdateConfig({ soundEnabled: !config.soundEnabled })}
          className="p-2 rounded-lg border border-neutral-800 bg-neutral-900/60 text-neutral-300 hover:text-white hover:border-neutral-700 transition-colors"
          title={config.soundEnabled ? 'Matikan Suara' : 'Aktifkan Suara'}
        >
          {config.soundEnabled ? (
            <Volume2 className="w-4 h-4 text-emerald-400" />
          ) : (
            <VolumeX className="w-4 h-4 text-neutral-500" />
          )}
        </button>

        <button
          onClick={onReset}
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-neutral-800 bg-neutral-900/60 text-neutral-300 hover:text-white hover:border-neutral-700 text-xs transition-colors"
          title={lang === 'id' ? 'Kembalikan ke awal' : 'Reset to default'}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">{lang === 'id' ? 'Reset' : 'Reset'}</span>
        </button>

        <button
          onClick={onToggleLang}
          className="px-2 py-1.5 rounded-lg border border-neutral-800 bg-neutral-900/60 text-neutral-300 hover:text-white hover:border-neutral-700 text-xs font-mono transition-colors"
        >
          {lang === 'id' ? 'ID 🇮🇩' : 'EN 🇬🇧'}
        </button>

        <button
          onClick={onOpenExport}
          className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-neutral-950 bg-gradient-to-r from-cyan-400 via-sky-300 to-cyan-300 hover:from-cyan-300 hover:to-sky-200 rounded-xl shadow-md shadow-cyan-500/25 transition-all whitespace-nowrap active:scale-[0.98]"
        >
          <Download className="w-3.5 h-3.5 text-neutral-950 stroke-[2.5]" />
          <span>{lang === 'id' ? 'Ekspor Video' : 'Export Video'}</span>
        </button>
      </div>
    </header>
  );
};
