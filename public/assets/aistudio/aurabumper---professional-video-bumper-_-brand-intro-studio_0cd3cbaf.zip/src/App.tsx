import React, { useState } from 'react';
import { Header } from './components/Header';
import { PreviewViewport } from './components/PreviewViewport';
import { ControlsSidebar } from './components/ControlsSidebar';
import { ExportModal } from './components/ExportModal';
import { AIBumperModal } from './components/AIBumperModal';
import { BumperConfig, AIConcept } from './types/bumper';
import { BUMPER_PRESETS } from './data/presets';
import { Sparkles, Film, Download, ShieldCheck, Zap, Info } from 'lucide-react';

const INITIAL_CONFIG: BumperConfig = {
  // 3 Primary Studio Modes: 'bumper_logo' | 'video_title' | 'frame_video'
  studioMode: 'bumper_logo',

  // 1. Bumper Logo Settings
  logoCountMode: 'single',
  bumperLogos: [
    { id: 'logo1', enabled: true, name: 'Nusa Konstruksi Enjiniring', url: '/assets/aistudio/kso_nke_hd.png', scale: 1 },
    { id: 'logo2', enabled: true, name: 'Jaya Konstruksi', url: '/assets/aistudio/kso_jaya_hd.png', scale: 1 },
  ],
  singleLogo: {
    id: 'single1',
    enabled: true,
    name: 'Nusa Konstruksi Enjiniring',
    url: '/assets/aistudio/LOGO_WM_NKE_R3_c1d75e16.png',
    scale: 1.25,
  },
  singleLogoAnimation: 'nke_triangles_assemble',
  singleLogoTransition: 'nke_triangles_assemble',
  singleLogoScale: 1.25,
  title: 'NUSA JAYA WISWAKHARMAN, KSO',
  subtitle: '',
  tagline: '',
  titleColor: '#FFFFFF',
  bumperTitleFont: 'Outfit',

  // 2. Video Title Screen Settings (Top, Main, Bottom Titles)
  titleTop: 'SIMULASI KONSTRUKSI',
  titleTopSize: 22,
  titleTopColor: '#38BDF8',
  titleMain: 'PEMBANGUNAN HUNIAN VERTIKAL NEGARA',
  titleMainSize: 48,
  titleMainColor: '#FFFFFF',
  titleBottom: 'DI IBU KOTA NUSANTARA',
  titleBottomSize: 18,
  titleBottomColor: '#38BDF8',
  titleFont: 'Plus Jakarta Sans',
  videoTitleSpacing: 22,
  titleBadgeText: 'TIPE 65',
  titleBadgeEnabled: true,
  titleBadgeBgColor: '#DF9B35',
  titleBadgeTextColor: '#08101E',
  titleEmblemEnabled: true,
  titleEmblemUrl: '',
  titleTransition: 'kinetic_typography',

  // 3. Frame Video Logo Overlay Settings (Top-Right Corner strictly)
  frameStyle: 'corner_badge_diagonal',
  framePosition: 'top_right',
  frameBackgroundMode: 'transparent',
  frameGlowIntensity: 0.7,
  frameBorderRadius: 10,
  frameLogos: [
    { id: 'f_logo1', enabled: true, name: 'Logo UNP / Klien', url: '/assets/aistudio/kso_wiswa_hd.png', scale: 1 },
    { id: 'f_logo2', enabled: true, name: 'Nusa Konstruksi Enjiniring', url: '/assets/aistudio/kso_nke_hd.png', scale: 1 },
  ],
  frameAccentColor: '#38BDF8',
  frameSecondaryAccent: '#DF9B35',

  // Color Tone (Color Grading)
  colorTone: 'none',

  // Theming & Backgrounds
  theme: 'kso_corporate',
  aspectRatio: '16:9',
  duration: 5.5,
  fps: 60,
  primaryColor: '#FFFFFF',
  secondaryColor: '#DF9B35',
  accentColor: '#38BDF8',
  backgroundColor: '#08101E',
  backgroundSecondaryColor: '#0E1D36',
  backgroundStyle: 'gradient',
  spotlightEnabled: true,
  spotlightIntensity: 0.65,
  spotlightRadius: 70,
  spotlightSoftness: 0.75,
  spotlightYOffset: 0,
  spotlightPulseSpeed: 1.0,
  futuristicEffect: 'none',
  laserScanline: false,
  cyberHexMesh: false,
  hologramLines: false,
  lightStreaks: false,
  showGrid: true,
  gridOpacity: 0.04,
  fontFamily: 'Outfit',
  fontSize: 1.0,
  letterSpacing: 3,
  icon: 'kso',
  customLogoUrl: '/assets/aistudio/LOGO_KSO_HD_vektor_edcea276.png',
  ksoLogoMode: 'hd_vector',
  transitionStyle: 'slide_left',
  showPartnerLabels: false,
  particleCount: 45,
  particleColor: '#38BDF8',
  motionSpeed: 1.0,
  vignette: true,
  filmGrain: false,
  letterbox: false,
  anamorphicFlare: true,
  audioTheme: 'sfx_kso_official',
  soundEnabled: true,
  soundVolume: 0.8,
};

export default function App() {
  const [config, setConfig] = useState<BumperConfig>(INITIAL_CONFIG);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState<boolean>(false);
  const [lang, setLang] = useState<'id' | 'en'>('id');

  const handleUpdateConfig = (partial: Partial<BumperConfig>) => {
    setConfig((prev) => ({ ...prev, ...partial }));
  };

  const handleReset = () => {
    setConfig(INITIAL_CONFIG);
  };

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'id' ? 'en' : 'id'));
  };

  const handleApplyConcept = (concept: AIConcept) => {
    setConfig((prev) => ({
      ...prev,
      title: concept.title,
      subtitle: concept.slogan,
      theme: concept.themeId,
      primaryColor: concept.primaryColor,
      secondaryColor: concept.secondaryColor,
      fontFamily: concept.fontFamily,
      audioTheme: concept.audioTheme,
    }));
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top Bar adhering to Top Bar Contract */}
      <Header
        config={config}
        onUpdateConfig={handleUpdateConfig}
        onOpenExport={() => setIsExportModalOpen(true)}
        onOpenAIModal={() => setIsAIModalOpen(true)}
        onReset={handleReset}
        lang={lang}
        onToggleLang={handleToggleLang}
      />

      {/* Main Studio Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-8">
        {/* Workspace Title & Quick Context */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-neutral-800/60">
          <div className="flex flex-col gap-1">
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white flex items-center gap-2.5">
              <span>Editor Video Effect</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-800/60 text-cyan-400 font-mono">
                {config.studioMode === 'video_title'
                  ? 'Video Title Screen'
                  : config.studioMode === 'frame_video'
                  ? 'Frame Video Logo'
                  : 'Bumper Logo'}
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-neutral-400">
              {lang === 'id'
                ? 'Studio Editor Video Effect: Rancang Bumper Logo (Single / Multi-Logo), Video Title Screen arsitektural, dan Frame Video Logo overlay dengan visual futuristik & blended.'
                : 'Video Effect Editor Studio: Design Bumper Logos, Architectural Video Titles, and Blended Frame Video Logo Overlays with instant high-fps export.'}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>60 FPS Render</span>
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span>Web Audio Synth</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span>Format 16:9 / 9:16 / 1:1</span>
          </div>
        </div>

        {/* 2-Column Split: Viewport (Left/Center) + Controls (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Interactive Canvas Preview Viewport */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <PreviewViewport
              config={config}
              onUpdateConfig={handleUpdateConfig}
              lang={lang}
            />
          </div>

          {/* Right Column: Studio Controls Sidebar */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <ControlsSidebar
              config={config}
              onUpdateConfig={handleUpdateConfig}
              onOpenAIModal={() => setIsAIModalOpen(true)}
              lang={lang}
            />
          </div>
        </div>

        {/* Informational Guidance Section: How to Use Video Bumpers */}
        <section className="mt-6 p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800/80 flex flex-col gap-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-neutral-200">
            <Info className="w-4 h-4 text-cyan-400" />
            <span>
              {lang === 'id' ? 'Panduan Memasang Video Bumper ke Editor' : 'How to Use Your Bumper in Video Editors'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-neutral-400">
            <div className="p-3.5 bg-neutral-950/60 rounded-xl border border-neutral-800/60 flex flex-col gap-1.5">
              <span className="font-semibold text-neutral-200">
                {lang === 'id' ? '1. Di CapCut & TikTok' : '1. In CapCut & TikTok'}
              </span>
              <p className="leading-relaxed">
                {lang === 'id'
                  ? 'Pilih rasio 9:16 (Reels/Shorts), ekspor video, lalu import sebagai klip pembuka (0.0s - 4.0s) di timeline CapCut sebelum konten utama.'
                  : 'Choose 9:16 ratio, export, and place as the opening clip on your CapCut timeline before your main content.'}
              </p>
            </div>

            <div className="p-3.5 bg-neutral-950/60 rounded-xl border border-neutral-800/60 flex flex-col gap-1.5">
              <span className="font-semibold text-neutral-200">
                {lang === 'id' ? '2. Di Premiere Pro / DaVinci' : '2. In Premiere Pro / DaVinci'}
              </span>
              <p className="leading-relaxed">
                {lang === 'id'
                  ? 'Gunakan 16:9 1080p Full HD. Video sudah menyertakan trek audio sinematik otomatis sehingga Anda tidak perlu mencari sound effect terpisah.'
                  : 'Export at 1080p Full HD. The video file embeds synchronized audio tracks directly without needing third-party sound effects.'}
              </p>
            </div>

            <div className="p-3.5 bg-neutral-950/60 rounded-xl border border-neutral-800/60 flex flex-col gap-1.5">
              <span className="font-semibold text-neutral-200">
                {lang === 'id' ? '3. Poster Frame Thumbnail' : '3. Thumbnail Poster Frame'}
              </span>
              <p className="leading-relaxed">
                {lang === 'id'
                  ? 'Klik tombol "Unduh Foto (PNG)" di atas layar pratinjau untuk mendapatkan cover / thumbnail beresolusi tinggi secara instan.'
                  : 'Click "Snapshot (PNG)" on the preview bar to instantly save high-res poster frames for YouTube video thumbnails.'}
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-neutral-900 py-6 px-6 text-center text-xs text-neutral-500">
        <p>BumperCraft Studio · Pembuat Video Bumper & Intro Animasi Sinematik</p>
      </footer>

      {/* Modals */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        config={config}
        lang={lang}
      />

      <AIBumperModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        onApplyConcept={handleApplyConcept}
        lang={lang}
      />
    </div>
  );
}
