import React, { useState } from 'react';
import {
  Type,
  Palette,
  Sliders,
  Volume2,
  Sparkles,
  Upload,
  Image as ImageIcon,
  Check,
  Music,
  Film,
  Gamepad,
  Zap,
  Camera,
  Diamond,
  Shield,
  Play,
  RotateCcw,
} from 'lucide-react';
import { BumperConfig, BumperThemeId, AudioThemeId } from '../types/bumper';
import { audioEngine } from '../utils/audioEngine';

interface ControlsSidebarProps {
  config: BumperConfig;
  onUpdateConfig: (partial: Partial<BumperConfig>) => void;
  onOpenAIModal: () => void;
  lang: 'id' | 'en';
}

type TabType = 'text' | 'logo' | 'style' | 'audio';

const FONT_OPTIONS = [
  { id: 'Cinzel', name: 'Cinzel (Sinematik Mewah)' },
  { id: 'Outfit', name: 'Outfit (Modern & Cyber)' },
  { id: 'Oswald', name: 'Oswald (Kondensasi Agresif / Gaming)' },
  { id: 'Plus Jakarta Sans', name: 'Plus Jakarta Sans (Bersih & Elegan)' },
  { id: 'Space Grotesk', name: 'Space Grotesk (Tech Futuristik)' },
  { id: 'Playfair Display', name: 'Playfair Display (Klasik & Editorial)' },
];

const PRESET_ICONS = [
  { id: 'kso', name: 'Konsorsium 3 Logo KSO', icon: Shield },
  { id: 'film', name: 'Film & Bioskop', icon: Film },
  { id: 'gamepad', name: 'Gaming / Esport', icon: Gamepad },
  { id: 'bolt', name: 'Petir Elektrik', icon: Zap },
  { id: 'sparkles', name: 'Bintang Kosmik', icon: Sparkles },
  { id: 'music', name: 'Musik & Audio', icon: Music },
  { id: 'camera', name: 'Kamera / Foto', icon: Camera },
  { id: 'diamond', name: 'Berlian Luxury', icon: Diamond },
  { id: 'shield', name: 'Tameng & Keamanan', icon: Shield },
  { id: 'play', name: 'Tombol Putar', icon: Play },
  { id: 'monogram', name: 'Monogram Inisial', icon: Type },
];

const AUDIO_THEMES: { id: AudioThemeId; name: string; desc: string }[] = [
  { id: 'cinematic', name: 'Sinematik Sub Boom', desc: 'Whoosh atmosferik dan ledakan sub-bass megah' },
  { id: 'cyber', name: 'Cyber Glitch Riser', desc: 'Denyut digital futuristik dan distorsi laser' },
  { id: 'retro', name: '80s Synthwave Brass', desc: 'Akord analog synth retro dan gated snare 80-an' },
  { id: 'cosmic', name: 'Pusaran Supernova', desc: 'Swell etereal frekuensi naik dan lonceng kristal' },
  { id: 'minimal', name: 'Studio Tactile Pop', desc: 'Ketukan kayu organik bersih dan lonceng marimba' },
  { id: 'gaming', name: 'Esport 808 Heavy Drop', desc: 'Tebasan pisau dan dentuman sub 808 terdistorsi' },
  { id: 'none', name: 'Tanpa Suara (Mute)', desc: 'Ekspor video hening tanpa trek audio' },
];

export const ControlsSidebar: React.FC<ControlsSidebarProps> = ({
  config,
  onUpdateConfig,
  onOpenAIModal,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('text');

  // Handle custom logo image file upload
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        onUpdateConfig({
          icon: 'custom',
          customLogoUrl: dataUrl,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // Quick sound tester
  const handleTestSound = (themeId: AudioThemeId) => {
    audioEngine.play(themeId, config.soundVolume, 0);
  };

  return (
    <div className="flex flex-col bg-neutral-900/70 border border-neutral-800/80 rounded-2xl overflow-hidden shadow-xl w-full">
      {/* Category Tabs Header */}
      <div className="flex items-center border-b border-neutral-800/80 bg-neutral-950/60 p-1.5 gap-1">
        <button
          onClick={() => setActiveTab('text')}
          className={`flex items-center justify-center gap-1.5 flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'text'
              ? 'bg-neutral-800 text-cyan-400 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>{lang === 'id' ? 'Teks & Font' : 'Text & Font'}</span>
        </button>

        <button
          onClick={() => setActiveTab('logo')}
          className={`flex items-center justify-center gap-1.5 flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'logo'
              ? 'bg-neutral-800 text-cyan-400 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>{lang === 'id' ? 'Logo & Ikon' : 'Logo & Icon'}</span>
        </button>

        <button
          onClick={() => setActiveTab('style')}
          className={`flex items-center justify-center gap-1.5 flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'style'
              ? 'bg-neutral-800 text-cyan-400 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>{lang === 'id' ? 'Warna & FX' : 'Style & FX'}</span>
        </button>

        <button
          onClick={() => setActiveTab('audio')}
          className={`flex items-center justify-center gap-1.5 flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'audio'
              ? 'bg-neutral-800 text-cyan-400 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Volume2 className="w-3.5 h-3.5" />
          <span>{lang === 'id' ? 'Audio FX' : 'Audio FX'}</span>
        </button>
      </div>

      {/* Tab Contents */}
      <div className="p-4 sm:p-5 flex flex-col gap-5 overflow-y-auto max-h-[600px]">
        {/* ================= TAB 1: TEXT & FONT ================= */}
        {activeTab === 'text' && (
          <div className="flex flex-col gap-4">
            {/* Title Input */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-neutral-300">
                {lang === 'id' ? 'Nama Brand / Channel Utama' : 'Main Brand / Title'}
              </label>
              <input
                type="text"
                value={config.title}
                onChange={(e) => onUpdateConfig({ title: e.target.value })}
                placeholder="misal: AURA CINEMA"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-sm text-neutral-100 placeholder:text-neutral-600 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/30 transition-all font-medium"
              />
            </div>

            {/* Subtitle / Slogan Input */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-neutral-300">
                  {lang === 'id' ? 'Slogan Pendek / Subtitle (Opsional)' : 'Tagline / Subtitle (Optional)'}
                </label>
                {config.subtitle ? (
                  <button
                    type="button"
                    onClick={() => onUpdateConfig({ subtitle: '' })}
                    className="text-[11px] text-amber-400 hover:text-amber-300 transition-colors font-medium"
                  >
                    {lang === 'id' ? '✕ Kosongkan Slogan' : '✕ Clear Slogan'}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onOpenAIModal}
                    className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>{lang === 'id' ? 'Ide Slogan AI' : 'AI Slogan'}</span>
                  </button>
                )}
              </div>
              <input
                type="text"
                value={config.subtitle}
                onChange={(e) => onUpdateConfig({ subtitle: e.target.value })}
                placeholder={lang === 'id' ? 'Biarkan kosong untuk tampilan bersih tanpa slogan' : 'Leave empty for no tagline'}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-sm text-neutral-100 placeholder:text-neutral-600 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/30 transition-all"
              />
              <span className="text-[11px] text-neutral-500">
                {lang === 'id'
                  ? 'Sesuai arahan: Kosongkan field ini agar tidak ada slogan kecil di bawah judul.'
                  : 'Leave empty for an authoritative, clean corporate look without slogans.'}
              </span>
            </div>

            {/* Font Family Selector */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-neutral-300">
                {lang === 'id' ? 'Gaya Tipografi Font' : 'Typography Font'}
              </label>
              <select
                value={config.fontFamily}
                onChange={(e) => onUpdateConfig({ fontFamily: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-sm text-neutral-100 focus:outline-none focus:border-cyan-400 cursor-pointer"
              >
                {FONT_OPTIONS.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Font Size Multiplier Slider */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{lang === 'id' ? 'Skala Ukuran Teks' : 'Text Size Scale'}</span>
                <span className="font-mono text-neutral-300 tabular-nums">
                  {config.fontSize.toFixed(2)}x
                </span>
              </div>
              <input
                type="range"
                min={0.7}
                max={1.4}
                step={0.05}
                value={config.fontSize}
                onChange={(e) => onUpdateConfig({ fontSize: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* AI Slogan Quick Generator Banner */}
            <div className="p-3.5 rounded-xl bg-gradient-to-r from-cyan-950/40 to-indigo-950/40 border border-cyan-800/40 flex items-center justify-between gap-3">
              <div className="flex flex-col">
                <span className="text-xs font-semibold text-cyan-200">
                  {lang === 'id' ? 'Butuh Slogan Menarik?' : 'Need a Punchy Slogan?'}
                </span>
                <span className="text-[11px] text-neutral-400">
                  {lang === 'id'
                    ? 'Buat 4 konsep unik dengan AI Gemini'
                    : 'Generate 4 tailored concepts with Gemini'}
                </span>
              </div>
              <button
                onClick={onOpenAIModal}
                className="px-3 py-1.5 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm transition-colors whitespace-nowrap"
              >
                {lang === 'id' ? 'Buka Asisten' : 'Open AI'}
              </button>
            </div>
          </div>
        )}

        {/* ================= TAB 2: LOGO & ICON ================= */}
        {activeTab === 'logo' && (
          <div className="flex flex-col gap-4">
            {/* KSO Motion & Transition Choreography */}
            {(config.icon === 'kso' || config.theme.startsWith('kso')) && (
              <div className="p-3.5 bg-neutral-950/80 border border-cyan-800/50 rounded-xl flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-cyan-300">
                    {lang === 'id' ? 'Koreografi Gerak & Transisi' : 'Motion & Transition Choreography'}
                  </span>
                  <span className="text-[10px] text-cyan-400 font-mono">SEKUENSIAL</span>
                </div>

                <div className="grid grid-cols-1 gap-2">
                  <button
                    type="button"
                    onClick={() => onUpdateConfig({ transitionStyle: 'slide_left' })}
                    className={`flex flex-col text-left p-2.5 rounded-lg border transition-all ${
                      (config.transitionStyle || 'slide_left') === 'slide_left'
                        ? 'bg-neutral-800 border-cyan-400 text-white shadow-sm'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <span className="text-xs font-semibold text-cyan-200">
                      ★ Muncul di Tengah → Geser ke Kiri (Teks Muncul di Kanan)
                    </span>
                    <span className="text-[11px] text-neutral-400 mt-0.5">
                      Logo NKE, Jaya, & Wiswakharman muncul satu per satu di tengah, lalu bergeser mulus ke kiri saat teks judul terungkap.
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateConfig({ transitionStyle: 'slide_up' })}
                    className={`flex flex-col text-left p-2.5 rounded-lg border transition-all ${
                      config.transitionStyle === 'slide_up'
                        ? 'bg-neutral-800 border-cyan-400 text-white shadow-sm'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <span className="text-xs font-semibold text-neutral-200">
                      Muncul di Tengah → Geser ke Atas (Teks Muncul di Bawah)
                    </span>
                    <span className="text-[11px] text-neutral-400 mt-0.5">
                      Logo muncul satu per satu di tengah, lalu bergeser ke atas dan teks judul muncul di bawahnya.
                    </span>
                  </button>
                </div>

                {/* Sourced from User HD Vector Upload */}
                <div className="p-2 bg-cyan-950/30 border border-cyan-800/40 rounded-lg text-[11px] text-cyan-300 flex items-center justify-between">
                  <span>Aset Logo: Ultra-HD Vektor Asli (3340×660)</span>
                  <span className="text-[10px] text-cyan-400 font-mono">100% SHARP</span>
                </div>
              </div>
            )}

            {/* Custom Logo Upload Area */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-neutral-300">
                {lang === 'id' ? 'Ganti File Logo (Opsional)' : 'Change Logo File (Optional)'}
              </label>

              <label className="relative flex flex-col items-center justify-center p-4 border border-dashed border-neutral-700 hover:border-cyan-400 bg-neutral-950/60 rounded-xl cursor-pointer transition-colors group">
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/svg+xml,image/webp"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
                <Upload className="w-5 h-5 text-neutral-500 group-hover:text-cyan-400 transition-colors mb-1.5" />
                <span className="text-xs font-medium text-neutral-300 group-hover:text-white">
                  {lang === 'id' ? 'Klik untuk memilih file logo baru' : 'Click to select new logo file'}
                </span>
                <span className="text-[10px] text-neutral-500 mt-0.5">
                  Mendukung PNG transparan & resolusi tinggi
                </span>
              </label>

              {config.customLogoUrl && (
                <div className="flex items-center justify-between p-2 bg-neutral-950 border border-neutral-800 rounded-lg">
                  <div className="flex items-center gap-2">
                    <img
                      src={config.customLogoUrl}
                      alt="Logo preview"
                      className="w-8 h-8 rounded object-contain bg-neutral-800 p-0.5"
                    />
                    <span className="text-xs text-neutral-300 font-medium">Logo KSO Aktif</span>
                  </div>
                  <button
                    onClick={() => onUpdateConfig({ customLogoUrl: undefined, icon: 'kso' })}
                    className="text-xs text-red-400 hover:text-red-300 px-2 py-1 rounded"
                  >
                    Reset
                  </button>
                </div>
              )}
            </div>

            {/* Preset Vector Icons Grid */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-neutral-300">
                {lang === 'id' ? 'Atau Pilih Preset Ikon Vektor' : 'Or Select Vector Icon'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {PRESET_ICONS.map((item) => {
                  const IconComp = item.icon;
                  const isSelected = config.icon === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onUpdateConfig({ icon: item.id })}
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-neutral-800 border-cyan-400 text-cyan-300 shadow-sm'
                          : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-neutral-200 hover:border-neutral-700'
                      }`}
                    >
                      <IconComp className="w-4 h-4 shrink-0" />
                      <span className="text-xs font-medium truncate">{item.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 3: STYLE & FX ================= */}
        {activeTab === 'style' && (
          <div className="flex flex-col gap-4">
            {/* Color Pickers */}
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-neutral-300">
                  {lang === 'id' ? 'Warna Utama' : 'Primary Color'}
                </label>
                <div className="flex items-center gap-2 p-1.5 bg-neutral-950 border border-neutral-800 rounded-lg">
                  <input
                    type="color"
                    value={config.primaryColor}
                    onChange={(e) => onUpdateConfig({ primaryColor: e.target.value })}
                    className="w-7 h-7 rounded border-0 bg-transparent cursor-pointer"
                  />
                  <span className="text-xs font-mono text-neutral-300 uppercase">
                    {config.primaryColor}
                  </span>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-neutral-300">
                  {lang === 'id' ? 'Warna Sekunder' : 'Secondary Color'}
                </label>
                <div className="flex items-center gap-2 p-1.5 bg-neutral-950 border border-neutral-800 rounded-lg">
                  <input
                    type="color"
                    value={config.secondaryColor}
                    onChange={(e) => onUpdateConfig({ secondaryColor: e.target.value })}
                    className="w-7 h-7 rounded border-0 bg-transparent cursor-pointer"
                  />
                  <span className="text-xs font-mono text-neutral-300 uppercase">
                    {config.secondaryColor}
                  </span>
                </div>
              </div>
            </div>

            {/* Duration Slider */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{lang === 'id' ? 'Durasi Video Bumper' : 'Video Duration'}</span>
                <span className="font-mono text-neutral-300 tabular-nums">
                  {config.duration.toFixed(1)}s
                </span>
              </div>
              <input
                type="range"
                min={3}
                max={8}
                step={0.5}
                value={config.duration}
                onChange={(e) => onUpdateConfig({ duration: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Motion Speed Multiplier */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{lang === 'id' ? 'Kecepatan Animasi' : 'Motion Speed'}</span>
                <span className="font-mono text-neutral-300 tabular-nums">
                  {config.motionSpeed.toFixed(1)}x
                </span>
              </div>
              <input
                type="range"
                min={0.7}
                max={1.5}
                step={0.1}
                value={config.motionSpeed}
                onChange={(e) => onUpdateConfig({ motionSpeed: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Particle Density */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{lang === 'id' ? 'Jumlah Partikel FX' : 'Particle Count'}</span>
                <span className="font-mono text-neutral-300 tabular-nums">
                  {config.particleCount}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={300}
                step={20}
                value={config.particleCount}
                onChange={(e) => onUpdateConfig({ particleCount: parseInt(e.target.value, 10) })}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Glitch Intensity Slider */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{lang === 'id' ? 'Intensitas Distorsi Glitch' : 'Glitch Distortion'}</span>
                <span className="font-mono text-neutral-300 tabular-nums">
                  {Math.round(config.glitchIntensity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={config.glitchIntensity}
                onChange={(e) => onUpdateConfig({ glitchIntensity: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Cinematic Post FX Toggles */}
            <div className="flex flex-col gap-2 pt-2 border-t border-neutral-800">
              <span className="text-xs font-semibold text-neutral-300">
                {lang === 'id' ? 'Efek Sinematik' : 'Cinematic FX'}
              </span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => onUpdateConfig({ letterbox: !config.letterbox })}
                  className={`px-3 py-2 text-xs font-medium rounded-lg border text-center transition-colors ${
                    config.letterbox
                      ? 'bg-neutral-800 border-cyan-400 text-cyan-300'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  Letterbox
                </button>

                <button
                  onClick={() => onUpdateConfig({ vignette: !config.vignette })}
                  className={`px-3 py-2 text-xs font-medium rounded-lg border text-center transition-colors ${
                    config.vignette
                      ? 'bg-neutral-800 border-cyan-400 text-cyan-300'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  Vignette
                </button>

                <button
                  onClick={() => onUpdateConfig({ filmGrain: !config.filmGrain })}
                  className={`px-3 py-2 text-xs font-medium rounded-lg border text-center transition-colors ${
                    config.filmGrain
                      ? 'bg-neutral-800 border-cyan-400 text-cyan-300'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  Film Grain
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 4: AUDIO FX ================= */}
        {activeTab === 'audio' && (
          <div className="flex flex-col gap-4">
            {/* Master Sound Switch */}
            <div className="flex items-center justify-between p-3 bg-neutral-950 border border-neutral-800 rounded-xl">
              <div className="flex flex-col">
                <span className="text-xs font-semibold text-neutral-200">
                  {lang === 'id' ? 'Suara Video Bumper' : 'Video Sound FX'}
                </span>
                <span className="text-[11px] text-neutral-400">
                  {lang === 'id'
                    ? 'Gabungkan audio procedural saat diekspor'
                    : 'Embed procedural sound into exported video'}
                </span>
              </div>
              <button
                onClick={() => onUpdateConfig({ soundEnabled: !config.soundEnabled })}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  config.soundEnabled ? 'bg-cyan-500' : 'bg-neutral-800'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    config.soundEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Audio Volume Slider */}
            {config.soundEnabled && (
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span>{lang === 'id' ? 'Volume Suara' : 'Master Volume'}</span>
                  <span className="font-mono text-neutral-300 tabular-nums">
                    {Math.round(config.soundVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0.1}
                  max={1}
                  step={0.05}
                  value={config.soundVolume}
                  onChange={(e) => onUpdateConfig({ soundVolume: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            )}

            {/* Sound Presets List */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-neutral-300">
                {lang === 'id' ? 'Koleksi Efek Suara Prosedural' : 'Procedural Sound Presets'}
              </label>

              <div className="flex flex-col gap-2">
                {AUDIO_THEMES.map((item) => {
                  const isSelected = config.audioTheme === item.id;
                  return (
                    <div
                      key={item.id}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-neutral-800/80 border-cyan-400 shadow-sm'
                          : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <button
                        onClick={() => onUpdateConfig({ audioTheme: item.id })}
                        className="flex flex-col text-left flex-1"
                      >
                        <span
                          className={`text-xs font-semibold ${
                            isSelected ? 'text-cyan-300' : 'text-neutral-200'
                          }`}
                        >
                          {item.name}
                        </span>
                        <span className="text-[11px] text-neutral-400">{item.desc}</span>
                      </button>

                      {item.id !== 'none' && (
                        <button
                          type="button"
                          onClick={() => handleTestSound(item.id)}
                          className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 transition-colors ml-2"
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>Test</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
