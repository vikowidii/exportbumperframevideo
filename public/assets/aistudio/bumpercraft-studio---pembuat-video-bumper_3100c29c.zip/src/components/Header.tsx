import React from 'react';
import { Film, Download, Sparkles, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { BumperConfig } from '../types/bumper';

interface HeaderProps {
  config: BumperConfig;
  onUpdateConfig: (partial: Partial<BumperConfig>) => void;
  onOpenExport: () => void;
  onOpenAIModal: () => void;
  onReset: () => void;
  lang: 'id' | 'en';
  onToggleLang: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  config,
  onUpdateConfig,
  onOpenExport,
  onOpenAIModal,
  onReset,
  lang,
  onToggleLang,
}) => {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-8 px-6 py-3.5 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800/80">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white shadow-sm shadow-cyan-500/20">
          <Film className="w-4 h-4" />
        </div>
        <a href="/" className="text-base font-bold tracking-tight text-white whitespace-nowrap">
          BumperCraft <span className="text-xs font-semibold text-cyan-400 font-mono ml-1">STUDIO</span>
        </a>
      </div>

      {/* Zone 2: Navigation & Quick Actions */}
      <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-neutral-400">
        <button
          onClick={onOpenAIModal}
          className="flex items-center gap-1.5 hover:text-cyan-400 transition-colors whitespace-nowrap"
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>{lang === 'id' ? 'Ide Bumper AI' : 'AI Bumper Ideas'}</span>
        </button>

        <button
          onClick={() => onUpdateConfig({ soundEnabled: !config.soundEnabled })}
          className="flex items-center gap-1.5 hover:text-neutral-200 transition-colors whitespace-nowrap"
        >
          {config.soundEnabled ? (
            <>
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'id' ? 'Audio Aktif' : 'Audio On'}</span>
            </>
          ) : (
            <>
              <VolumeX className="w-3.5 h-3.5 text-neutral-500" />
              <span>{lang === 'id' ? 'Audio Senyap' : 'Muted'}</span>
            </>
          )}
        </button>

        <button
          onClick={onReset}
          className="flex items-center gap-1 hover:text-neutral-200 transition-colors whitespace-nowrap"
          title={lang === 'id' ? 'Kembalikan ke awal' : 'Reset to default'}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{lang === 'id' ? 'Reset' : 'Reset'}</span>
        </button>

        <button
          onClick={onToggleLang}
          className="px-2 py-1 rounded border border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700 transition-colors font-mono"
        >
          {lang === 'id' ? 'ID 🇮🇩' : 'EN 🇬🇧'}
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenExport}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-neutral-950 bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-cyan-200 rounded-lg shadow-sm shadow-cyan-500/25 transition-all whitespace-nowrap active:scale-[0.98]"
        >
          <Download className="w-3.5 h-3.5 text-neutral-950" />
          <span>{lang === 'id' ? 'Ekspor Video' : 'Export Video'}</span>
        </button>
      </div>
    </header>
  );
};
