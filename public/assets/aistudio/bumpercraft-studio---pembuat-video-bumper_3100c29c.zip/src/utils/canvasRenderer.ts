import { BumperConfig } from '../types/bumper';

// Particle memory cache for deterministic particle animation
interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  seed: number;
}

const particlePool: Record<string, Particle[]> = {};

function getParticles(theme: string, count: number): Particle[] {
  const key = `${theme}_${count}`;
  if (!particlePool[key] || particlePool[key].length !== count) {
    const list: Particle[] = [];
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const radius = 0.1 + Math.random() * 0.9;
      list.push({
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        z: Math.random(),
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: 1 + Math.random() * 3.5,
        color: '#FFFFFF',
        seed: Math.random(),
      });
    }
    particlePool[key] = list;
  }
  return particlePool[key];
}

// Logo image cache
const imageCache = new Map<string, HTMLImageElement>();

export function getCachedImage(url?: string): HTMLImageElement | null {
  if (!url) return null;
  if (imageCache.has(url)) {
    const img = imageCache.get(url)!;
    return img.complete ? img : null;
  }
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.src = url;
  imageCache.set(url, img);
  return null;
}

// Pre-load the official sliced HD assets immediately
if (typeof window !== 'undefined') {
  getCachedImage('/assets/aistudio/kso_nke_hd.png');
  getCachedImage('/assets/aistudio/kso_jaya_hd.png');
  getCachedImage('/assets/aistudio/kso_wiswa_hd.png');
  getCachedImage('/assets/aistudio/kso_full_hd.png');
  getCachedImage('/assets/aistudio/LOGO_KSO_HD_vektor_edcea276.png');
}

// Smooth easing helpers
function easeOutCubic(x: number): number {
  const t = Math.max(0, Math.min(1, x));
  return 1 - Math.pow(1 - t, 3);
}

function easeOutExpo(x: number): number {
  const t = Math.max(0, Math.min(1, x));
  return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
}

function easeOutBack(x: number): number {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  const t = Math.max(0, Math.min(1, x)) - 1;
  return 1 + c3 * Math.pow(t, 3) + c1 * Math.pow(t, 2);
}

function clamp(val: number, min: number = 0, max: number = 1): number {
  return Math.max(min, Math.min(max, val));
}

/**
 * Main Bumper Canvas Entry Point
 * Exclusively focused on Corporate & Cinematic per user directive
 */
export function renderBumperFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  config: BumperConfig,
  time: number
) {
  const dur = Math.max(1, config.duration);
  const p = clamp(time / dur);
  const speed = config.motionSpeed || 1;

  ctx.save();
  ctx.fillStyle = config.backgroundColor || '#08101E';
  ctx.fillRect(0, 0, width, height);

  if (config.theme === 'kso_cinematic') {
    renderKsoCinematicTheme(ctx, width, height, config, time, p, speed);
  } else {
    renderKsoCorporateTheme(ctx, width, height, config, time, p, speed);
  }

  // Post FX: Film Grain
  if (config.filmGrain) {
    applyFilmGrain(ctx, width, height, time);
  }

  // Post FX: Vignette
  if (config.vignette) {
    applyVignette(ctx, width, height);
  }

  // Post FX: Letterbox Cinematic Bars
  if (config.letterbox && config.aspectRatio === '16:9') {
    const barHeight = height * 0.1;
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, barHeight);
    ctx.fillRect(0, height - barHeight, width, barHeight);
  }

  ctx.restore();
}

/**
 * ==============================================================================
 * TEMA 1: KSO CORPORATE ELEGAN & MODERN
 * Background Deep Navy (#08101E), Aksen Platinum & Sapphire, Grid Koordinat Presisi
 * Transisi: Logo muncul satu per satu di tengah, lalu geser ke kiri sebelum teks muncul
 * ==============================================================================
 */
function renderKsoCorporateTheme(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number,
  p: number,
  speed: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const scale = Math.min(w, h) / 1000;

  // 1. Prestigious Corporate Deep Navy Background with subtle sapphire radial gradient
  ctx.fillStyle = '#08101E';
  ctx.fillRect(0, 0, w, h);

  const radGrad = ctx.createRadialGradient(cx, cy * 0.95, 20, cx, cy, Math.max(w, h) * 0.65);
  radGrad.addColorStop(0, 'rgba(16, 32, 60, 0.9)');
  radGrad.addColorStop(0.5, 'rgba(10, 18, 34, 0.95)');
  radGrad.addColorStop(1, '#060B14');
  ctx.fillStyle = radGrad;
  ctx.fillRect(0, 0, w, h);

  // 2. Micro technical coordinate grid (subtle 2% opacity)
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.025)';
  ctx.lineWidth = 1 * scale;
  const step = 55 * scale;
  for (let x = 0; x < w; x += step) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y < h; y += step) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
  ctx.restore();

  // 3. Subtle architectural horizon baseline
  const baselineY = h * 0.78;
  ctx.strokeStyle = 'rgba(223, 155, 53, 0.18)';
  ctx.lineWidth = 1 * scale;
  ctx.beginPath();
  ctx.moveTo(cx - 360 * scale, baselineY);
  ctx.lineTo(cx + 360 * scale, baselineY);
  ctx.stroke();

  // 4. Master Sequential Motion Presentation (Corporate Palette)
  renderMasterKsoPresentation(
    ctx,
    w,
    h,
    cfg,
    t,
    speed,
    scale,
    {
      primaryTitleColor: '#FFFFFF',
      titleGradTop: '#FFFFFF',
      titleGradMid: '#E2E8F0',
      titleGradBot: '#94A3B8',
      dividerColor: 'rgba(223, 155, 53, 0.65)',
      flareColor: '#38BDF8',
      glowColor: 'rgba(56, 189, 248, 0.25)',
      isCinematicGold: false,
    }
  );
}

/**
 * ==============================================================================
 * TEMA 2: KSO CINEMATIC GOLD & MEGA INFRASTRUKTUR
 * Background Deep Cinematic Charcoal/Black, Backlight Emas 3D, Anamorphic Lens Flare
 * Transisi: Logo muncul satu per satu di tengah, lalu geser ke kiri sebelum teks muncul
 * ==============================================================================
 */
function renderKsoCinematicTheme(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number,
  p: number,
  speed: number
) {
  const cx = w / 2;
  const cy = h / 2;
  const scale = Math.min(w, h) / 1000;

  // 1. Deep Cinematic Obsidian Black with Warm Gold Backlight
  ctx.fillStyle = '#05070D';
  ctx.fillRect(0, 0, w, h);

  const radGrad = ctx.createRadialGradient(cx, cy * 0.9, 15, cx, cy, Math.max(w, h) * 0.7);
  radGrad.addColorStop(0, 'rgba(212, 175, 55, 0.20)'); // Golden center ambient
  radGrad.addColorStop(0.35, 'rgba(20, 45, 85, 0.12)'); // Deep sapphire atmospheric haze
  radGrad.addColorStop(0.75, 'rgba(7, 9, 16, 0.85)');
  radGrad.addColorStop(1, '#040509');
  ctx.fillStyle = radGrad;
  ctx.fillRect(0, 0, w, h);

  // 2. Floating golden embers
  const particles = getParticles('cinematic_kso', Math.min(cfg.particleCount || 40, 80));
  particles.forEach((pt) => {
    const py = ((pt.y + 0.5 - t * 0.06 * (0.6 + pt.seed * 0.4)) % 1 + 1) % 1;
    const px = ((pt.x + 0.5 + Math.sin(t * 0.5 + pt.seed * 8) * 0.04) % 1 + 1) % 1;
    const alpha = (0.2 + Math.sin(t * 2.2 + pt.seed * 15) * 0.2) * (1 - Math.abs(py - 0.5) * 1.6);
    if (alpha > 0) {
      ctx.fillStyle = pt.seed > 0.4 ? hexToRgba('#D4AF37', alpha) : hexToRgba('#F59E0B', alpha * 0.7);
      ctx.beginPath();
      ctx.arc(px * w, py * h, pt.size * scale * (0.7 + pt.seed * 0.5), 0, Math.PI * 2);
      ctx.fill();
    }
  });

  // 3. Master Sequential Motion Presentation (Cinematic Gold Palette)
  renderMasterKsoPresentation(
    ctx,
    w,
    h,
    cfg,
    t,
    speed,
    scale,
    {
      primaryTitleColor: '#D4AF37',
      titleGradTop: '#FFF9D2',
      titleGradMid: '#D4AF37',
      titleGradBot: '#8C6718',
      dividerColor: 'rgba(212, 175, 55, 0.85)',
      flareColor: '#D4AF37',
      glowColor: 'rgba(212, 175, 55, 0.35)',
      isCinematicGold: true,
    }
  );
}

/**
 * ==============================================================================
 * MASTER MOTION CHOREOGRAPHY:
 * Sesuai Permintaan Spesifik Pengguna:
 * 1. "logo munculnya satu satu di tengah" (NKE -> Jaya -> Wiswa berurutan)
 * 2. "logo ditengah dulu baru geser ke kiri gitu" (transisi geser mulus)
 * 3. "baru tulisannya" (teks judul NUSA JAYA WISWAKHARMAN, KSO muncul setelahnya)
 * ==============================================================================
 */
interface StyleThemePalette {
  primaryTitleColor: string;
  titleGradTop: string;
  titleGradMid: string;
  titleGradBot: string;
  dividerColor: string;
  flareColor: string;
  glowColor: string;
  isCinematicGold: boolean;
}

function renderMasterKsoPresentation(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cfg: BumperConfig,
  t: number,
  speed: number,
  scale: number,
  palette: StyleThemePalette
) {
  const cx = w / 2;
  const cy = h / 2;
  const dur = Math.max(1, cfg.duration);
  const tAdj = t * speed;

  // Gentle camera breathing push-in (1.0 -> 1.025)
  const cameraZoom = 1.0 + 0.025 * clamp(t / dur);

  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(cameraZoom, cameraZoom);

  // --------------------------------------------------------------------------
  // LOGO GEOMETRY CONSTANTS
  // Calibrated dimensions from official HD vector asset
  // --------------------------------------------------------------------------
  const targetH = 50 * scale; // uniform optical height
  const wNKE = targetH * (1800 / 362); // ~248px
  const wJaya = targetH * (608 / 608); // 50px
  const wWiswa = targetH * (630 / 618); // ~51px
  const gap = 28 * scale;

  const totalLogosW = wNKE + gap + wJaya + gap + wWiswa; // ~405px
  const startX = -totalLogosW / 2;

  // Center positions of each logo relative to the logo cluster
  const xNKE = startX + wNKE / 2;
  const xDiv1 = startX + wNKE + gap / 2;
  const xJaya = startX + wNKE + gap + wJaya / 2;
  const xDiv2 = startX + wNKE + gap + wJaya + gap / 2;
  const xWiswa = startX + wNKE + gap + wJaya + gap + wWiswa / 2;

  // --------------------------------------------------------------------------
  // SEQUENTIAL ONE-BY-ONE ENTRANCE TIMELINE
  // --------------------------------------------------------------------------
  // 1. Logo 1 (NKE): emerges at 0.10s -> 0.70s
  const pLogo1 = clamp((tAdj - 0.10) / 0.60);
  const scaleLogo1 = 0.85 + 0.15 * easeOutBack(pLogo1);
  const alphaLogo1 = clamp(pLogo1 * 1.5);

  // Divider 1: expands at 0.65s -> 0.90s
  const pDiv1 = clamp((tAdj - 0.65) / 0.25);

  // 2. Logo 2 (Jaya Konstruksi): emerges at 0.75s -> 1.35s
  const pLogo2 = clamp((tAdj - 0.75) / 0.60);
  const scaleLogo2 = 0.82 + 0.18 * easeOutBack(pLogo2);
  const alphaLogo2 = clamp(pLogo2 * 1.5);

  // Divider 2: expands at 1.25s -> 1.50s
  const pDiv2 = clamp((tAdj - 1.25) / 0.25);

  // 3. Logo 3 (Wiswakharman): emerges at 1.35s -> 1.95s
  const pLogo3 = clamp((tAdj - 1.35) / 0.60);
  const scaleLogo3 = 0.82 + 0.18 * easeOutBack(pLogo3);
  const alphaLogo3 = clamp(pLogo3 * 1.5);

  // --------------------------------------------------------------------------
  // SMOOTH SLIDE TO THE LEFT TRANSITION: "logo ditengah dulu baru geser ke kiri"
  // Pauses in center until 2.15s, then slides smoothly from 2.15s to 3.00s
  // --------------------------------------------------------------------------
  const pSlide = clamp((tAdj - 2.15) / 0.85);
  const easeSlide = easeOutCubic(pSlide);

  // Layout mode:
  // In widescreen 16:9 / 1:1, slide left and reveal text on right (as requested!)
  // In portrait 9:16, slide up and reveal text below
  const isSlideLeft = (cfg.transitionStyle || 'slide_left') === 'slide_left' && cfg.aspectRatio !== '9:16';

  let clusterX = 0;
  let clusterY = 0;

  if (isSlideLeft) {
    // Shifts from center (X=0) to left anchor (-220px)
    const targetLeftX = -Math.min(w * 0.24, 230 * scale);
    clusterX = targetLeftX * easeSlide;
    clusterY = 0;
  } else {
    // Vertical slide up
    const targetUpY = -70 * scale;
    clusterX = 0;
    clusterY = targetUpY * easeSlide;
  }

  // --------------------------------------------------------------------------
  // ANAMORPHIC HORIZONTAL FLARE SWEEP (at 1.9s - 2.6s when logos unite in center)
  // --------------------------------------------------------------------------
  if (tAdj > 1.8 && tAdj < 2.9) {
    const flareP = clamp((tAdj - 1.8) / 1.1);
    const flareX = (flareP * 2.2 - 1.1) * (w * 0.45);
    const flareAlpha = Math.sin(flareP * Math.PI) * 0.75;

    ctx.save();
    ctx.translate(clusterX + flareX, clusterY);
    const beamGrad = ctx.createLinearGradient(-w * 0.4, 0, w * 0.4, 0);
    beamGrad.addColorStop(0, 'rgba(255,255,255,0)');
    beamGrad.addColorStop(0.35, hexToRgba(palette.flareColor, flareAlpha * 0.3));
    beamGrad.addColorStop(0.5, `rgba(255,255,255,${flareAlpha * 0.9})`);
    beamGrad.addColorStop(0.65, hexToRgba(palette.flareColor, flareAlpha * 0.3));
    beamGrad.addColorStop(1, 'rgba(255,255,255,0)');

    ctx.fillStyle = beamGrad;
    ctx.fillRect(-w * 0.4, -3 * scale, w * 0.8, 6 * scale);

    const starGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, 60 * scale);
    starGrad.addColorStop(0, `rgba(255,255,255,${flareAlpha * 0.95})`);
    starGrad.addColorStop(0.4, hexToRgba(palette.flareColor, flareAlpha * 0.4));
    starGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = starGrad;
    ctx.beginPath();
    ctx.arc(0, 0, 60 * scale, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // --------------------------------------------------------------------------
  // DRAW THE 3 LOGOS WITH INDIVIDUAL SEQUENTIAL TIMING & OFFSCREEN HD CACHE
  // --------------------------------------------------------------------------
  ctx.save();
  ctx.translate(clusterX, clusterY);

  // Logo 1: Nusa Konstruksi Enjiniring
  if (alphaLogo1 > 0) {
    ctx.save();
    ctx.translate(xNKE, 0);
    ctx.scale(scaleLogo1, scaleLogo1);
    ctx.globalAlpha = alphaLogo1;
    drawLogo1NKE(ctx, 0, 0, targetH, wNKE);
    ctx.restore();
  }

  // Hairline Divider 1
  if (pDiv1 > 0) {
    const divH = targetH * 0.46 * easeOutCubic(pDiv1);
    ctx.save();
    ctx.strokeStyle = palette.dividerColor;
    ctx.lineWidth = 1.2 * scale;
    ctx.globalAlpha = clamp(pDiv1 * 1.5);
    ctx.beginPath();
    ctx.moveTo(xDiv1, -divH);
    ctx.lineTo(xDiv1, divH);
    ctx.stroke();
    ctx.restore();
  }

  // Logo 2: Jaya Konstruksi
  if (alphaLogo2 > 0) {
    ctx.save();
    ctx.translate(xJaya, 0);
    ctx.scale(scaleLogo2, scaleLogo2);
    ctx.globalAlpha = alphaLogo2;
    drawLogo2Jaya(ctx, 0, 0, targetH, wJaya);
    ctx.restore();
  }

  // Hairline Divider 2
  if (pDiv2 > 0) {
    const divH = targetH * 0.46 * easeOutCubic(pDiv2);
    ctx.save();
    ctx.strokeStyle = palette.dividerColor;
    ctx.lineWidth = 1.2 * scale;
    ctx.globalAlpha = clamp(pDiv2 * 1.5);
    ctx.beginPath();
    ctx.moveTo(xDiv2, -divH);
    ctx.lineTo(xDiv2, divH);
    ctx.stroke();
    ctx.restore();
  }

  // Logo 3: Wiswakharman
  if (alphaLogo3 > 0) {
    ctx.save();
    ctx.translate(xWiswa, 0);
    ctx.scale(scaleLogo3, scaleLogo3);
    ctx.globalAlpha = alphaLogo3;
    drawLogo3Wiswa(ctx, 0, 0, targetH, wWiswa);
    ctx.restore();
  }

  ctx.restore(); // end logo cluster translate

  // --------------------------------------------------------------------------
  // TEXT REVEAL: "baru tulisannya"
  // Appears after logos slide to the left (starting at 2.4s, fully gleaming by 3.2s)
  // --------------------------------------------------------------------------
  const pText = clamp((tAdj - 2.35) / 0.85);
  const easeText = easeOutCubic(pText);
  const alphaText = clamp(pText * 1.3);

  if (alphaText > 0) {
    ctx.save();
    ctx.globalAlpha = alphaText;

    if (isSlideLeft) {
      // ----------------------------------------------------------------------
      // WIDESCREEN SIDE-BY-SIDE PRESENTATION
      // Logos on the left, elegant architectural divider in center, title on right
      // ----------------------------------------------------------------------
      const logoRightEdge = clusterX + totalLogosW / 2;
      const midDividerX = logoRightEdge + 30 * scale;

      // Vertical Gold/Platinum Master Divider Beam
      const beamHeight = 72 * scale * easeText;
      ctx.save();
      const divBeamGrad = ctx.createLinearGradient(0, -beamHeight, 0, beamHeight);
      divBeamGrad.addColorStop(0, 'rgba(255,255,255,0)');
      divBeamGrad.addColorStop(0.5, palette.dividerColor);
      divBeamGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = divBeamGrad;
      ctx.lineWidth = 2 * scale;
      ctx.beginPath();
      ctx.moveTo(midDividerX, -beamHeight);
      ctx.lineTo(midDividerX, beamHeight);
      ctx.stroke();
      ctx.restore();

      // Title Positioning (slides in from right by +35px -> 0)
      const textSlideOffset = (1 - easeText) * 35 * scale;
      const textStartX = midDividerX + 26 * scale + textSlideOffset;

      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';

      // Line 1: NUSA JAYA WISWAKHARMAN
      const fontS1 = 34 * scale * cfg.fontSize;
      ctx.font = `800 ${fontS1}px "${cfg.fontFamily}", sans-serif`;

      const titleY1 = -13 * scale;
      // 3D Drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText('NUSA JAYA WISWAKHARMAN', textStartX, titleY1 + 3 * scale);

      // Metallic Gradient Fill
      const gradTitle = ctx.createLinearGradient(
        textStartX,
        titleY1 - fontS1 * 0.5,
        textStartX,
        titleY1 + fontS1 * 0.5
      );
      gradTitle.addColorStop(0, palette.titleGradTop);
      gradTitle.addColorStop(0.45, palette.titleGradMid);
      gradTitle.addColorStop(1, palette.titleGradBot);
      ctx.fillStyle = gradTitle;
      ctx.fillText('NUSA JAYA WISWAKHARMAN', textStartX, titleY1);

      // Line 2: KERJA SAMA OPERASI (KSO) or KSO
      const subText = (cfg.subtitle && cfg.subtitle.trim()) || 'KERJA SAMA OPERASI (KSO)';
      const fontS2 = 13.5 * scale;
      ctx.font = `700 ${fontS2}px "Plus Jakarta Sans", sans-serif`;

      const titleY2 = titleY1 + 32 * scale;
      ctx.fillStyle = hexToRgba(palette.primaryTitleColor, 0.95);
      drawLetterSpacedTextLeft(ctx, subText.toUpperCase(), textStartX, titleY2, 4 * scale);

      // Specular glint sweep across title text (3.0s to 4.4s)
      if (tAdj > 2.8) {
        const shineP = ((tAdj - 2.8) * 0.7) % 2.8;
        if (shineP < 1.0) {
          ctx.save();
          ctx.globalCompositeOperation = 'source-atop';
          const shineX = textStartX + shineP * 480 * scale;
          const sGrad = ctx.createLinearGradient(shineX - 50 * scale, 0, shineX + 50 * scale, 0);
          sGrad.addColorStop(0, 'rgba(255,255,255,0)');
          sGrad.addColorStop(0.5, 'rgba(255,255,255,0.85)');
          sGrad.addColorStop(1, 'rgba(255,255,255,0)');
          ctx.fillStyle = sGrad;
          ctx.fillRect(textStartX - 20, -50 * scale, 600 * scale, 100 * scale);
          ctx.restore();
        }
      }
    } else {
      // ----------------------------------------------------------------------
      // VERTICAL CENTERED PRESENTATION (Fallback for 9:16 mobile)
      // Logos on top, title centered below
      // ----------------------------------------------------------------------
      const titleY = 46 * scale;
      const fontSize = 38 * scale * cfg.fontSize;
      ctx.font = `800 ${fontSize}px "${cfg.fontFamily}", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // Drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText(cfg.title || 'NUSA JAYA WISWAKHARMAN, KSO', 0, titleY + 3 * scale);

      // Metallic Gradient Fill
      const gradTitle = ctx.createLinearGradient(0, titleY - fontSize * 0.5, 0, titleY + fontSize * 0.5);
      gradTitle.addColorStop(0, palette.titleGradTop);
      gradTitle.addColorStop(0.45, palette.titleGradMid);
      gradTitle.addColorStop(1, palette.titleGradBot);
      ctx.fillStyle = gradTitle;
      ctx.fillText(cfg.title || 'NUSA JAYA WISWAKHARMAN, KSO', 0, titleY);

      if (cfg.subtitle && cfg.subtitle.trim()) {
        const subY = titleY + 38 * scale;
        ctx.font = `700 ${12 * scale}px "Plus Jakarta Sans", sans-serif`;
        ctx.fillStyle = hexToRgba(palette.primaryTitleColor, 0.85);
        drawLetterSpacedText(ctx, cfg.subtitle.trim().toUpperCase(), 0, subY, 5 * scale);
      }
    }

    ctx.restore();
  }

  ctx.restore(); // end master translate
}

/**
 * ==============================================================================
 * LOGO DRAWING HELPERS:
 * Prioritizes the sliced Ultra-HD Vector assets created from the user's uploaded
 * file LOGO_KSO_HD_vektor_edcea276.png, falling back seamlessly to procedural vectors.
 * ==============================================================================
 */

// 1. PT Nusa Konstruksi Enjiniring
function drawLogo1NKE(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgNKE = getCachedImage('/assets/aistudio/kso_nke_hd.png');
  if (imgNKE) {
    ctx.drawImage(imgNKE, x - w / 2, y - h / 2, w, h);
    return;
  }

  // Fallback Procedural Vector
  ctx.save();
  ctx.translate(x, y);
  const startX = -w / 2;
  const topY = -h / 2;
  const botY = h / 2;

  // Green Triangle (Base 1.33x Height)
  const greenW = 1.33 * h;
  ctx.fillStyle = '#12A727';
  ctx.beginPath();
  ctx.moveTo(startX, botY);
  ctx.lineTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.closePath();
  ctx.fill();

  // Blue Triangle
  const rectW = 1.33 * h;
  const emblemEnd = startX + greenW + rectW;
  ctx.fillStyle = '#144DFF';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(startX + greenW, botY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  // Orange Triangle
  ctx.fillStyle = '#FFB51C';
  ctx.beginPath();
  ctx.moveTo(startX + greenW, topY);
  ctx.lineTo(emblemEnd, topY);
  ctx.lineTo(emblemEnd, botY);
  ctx.closePath();
  ctx.fill();

  // White Typography
  const textX = emblemEnd + 0.22 * h;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#FFFFFF';

  ctx.font = `800 ${h * 0.28}px "Plus Jakarta Sans", sans-serif`;
  drawLetterSpacedTextLeft(ctx, 'N  U  S  A', textX, -h * 0.26, 3.0);
  ctx.font = `700 ${h * 0.22}px "Plus Jakarta Sans", sans-serif`;
  drawLetterSpacedTextLeft(ctx, 'KONSTRUKSI', textX, 0.02 * h, 1.4);
  drawLetterSpacedTextLeft(ctx, 'ENJINIRING', textX, 0.30 * h, 1.6);
  ctx.restore();
}

// 2. PT Jaya Konstruksi Manggala Pratama
function drawLogo2Jaya(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgJaya = getCachedImage('/assets/aistudio/kso_jaya_hd.png');
  if (imgJaya) {
    ctx.drawImage(imgJaya, x - w / 2, y - h / 2, w, h);
    return;
  }

  // Fallback Procedural Vector
  ctx.save();
  ctx.translate(x, y);
  const R = h / 2;
  const strokeW = Math.max(2.6, h * 0.065);

  ctx.strokeStyle = '#FFAE19';
  ctx.lineWidth = strokeW;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.beginPath();
  ctx.arc(0, 0, R - strokeW / 2, 0, Math.PI * 2);
  ctx.stroke();

  // Tallest Tower
  ctx.beginPath();
  ctx.moveTo(0.08 * R, 0.65 * R);
  ctx.lineTo(0.08 * R, -0.72 * R);
  ctx.lineTo(0.22 * R, -0.62 * R);
  ctx.lineTo(0.22 * R, -0.15 * R);
  ctx.lineTo(0.38 * R, 0);
  ctx.lineTo(0.38 * R, 0.40 * R);
  ctx.lineTo(0.55 * R, 0.65 * R);
  ctx.stroke();

  // Left Wing Tower
  ctx.beginPath();
  ctx.moveTo(-0.55 * R, 0.65 * R);
  ctx.lineTo(-0.38 * R, 0.40 * R);
  ctx.lineTo(-0.38 * R, -0.15 * R);
  ctx.lineTo(-0.20 * R, -0.28 * R);
  ctx.lineTo(-0.20 * R, 0.35 * R);
  ctx.stroke();

  // Foundation
  ctx.beginPath();
  ctx.moveTo(-0.55 * R, 0.65 * R);
  ctx.lineTo(0.55 * R, 0.65 * R);
  ctx.stroke();

  ctx.restore();
}

// 3. PT Wiswakharman
function drawLogo3Wiswa(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  w: number
) {
  const imgWiswa = getCachedImage('/assets/aistudio/kso_wiswa_hd.png');
  if (imgWiswa) {
    ctx.drawImage(imgWiswa, x - w / 2, y - h / 2, w, h);
    return;
  }

  // Fallback Procedural Vector
  ctx.save();
  ctx.translate(x, y);
  const H = h;
  const W = w;
  const w2 = W / 2;
  const h2 = H / 2;
  const redColor = '#E02030';

  // Rhombus frame
  ctx.strokeStyle = redColor;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(0, -h2);
  ctx.lineTo(w2, 0);
  ctx.lineTo(0, h2);
  ctx.lineTo(-w2, 0);
  ctx.closePath();
  ctx.stroke();

  // Center axes
  ctx.lineWidth = 1.0;
  ctx.beginPath();
  ctx.moveTo(0, -h2);
  ctx.lineTo(0, h2);
  ctx.moveTo(-w2, 0);
  ctx.lineTo(w2, 0);
  ctx.stroke();

  // Upper rafters
  ctx.beginPath();
  ctx.moveTo(0, -h2 * 0.67);
  ctx.lineTo(-w2 * 0.33, -h2 * 0.34);
  ctx.moveTo(0, -h2 * 0.67);
  ctx.lineTo(w2 * 0.33, -h2 * 0.34);
  ctx.moveTo(0, -h2 * 0.34);
  ctx.lineTo(-w2 * 0.67, 0);
  ctx.moveTo(0, -h2 * 0.34);
  ctx.lineTo(w2 * 0.67, 0);
  ctx.stroke();

  // Solid Red Wings
  ctx.fillStyle = redColor;
  ctx.beginPath();
  ctx.moveTo(-w2 * 0.66, 0);
  ctx.lineTo(-w2 * 0.05, 0);
  ctx.lineTo(-w2 * 0.35, h2 * 0.28);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(w2 * 0.05, 0);
  ctx.lineTo(w2 * 0.66, 0);
  ctx.lineTo(w2 * 0.35, h2 * 0.28);
  ctx.closePath();
  ctx.fill();

  // Bottom Anchor Upward Triangle
  ctx.beginPath();
  ctx.moveTo(0, h2 * 0.42);
  ctx.lineTo(-w2 * 0.28, h2 * 0.65);
  ctx.lineTo(w2 * 0.28, h2 * 0.65);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}

/**
 * Letter-spaced typography helper (centered)
 */
function drawLetterSpacedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  spacing: number
) {
  const chars = text.split('');
  const widths = chars.map((c) => ctx.measureText(c).width);
  const totalWidth = widths.reduce((a, b) => a + b, 0) + (chars.length - 1) * spacing;
  let curX = x - totalWidth / 2;

  chars.forEach((char, idx) => {
    ctx.fillText(char, curX + widths[idx] / 2, y);
    curX += widths[idx] + spacing;
  });
}

/**
 * Letter-spaced typography helper (left-aligned)
 */
function drawLetterSpacedTextLeft(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  spacing: number
) {
  let curX = x;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    ctx.fillText(ch, curX, y);
    curX += ctx.measureText(ch).width + spacing;
  }
}

function applyFilmGrain(ctx: CanvasRenderingContext2D, w: number, h: number, time: number) {
  const grainCanvas = document.createElement('canvas');
  grainCanvas.width = 120;
  grainCanvas.height = 120;
  const gctx = grainCanvas.getContext('2d');
  if (!gctx) return;

  const imgData = gctx.createImageData(120, 120);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const val = Math.floor(Math.random() * 255);
    data[i] = val;
    data[i + 1] = val;
    data[i + 2] = val;
    data[i + 3] = 16;
  }
  gctx.putImageData(imgData, 0, 0);

  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const pattern = ctx.createPattern(grainCanvas, 'repeat');
  if (pattern) {
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

function applyVignette(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.save();
  const radius = Math.max(w, h) * 0.75;
  const vig = ctx.createRadialGradient(w / 2, h / 2, radius * 0.35, w / 2, h / 2, radius);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(0,0,0,0.65)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

function hexToRgba(hex: string, alpha: number = 1): string {
  if (!hex || !hex.startsWith('#')) return `rgba(255,255,255,${alpha})`;
  let c = hex.substring(1);
  if (c.length === 3) c = c.split('').map((x) => x + x).join('');
  const num = parseInt(c, 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}
