import { AudioThemeId } from '../types/bumper';

class BumperAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getContext(): AudioContext | null {
    this.initContext();
    return this.ctx;
  }

  /**
   * Play live procedural sound for preview
   */
  public play(theme: AudioThemeId, volume: number = 0.8, offsetSeconds: number = 0) {
    if (theme === 'none' || volume <= 0) return;
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    this.masterGain.gain.setValueAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime);
    this.synthesizeTheme(this.ctx, this.masterGain, theme, this.ctx.currentTime - offsetSeconds);
  }

  /**
   * Synthesize audio for offline video recording into a destination node
   */
  public synthesizeToDestination(
    destinationCtx: AudioContext | OfflineAudioContext,
    destinationNode: AudioNode,
    theme: AudioThemeId,
    volume: number = 0.8,
    startTime: number = 0
  ) {
    if (theme === 'none' || volume <= 0) return;
    const gainNode = destinationCtx.createGain();
    gainNode.gain.setValueAtTime(volume, startTime);
    gainNode.connect(destinationNode);
    this.synthesizeTheme(destinationCtx, gainNode, theme, startTime);
  }

  private synthesizeTheme(
    ctx: BaseAudioContext,
    target: AudioNode,
    theme: AudioThemeId,
    startTime: number
  ) {
    const t0 = Math.max(ctx.currentTime, startTime);

    switch (theme) {
      case 'cinematic':
        this.renderCinematic(ctx, target, t0);
        break;
      case 'cyber':
        this.renderCyberGlitch(ctx, target, t0);
        break;
      case 'retro':
        this.renderRetroSynthwave(ctx, target, t0);
        break;
      case 'cosmic':
        this.renderCosmicSupernova(ctx, target, t0);
        break;
      case 'minimal':
        this.renderMinimalStudio(ctx, target, t0);
        break;
      case 'gaming':
        this.renderGamingBassDrop(ctx, target, t0);
        break;
      default:
        break;
    }
  }

  /**
   * 1. CINEMATIC:
   * Atmospheric wind whoosh riser -> Massive sub boom (65Hz -> 28Hz) -> Crystalline shimmer
   */
  private renderCinematic(ctx: BaseAudioContext, target: AudioNode, t0: number) {
    // Whoosh Riser (Filtered Pink/White Noise)
    const bufferSize = ctx.sampleRate * 2.0;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(150, t0);
    filter.frequency.exponentialRampToValueAtTime(1800, t0 + 1.2);
    filter.Q.setValueAtTime(3, t0);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.001, t0);
    noiseGain.gain.exponentialRampToValueAtTime(0.35, t0 + 1.15);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 1.4);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(target);
    noise.start(t0);
    noise.stop(t0 + 1.5);

    // Impact Sub Boom at 1.2s
    const hitTime = t0 + 1.2;
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(110, hitTime);
    osc.frequency.exponentialRampToValueAtTime(32, hitTime + 1.2);

    oscGain.gain.setValueAtTime(0.9, hitTime);
    oscGain.gain.exponentialRampToValueAtTime(0.001, hitTime + 2.5);

    osc.connect(oscGain);
    oscGain.connect(target);
    osc.start(hitTime);
    osc.stop(hitTime + 2.6);

    // Warm Brass Drone (harmonic reinforcement)
    const brass = ctx.createOscillator();
    const brassFilter = ctx.createBiquadFilter();
    const brassGain = ctx.createGain();

    brass.type = 'sawtooth';
    brass.frequency.setValueAtTime(65.41, hitTime); // C2

    brassFilter.type = 'lowpass';
    brassFilter.frequency.setValueAtTime(500, hitTime);
    brassFilter.frequency.exponentialRampToValueAtTime(80, hitTime + 2.0);

    brassGain.gain.setValueAtTime(0.25, hitTime);
    brassGain.gain.exponentialRampToValueAtTime(0.001, hitTime + 2.2);

    brass.connect(brassFilter);
    brassFilter.connect(brassGain);
    brassGain.connect(target);
    brass.start(hitTime);
    brass.stop(hitTime + 2.3);

    // High crystalline shimmer bell (Gold glint at 1.8s)
    [523.25, 659.25, 1046.5].forEach((freq, idx) => {
      const bell = ctx.createOscillator();
      const bellGain = ctx.createGain();
      bell.type = 'sine';
      bell.frequency.setValueAtTime(freq, hitTime + 0.3 + idx * 0.1);

      bellGain.gain.setValueAtTime(0.12, hitTime + 0.3 + idx * 0.1);
      bellGain.gain.exponentialRampToValueAtTime(0.0001, hitTime + 1.8 + idx * 0.1);

      bell.connect(bellGain);
      bellGain.connect(target);
      bell.start(hitTime + 0.3 + idx * 0.1);
      bell.stop(hitTime + 2.0 + idx * 0.1);
    });
  }

  /**
   * 2. CYBERPUNK:
   * Digital stutter blips -> Sci-fi laser sweep -> Glitch bass punch & static burst
   */
  private renderCyberGlitch(ctx: BaseAudioContext, target: AudioNode, t0: number) {
    // Rapid digital blips
    for (let i = 0; i < 5; i++) {
      const blip = ctx.createOscillator();
      const blipGain = ctx.createGain();
      const blipTime = t0 + i * 0.14;

      blip.type = 'square';
      blip.frequency.setValueAtTime(400 + i * 220, blipTime);

      blipGain.gain.setValueAtTime(0.18, blipTime);
      blipGain.gain.exponentialRampToValueAtTime(0.001, blipTime + 0.08);

      blip.connect(blipGain);
      blipGain.connect(target);
      blip.start(blipTime);
      blip.stop(blipTime + 0.09);
    }

    // Laser Pitch Sweep Down at 0.9s
    const sweep = ctx.createOscillator();
    const sweepGain = ctx.createGain();
    sweep.type = 'sawtooth';
    sweep.frequency.setValueAtTime(2400, t0 + 0.8);
    sweep.frequency.exponentialRampToValueAtTime(120, t0 + 1.15);

    sweepGain.gain.setValueAtTime(0.2, t0 + 0.8);
    sweepGain.gain.exponentialRampToValueAtTime(0.001, t0 + 1.2);

    sweep.connect(sweepGain);
    sweepGain.connect(target);
    sweep.start(t0 + 0.8);
    sweep.stop(t0 + 1.25);

    // Glitch Impact Hit at 1.15s
    const hitTime = t0 + 1.15;
    const bass = ctx.createOscillator();
    const bassDistort = ctx.createWaveShaper();
    const bassGain = ctx.createGain();

    // distortion curve
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    for (let i = 0; i < n_samples; ++i) {
      const x = (i * 2) / n_samples - 1;
      curve[i] = Math.tanh(x * 3);
    }
    bassDistort.curve = curve;

    bass.type = 'triangle';
    bass.frequency.setValueAtTime(140, hitTime);
    bass.frequency.exponentialRampToValueAtTime(45, hitTime + 0.8);

    bassGain.gain.setValueAtTime(0.7, hitTime);
    bassGain.gain.exponentialRampToValueAtTime(0.001, hitTime + 1.8);

    bass.connect(bassDistort);
    bassDistort.connect(bassGain);
    bassGain.connect(target);
    bass.start(hitTime);
    bass.stop(hitTime + 1.9);
  }

  /**
   * 3. SYNTHWAVE:
   * 80s analog synth chord (Am7) + gated reverb snare clap + arpeggio sweep
   */
  private renderRetroSynthwave(ctx: BaseAudioContext, target: AudioNode, t0: number) {
    const chordTime = t0 + 0.8;
    // Frequencies: A2 (110Hz), E3 (164.81Hz), A3 (220Hz), C4 (261.63Hz), E4 (329.63Hz)
    const notes = [110, 164.81, 220, 261.63, 329.63];

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, chordTime);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(300, chordTime);
      filter.frequency.exponentialRampToValueAtTime(2200, chordTime + 0.6);
      filter.frequency.exponentialRampToValueAtTime(600, chordTime + 2.5);

      gain.gain.setValueAtTime(0.001, chordTime);
      gain.gain.linearRampToValueAtTime(0.12, chordTime + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.001, chordTime + 2.6);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(target);

      osc.start(chordTime);
      osc.stop(chordTime + 2.7);
    });

    // 80s Snare Hit at 1.0s
    const snareTime = t0 + 1.0;
    const snareNoise = ctx.createBufferSource();
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 0.4, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    snareNoise.buffer = buffer;

    const snareFilter = ctx.createBiquadFilter();
    snareFilter.type = 'highpass';
    snareFilter.frequency.setValueAtTime(800, snareTime);

    const snareGain = ctx.createGain();
    snareGain.gain.setValueAtTime(0.35, snareTime);
    snareGain.gain.exponentialRampToValueAtTime(0.001, snareTime + 0.35);

    snareNoise.connect(snareFilter);
    snareFilter.connect(snareGain);
    snareGain.connect(target);
    snareNoise.start(snareTime);
    snareNoise.stop(snareTime + 0.4);
  }

  /**
   * 4. COSMIC SUPERNOVA:
   * Ethereal rising frequency swell -> Starburst explosion ring chime
   */
  private renderCosmicSupernova(ctx: BaseAudioContext, target: AudioNode, t0: number) {
    // Ethereal swell
    const swell = ctx.createOscillator();
    const swellGain = ctx.createGain();
    swell.type = 'sine';
    swell.frequency.setValueAtTime(130, t0);
    swell.frequency.exponentialRampToValueAtTime(520, t0 + 1.3);

    swellGain.gain.setValueAtTime(0.001, t0);
    swellGain.gain.linearRampToValueAtTime(0.3, t0 + 1.25);
    swellGain.gain.exponentialRampToValueAtTime(0.001, t0 + 1.4);

    swell.connect(swellGain);
    swellGain.connect(target);
    swell.start(t0);
    swell.stop(t0 + 1.45);

    // Supernova Impact at 1.3s
    const hitTime = t0 + 1.3;
    const deepOsc = ctx.createOscillator();
    const deepGain = ctx.createGain();
    deepOsc.type = 'sine';
    deepOsc.frequency.setValueAtTime(80, hitTime);
    deepOsc.frequency.exponentialRampToValueAtTime(25, hitTime + 1.8);

    deepGain.gain.setValueAtTime(0.7, hitTime);
    deepGain.gain.exponentialRampToValueAtTime(0.001, hitTime + 2.4);

    deepOsc.connect(deepGain);
    deepGain.connect(target);
    deepOsc.start(hitTime);
    deepOsc.stop(hitTime + 2.5);

    // Starlight Chimes (pentatonic sparkle)
    [587.33, 659.25, 880, 1174.66, 1318.51].forEach((f, i) => {
      const chime = ctx.createOscillator();
      const chimeGain = ctx.createGain();
      const cTime = hitTime + 0.1 + i * 0.12;

      chime.type = 'sine';
      chime.frequency.setValueAtTime(f, cTime);

      chimeGain.gain.setValueAtTime(0.12, cTime);
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, cTime + 1.2);

      chime.connect(chimeGain);
      chimeGain.connect(target);
      chime.start(cTime);
      chime.stop(cTime + 1.3);
    });
  }

  /**
   * 5. MINIMAL STUDIO:
   * Warm wooden tactile tap -> Studio pop -> Pure harmonic glass chime
   */
  private renderMinimalStudio(ctx: BaseAudioContext, target: AudioNode, t0: number) {
    const popTime = t0 + 0.8;

    // Organic Pop/Tap (rapid pitch envelope)
    const pop = ctx.createOscillator();
    const popGain = ctx.createGain();
    pop.type = 'sine';
    pop.frequency.setValueAtTime(600, popTime);
    pop.frequency.exponentialRampToValueAtTime(110, popTime + 0.05);

    popGain.gain.setValueAtTime(0.6, popTime);
    popGain.gain.exponentialRampToValueAtTime(0.001, popTime + 0.08);

    pop.connect(popGain);
    popGain.connect(target);
    pop.start(popTime);
    pop.stop(popTime + 0.09);

    // Elegant Marimba / Glass Tone at 0.9s
    [440, 660].forEach((freq) => {
      const chime = ctx.createOscillator();
      const chimeGain = ctx.createGain();
      chime.type = 'triangle';
      chime.frequency.setValueAtTime(freq, popTime + 0.05);

      chimeGain.gain.setValueAtTime(0.25, popTime + 0.05);
      chimeGain.gain.exponentialRampToValueAtTime(0.001, popTime + 1.5);

      chime.connect(chimeGain);
      chimeGain.connect(target);
      chime.start(popTime + 0.05);
      chime.stop(popTime + 1.6);
    });
  }

  /**
   * 6. GAMING / ESPORT:
   * Knife slash whoosh -> Massive distorted 808 drop -> High-voltage energy hit
   */
  private renderGamingBassDrop(ctx: BaseAudioContext, target: AudioNode, t0: number) {
    // Sharp blade slash whoosh at 0.5s
    const slash = ctx.createOscillator();
    const slashGain = ctx.createGain();
    slash.type = 'sawtooth';
    slash.frequency.setValueAtTime(1800, t0 + 0.5);
    slash.frequency.exponentialRampToValueAtTime(200, t0 + 0.85);

    slashGain.gain.setValueAtTime(0.2, t0 + 0.5);
    slashGain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.9);

    slash.connect(slashGain);
    slashGain.connect(target);
    slash.start(t0 + 0.5);
    slash.stop(t0 + 0.95);

    // 808 Drop at 0.85s
    const dropTime = t0 + 0.85;
    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(160, dropTime);
    sub.frequency.exponentialRampToValueAtTime(38, dropTime + 0.6);

    subGain.gain.setValueAtTime(0.95, dropTime);
    subGain.gain.exponentialRampToValueAtTime(0.001, dropTime + 2.2);

    sub.connect(subGain);
    subGain.connect(target);
    sub.start(dropTime);
    sub.stop(dropTime + 2.3);

    // Metal Clang / Impact Accent
    const clang = ctx.createOscillator();
    const clangGain = ctx.createGain();
    clang.type = 'square';
    clang.frequency.setValueAtTime(1240, dropTime);
    clangGain.gain.setValueAtTime(0.25, dropTime);
    clangGain.gain.exponentialRampToValueAtTime(0.001, dropTime + 0.25);

    clang.connect(clangGain);
    clangGain.connect(target);
    clang.start(dropTime);
    clang.stop(dropTime + 0.3);
  }
}

export const audioEngine = new BumperAudioEngine();
