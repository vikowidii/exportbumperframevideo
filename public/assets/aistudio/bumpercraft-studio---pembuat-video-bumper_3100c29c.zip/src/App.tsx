import React, { useState } from 'react';
import { Header } from './components/Header';
import { PreviewViewport } from './components/PreviewViewport';
import { ControlsSidebar } from './components/ControlsSidebar';
import { ExportModal } from './components/ExportModal';
import { AIBumperModal } from './components/AIBumperModal';
import { BumperConfig, AIConcept } from './types/bumper';
import { BUMPER_PRESETS } from './data/presets';
import { Sparkles, Film, Download, ShieldCheck, Zap, Info } from 'lucide-react';

const INITIAL_CONFIG: BumperConfig = {
  title: 'NUSA JAYA WISWAKHARMAN, KSO',
  subtitle: '',
  tagline: '',
  theme: 'kso_corporate',
  aspectRatio: '16:9',
  duration: 5.5,
  fps: 60,
  primaryColor: '#FFFFFF',
  secondaryColor: '#DF9B35',
  accentColor: '#38BDF8',
  backgroundColor: '#08101E',
  fontFamily: 'Outfit',
  fontSize: 1.0,
  letterSpacing: 3,
  icon: 'kso',
  customLogoUrl: '/assets/aistudio/LOGO_KSO_HD_vektor_edcea276.png',
  ksoLogoMode: 'hd_vector',
  transitionStyle: 'slide_left',
  showPartnerLabels: false,
  particleCount: 40,
  glitchIntensity: 0,
  motionSpeed: 1.0,
  vignette: true,
  filmGrain: false,
  letterbox: false,
  audioTheme: 'minimal',
  soundEnabled: true,
  soundVolume: 0.8,
};

export default function App() {
  const [config, setConfig] = useState<BumperConfig>(INITIAL_CONFIG);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState<boolean>(false);
  const [lang, setLang] = useState<'id' | 'en'>('id');

  const handleUpdateConfig = (partial: Partial<BumperConfig>) => {
    setConfig((prev) => ({ ...prev, ...partial }));
  };

  const handleReset = () => {
    setConfig(INITIAL_CONFIG);
  };

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'id' ? 'en' : 'id'));
  };

  const handleApplyConcept = (concept: AIConcept) => {
    setConfig((prev) => ({
      ...prev,
      title: concept.title,
      subtitle: concept.slogan,
      theme: concept.themeId,
      primaryColor: concept.primaryColor,
      secondaryColor: concept.secondaryColor,
      fontFamily: concept.fontFamily,
      audioTheme: concept.audioTheme,
    }));
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top Bar adhering to Top Bar Contract */}
      <Header
        config={config}
        onUpdateConfig={handleUpdateConfig}
        onOpenExport={() => setIsExportModalOpen(true)}
        onOpenAIModal={() => setIsAIModalOpen(true)}
        onReset={handleReset}
        lang={lang}
        onToggleLang={handleToggleLang}
      />

      {/* Main Studio Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-8">
        {/* Workspace Title & Quick Context */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-neutral-800/60">
          <div className="flex flex-col gap-1">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              {lang === 'id' ? 'Studio Pembuat Video Bumper' : 'Video Bumper Motion Studio'}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-400">
              {lang === 'id'
                ? 'Rancang animasi intro, bumper brand, dan outro berkualitas sinematik dengan audio sinkron & unduhan MP4/WebM instan.'
                : 'Design cinematic video bumper intros & outros with procedural audio sync and instant WebM/MP4 export.'}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>60 FPS Render</span>
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span>Web Audio Synth</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span>Format 16:9 / 9:16 / 1:1</span>
          </div>
        </div>

        {/* 2-Column Split: Viewport (Left/Center) + Controls (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Interactive Canvas Preview Viewport */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <PreviewViewport
              config={config}
              onUpdateConfig={handleUpdateConfig}
              lang={lang}
            />
          </div>

          {/* Right Column: Studio Controls Sidebar */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <ControlsSidebar
              config={config}
              onUpdateConfig={handleUpdateConfig}
              onOpenAIModal={() => setIsAIModalOpen(true)}
              lang={lang}
            />
          </div>
        </div>

        {/* Informational Guidance Section: How to Use Video Bumpers */}
        <section className="mt-6 p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800/80 flex flex-col gap-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-neutral-200">
            <Info className="w-4 h-4 text-cyan-400" />
            <span>
              {lang === 'id' ? 'Panduan Memasang Video Bumper ke Editor' : 'How to Use Your Bumper in Video Editors'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-neutral-400">
            <div className="p-3.5 bg-neutral-950/60 rounded-xl border border-neutral-800/60 flex flex-col gap-1.5">
              <span className="font-semibold text-neutral-200">
                {lang === 'id' ? '1. Di CapCut & TikTok' : '1. In CapCut & TikTok'}
              </span>
              <p className="leading-relaxed">
                {lang === 'id'
                  ? 'Pilih rasio 9:16 (Reels/Shorts), ekspor video, lalu import sebagai klip pembuka (0.0s - 4.0s) di timeline CapCut sebelum konten utama.'
                  : 'Choose 9:16 ratio, export, and place as the opening clip on your CapCut timeline before your main content.'}
              </p>
            </div>

            <div className="p-3.5 bg-neutral-950/60 rounded-xl border border-neutral-800/60 flex flex-col gap-1.5">
              <span className="font-semibold text-neutral-200">
                {lang === 'id' ? '2. Di Premiere Pro / DaVinci' : '2. In Premiere Pro / DaVinci'}
              </span>
              <p className="leading-relaxed">
                {lang === 'id'
                  ? 'Gunakan 16:9 1080p Full HD. Video sudah menyertakan trek audio sinematik otomatis sehingga Anda tidak perlu mencari sound effect terpisah.'
                  : 'Export at 1080p Full HD. The video file embeds synchronized audio tracks directly without needing third-party sound effects.'}
              </p>
            </div>

            <div className="p-3.5 bg-neutral-950/60 rounded-xl border border-neutral-800/60 flex flex-col gap-1.5">
              <span className="font-semibold text-neutral-200">
                {lang === 'id' ? '3. Poster Frame Thumbnail' : '3. Thumbnail Poster Frame'}
              </span>
              <p className="leading-relaxed">
                {lang === 'id'
                  ? 'Klik tombol "Unduh Foto (PNG)" di atas layar pratinjau untuk mendapatkan cover / thumbnail beresolusi tinggi secara instan.'
                  : 'Click "Snapshot (PNG)" on the preview bar to instantly save high-res poster frames for YouTube video thumbnails.'}
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-neutral-900 py-6 px-6 text-center text-xs text-neutral-500">
        <p>BumperCraft Studio · Pembuat Video Bumper & Intro Animasi Sinematik</p>
      </footer>

      {/* Modals */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        config={config}
        lang={lang}
      />

      <AIBumperModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        onApplyConcept={handleApplyConcept}
        lang={lang}
      />
    </div>
  );
}
