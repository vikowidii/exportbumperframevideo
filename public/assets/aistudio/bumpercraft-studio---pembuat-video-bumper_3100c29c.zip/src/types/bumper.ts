export type BumperThemeId = 'kso_corporate' | 'kso_cinematic';

export type AspectRatio = '16:9' | '9:16' | '1:1';

export type AudioThemeId =
  | 'cinematic'
  | 'cyber'
  | 'retro'
  | 'cosmic'
  | 'minimal'
  | 'gaming'
  | 'none';

export type TransitionStyle = 'slide_left' | 'slide_up';

export type KsoLogoMode = 'hd_vector' | 'raster_png';

export interface BumperConfig {
  title: string;
  subtitle: string;
  tagline?: string;
  theme: BumperThemeId;
  aspectRatio: AspectRatio;
  duration: number; // in seconds (3 - 8s)
  fps: 30 | 60;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  fontFamily: string;
  fontSize: number; // scale multiplier 0.8 - 1.5
  letterSpacing: number; // in px
  icon: string; // preset icon name or 'kso' or 'custom' or 'none' or 'monogram'
  customLogoUrl?: string;
  ksoLogoMode?: KsoLogoMode;
  transitionStyle?: TransitionStyle;
  showPartnerLabels?: boolean;
  particleCount: number; // 0 to 600
  glitchIntensity: number; // 0 to 1
  motionSpeed: number; // 0.7 to 1.5
  vignette: boolean;
  filmGrain: boolean;
  letterbox: boolean;
  audioTheme: AudioThemeId;
  soundEnabled: boolean;
  soundVolume: number; // 0 to 1
}

export interface BumperPreset {
  id: BumperThemeId;
  name: string;
  nameId: string;
  tagline: string;
  description: string;
  category: 'Cinematic' | 'Tech & Gaming' | 'Modern' | 'Retro';
  defaultTitle: string;
  defaultSubtitle: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  fontFamily: string;
  icon: string;
  audioTheme: AudioThemeId;
  duration: number;
}

export interface AIConcept {
  title: string;
  slogan: string;
  themeId: BumperThemeId;
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
  audioTheme: AudioThemeId;
  description: string;
}
